<?php
/**
 * 後台管理頁面
 */

if (!defined('ABSPATH')) {
    exit;
}

class OIP_Admin_Page {
    
    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'handle_form_submission']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_styles']);
        add_action('wp_ajax_oip_resend_email', [$this, 'ajax_resend_email']);
        add_action('wp_ajax_oip_delete_order', [$this, 'ajax_delete_order']);
        add_action('wp_ajax_oip_save_social', [$this, 'ajax_save_social']);
    }
    
    public function add_admin_menu() {
        add_menu_page(
            '網站管理',
            '網站管理',
            'manage_options',
            'order-import',
            [$this, 'render_main_page'],
            'dashicons-admin-site-alt3',
            30
        );
        
        add_submenu_page(
            'order-import',
            '訂單管理',
            '訂單管理',
            'manage_options',
            'order-import',
            [$this, 'render_main_page']
        );
        
        add_submenu_page(
            'order-import',
            '導入訂單',
            '導入訂單',
            'manage_options',
            'order-import-add',
            [$this, 'render_import_page']
        );
        
        add_submenu_page(
            'order-import',
            '網站設置',
            '網站設置',
            'manage_options',
            'order-import-settings',
            [$this, 'render_settings_page']
        );
        
        /* 使用說明頁面暫時註釋
        add_submenu_page(
            'order-import',
            '使用說明',
            '使用說明',
            'manage_options',
            'order-import-help',
            [$this, 'render_help_page']
        );
        */
    }
    
    public function enqueue_admin_styles($hook) {
        if (strpos($hook, 'order-import') === false) {
            return;
        }
        
        wp_enqueue_script('jquery');
        add_action('admin_footer', [$this, 'admin_footer_scripts']);
        
        echo '<style>
            .oip-form { max-width: 600px; }
            .oip-form table { width: 100%; }
            .oip-form input[type="text"],
            .oip-form input[type="email"],
            .oip-form input[type="number"],
            .oip-form textarea { width: 100%; }
            .oip-orders-table { margin-top: 20px; }
            .oip-success { color: green; }
            .oip-error { color: red; }
            .email-sent { color: #46b450; }
            .email-failed { color: #dc3232; }
            .email-pending { color: #f0ad4e; }
            .viewed-yes { color: #46b450; font-weight: 500; }
            .viewed-no { color: #999; }
            .oip-actions a { margin-right: 10px; }
            .oip-template-box { background: #f1f1f1; padding: 15px; margin: 15px 0; border-radius: 5px; }
        </style>';
    }
    
    public function admin_footer_scripts() {
        ?>
        <script>
        jQuery(document).ready(function($) {
            $(".oip-resend-email").on("click", function(e) {
                e.preventDefault();
                var btn = $(this);
                var orderId = btn.data("order-id");
                if (!confirm("確定要重新發送郵件嗎？")) return;
                
                btn.text("發送中...");
                $.post(ajaxurl, {
                    action: "oip_resend_email",
                    order_id: orderId,
                    nonce: "<?php echo wp_create_nonce('oip_ajax_nonce'); ?>"
                }, function(response) {
                    if (response.success) {
                        alert("郵件發送成功！");
                        location.reload();
                    } else {
                        alert("發送失敗：" + response.data);
                        btn.text("重發");
                    }
                });
            });
            
            $(".oip-delete-order").on("click", function(e) {
                e.preventDefault();
                var btn = $(this);
                var orderId = btn.data("order-id");
                if (!confirm("確定要刪除此訂單嗎？此操作不可恢復！")) return;
                
                $.post(ajaxurl, {
                    action: "oip_delete_order",
                    order_id: orderId,
                    nonce: "<?php echo wp_create_nonce('oip_ajax_nonce'); ?>"
                }, function(response) {
                    if (response.success) {
                        btn.closest("tr").fadeOut();
                    } else {
                        alert("刪除失敗：" + response.data);
                    }
                });
            });
            
            // 手動觸發郵件發送
            $("#oip-trigger-emails").on("click", function() {
                var btn = $(this);
                btn.prop("disabled", true).text("發送中...");
                $("#oip-email-status").text("");
                
                $.post(ajaxurl, {
                    action: "oip_trigger_email_queue",
                    nonce: "<?php echo wp_create_nonce('oip_ajax_nonce'); ?>"
                }, function(response) {
                    if (response.success) {
                        if (response.data.pending > 0) {
                            $("#oip-email-status").html('<span style="color:green;">✓ 已處理一批，剩餘 ' + response.data.pending + ' 封</span>');
                            btn.prop("disabled", false).text("繼續發送");
                        } else {
                            $("#oip-email-status").html('<span style="color:green;">✓ 全部發送完成！</span>');
                            setTimeout(function() { location.reload(); }, 1500);
                        }
                    } else {
                        $("#oip-email-status").html('<span style="color:red;">發送失敗</span>');
                        btn.prop("disabled", false).text("重試");
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    public function ajax_resend_email() {
        check_ajax_referer('oip_ajax_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('權限不足');
        }
        
        $order_id = intval($_POST['order_id']);
        $result = OIP_Order_Manager::resend_email($order_id);
        
        if ($result === true) {
            wp_send_json_success();
        } else {
            wp_send_json_error(is_string($result) ? $result : '郵件發送失敗');
        }
    }
    
    public function ajax_delete_order() {
        check_ajax_referer('oip_ajax_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('權限不足');
        }
        
        $order_id = intval($_POST['order_id']);
        $result = OIP_Order_Manager::delete_order($order_id);
        
        if ($result) {
            wp_send_json_success();
        } else {
            wp_send_json_error('刪除失敗');
        }
    }
    
    public function handle_form_submission() {
        if (isset($_GET['oip_download_xlsx'])) {
            $this->download_xlsx_template();
            exit;
        }
        
        // 重置數據表
        if (isset($_GET['oip_reset_table']) && wp_verify_nonce($_GET['_wpnonce'], 'oip_reset_table')) {
            OIP_Order_Manager::maybe_create_table(true);
            add_settings_error('oip_messages', 'oip_success', '數據表已重置！', 'success');
        }
        
        if (isset($_POST['oip_import_single']) && wp_verify_nonce($_POST['oip_nonce'], 'oip_import_order')) {
            $data = [
                'order_number' => sanitize_text_field($_POST['order_number']),
                'recipient_name' => sanitize_text_field($_POST['recipient_name']),
                'recipient_address' => sanitize_textarea_field($_POST['recipient_address']),
                'phone' => sanitize_text_field($_POST['phone']),
                'email' => sanitize_email($_POST['email']),
                'product_name' => sanitize_textarea_field($_POST['product_name']),
                'amount' => floatval($_POST['amount'])
            ];
            
            $result = OIP_Order_Manager::import_order($data, true); // 單筆立即發送
            
            if (is_wp_error($result)) {
                add_settings_error('oip_messages', 'oip_error', $result->get_error_message(), 'error');
            } else {
                add_settings_error('oip_messages', 'oip_success', '訂單導入成功！確認郵件已發送。', 'success');
            }
        }
        
        if (isset($_POST['oip_import_file']) && wp_verify_nonce($_POST['oip_nonce'], 'oip_import_csv')) {
            if (!empty($_FILES['import_file']['tmp_name'])) {
                // 保存文件到臨時目錄，由後台異步處理
                $upload_dir = wp_upload_dir();
                $queue_dir = $upload_dir['basedir'] . '/oip-queue';
                if (!file_exists($queue_dir)) {
                    mkdir($queue_dir, 0755, true);
                }
                
                $queue_file = $queue_dir . '/import_' . time() . '_' . uniqid() . '.xlsx';
                move_uploaded_file($_FILES['import_file']['tmp_name'], $queue_file);
                
                // 記錄到隊列
                $queue = get_option('oip_import_queue', []);
                $queue[] = [
                    'file' => $queue_file,
                    'time' => current_time('mysql'),
                    'status' => 'pending'
                ];
                update_option('oip_import_queue', $queue);
                
                // 立即觸發一次處理
                wp_schedule_single_event(time(), 'oip_process_import_queue');
                
                add_settings_error('oip_messages', 'oip_result', 
                    '📥 文件已上傳，正在後台處理導入和發送郵件...<br>請稍後刷新頁面查看訂單列表。', 
                    'success'
                );
            }
        }
    }
    
    private function download_xlsx_template() {
        // 創建簡單的 xlsx 文件（使用 XML 格式）
        $filename = 'order-import-template.xlsx';
        
        // 創建臨時目錄
        $temp_dir = sys_get_temp_dir() . '/xlsx_' . uniqid();
        mkdir($temp_dir);
        mkdir($temp_dir . '/_rels');
        mkdir($temp_dir . '/xl');
        mkdir($temp_dir . '/xl/_rels');
        mkdir($temp_dir . '/xl/worksheets');
        
        // [Content_Types].xml
        file_put_contents($temp_dir . '/[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
</Types>');
        
        // _rels/.rels
        file_put_contents($temp_dir . '/_rels/.rels', '<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>');
        
        // xl/_rels/workbook.xml.rels
        file_put_contents($temp_dir . '/xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>
</Relationships>');
        
        // xl/workbook.xml
        file_put_contents($temp_dir . '/xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="訂單" sheetId="1" r:id="rId1"/></sheets>
</workbook>');
        
        // 共享字符串（不含訂單號）
        $strings = ['recipient_name', 'recipient_address', 'phone', 'email', 'product_name', 'amount',
                    '王小明', '台北市信義區信義路100號5樓', '0912345678', 'example@email.com', 'iPhone 15 Pro Max 256GB',
                    '李美華', '新北市板橋區文化路200號', '0923456789', 'example2@email.com', 'MacBook Pro 14吋'];
        
        $shared_xml = '<?xml version="1.0" encoding="UTF-8"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="' . count($strings) . '" uniqueCount="' . count($strings) . '">';
        foreach ($strings as $s) {
            $shared_xml .= '<si><t>' . htmlspecialchars($s) . '</t></si>';
        }
        $shared_xml .= '</sst>';
        file_put_contents($temp_dir . '/xl/sharedStrings.xml', $shared_xml);
        
        // xl/worksheets/sheet1.xml（6欄，不含訂單號）
        $sheet_xml = '<?xml version="1.0" encoding="UTF-8"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetData>
<row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c><c r="C1" t="s"><v>2</v></c><c r="D1" t="s"><v>3</v></c><c r="E1" t="s"><v>4</v></c><c r="F1" t="s"><v>5</v></c></row>
<row r="2"><c r="A2" t="s"><v>6</v></c><c r="B2" t="s"><v>7</v></c><c r="C2" t="s"><v>8</v></c><c r="D2" t="s"><v>9</v></c><c r="E2" t="s"><v>10</v></c><c r="F2"><v>45900</v></c></row>
<row r="3"><c r="A3" t="s"><v>11</v></c><c r="B3" t="s"><v>12</v></c><c r="C3" t="s"><v>13</v></c><c r="D3" t="s"><v>14</v></c><c r="E3" t="s"><v>15</v></c><c r="F3"><v>68900</v></c></row>
</sheetData>
</worksheet>';
        file_put_contents($temp_dir . '/xl/worksheets/sheet1.xml', $sheet_xml);
        
        // 創建 zip
        $zip_file = $temp_dir . '.xlsx';
        $zip = new ZipArchive();
        $zip->open($zip_file, ZipArchive::CREATE);
        
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($temp_dir), RecursiveIteratorIterator::LEAVES_ONLY);
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($temp_dir) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
        $zip->close();
        
        // 輸出
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($zip_file));
        readfile($zip_file);
        
        // 清理
        array_map('unlink', glob("$temp_dir/*/*/*"));
        array_map('unlink', glob("$temp_dir/*/*"));
        array_map('unlink', glob("$temp_dir/*"));
        array_map('rmdir', glob("$temp_dir/*/*"));
        array_map('rmdir', glob("$temp_dir/*"));
        rmdir($temp_dir);
        unlink($zip_file);
        exit;
    }
    
    private function get_email_status_html($order) {
        if ($order->email_sent) {
            $time = $order->email_sent_at ? ' (' . date('m/d H:i', strtotime($order->email_sent_at)) . ')' : '';
            return '<span class="email-sent">✓ 已發送' . $time . '</span>';
        } elseif (!empty($order->email_error)) {
            return '<span class="email-failed" title="' . esc_attr($order->email_error) . '">✗ 失敗</span>';
        } else {
            return '<span class="email-pending">⏳ 待發送</span>';
        }
    }
    
    private function get_viewed_status_html($order) {
        $is_viewed = isset($order->is_viewed) ? $order->is_viewed : 0;
        $viewed_at = isset($order->viewed_at) ? $order->viewed_at : null;
        
        if ($is_viewed) {
            $time = $viewed_at ? ' (' . date('m/d H:i', strtotime($viewed_at)) . ')' : '';
            return '<span class="viewed-yes">✓ 已查看' . $time . '</span>';
        } else {
            return '<span class="viewed-no">— 未查看</span>';
        }
    }

    
    public function render_main_page() {
        $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $viewed_filter = isset($_GET['viewed']) ? sanitize_text_field($_GET['viewed']) : '';
        $data = OIP_Order_Manager::get_all_orders($page, 20, $viewed_filter);
        
        // 統計數據
        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_orders';
        $total_all = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        $total_viewed = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE is_viewed = 1");
        $total_not_viewed = $total_all - $total_viewed;
        $pending_emails = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE email_sent = 0 AND (email_error IS NULL OR email_error = '')");
        ?>
        <div class="wrap">
            <h1>訂單管理</h1>
            
            <?php settings_errors('oip_messages'); ?>
            
            <?php if ($pending_emails > 0): ?>
            <div class="notice notice-info" style="padding: 10px 15px; display: flex; align-items: center; gap: 15px;">
                <span>📧 有 <strong><?php echo $pending_emails; ?></strong> 封郵件待發送（系統每分鐘自動處理 20 封）</span>
                <button type="button" class="button" id="oip-trigger-emails">立即發送</button>
                <span id="oip-email-status"></span>
            </div>
            <?php endif; ?>
            
            <ul class="subsubsub">
                <li><a href="<?php echo admin_url('admin.php?page=order-import'); ?>" class="<?php echo $viewed_filter === '' ? 'current' : ''; ?>">全部 <span class="count">(<?php echo $total_all; ?>)</span></a> |</li>
                <li><a href="<?php echo admin_url('admin.php?page=order-import&viewed=viewed'); ?>" class="<?php echo $viewed_filter === 'viewed' ? 'current' : ''; ?>">已查看 <span class="count">(<?php echo $total_viewed; ?>)</span></a> |</li>
                <li><a href="<?php echo admin_url('admin.php?page=order-import&viewed=not_viewed'); ?>" class="<?php echo $viewed_filter === 'not_viewed' ? 'current' : ''; ?>">未查看 <span class="count">(<?php echo $total_not_viewed; ?>)</span></a></li>
            </ul>
            
            <table class="wp-list-table widefat fixed striped oip-orders-table">
                <thead>
                    <tr>
                        <th width="100">訂單號</th>
                        <th width="60">來源</th>
                        <th width="80">收貨人</th>
                        <th>收貨地址</th>
                        <th width="80">電話</th>
                        <th>郵箱</th>
                        <th>商品</th>
                        <th width="80">金額</th>
                        <th width="100">郵件狀態</th>
                        <th width="90">查看狀態</th>
                        <th width="100">操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($data['orders'])): ?>
                        <tr><td colspan="11">暫無訂單</td></tr>
                    <?php else: ?>
                        <?php foreach ($data['orders'] as $order): 
                            $source = isset($order->source) ? $order->source : 'imported';
                        ?>
                            <tr>
                                <td><?php echo esc_html($order->order_number); ?></td>
                                <td><span style="<?php echo ($source === 'online' ? 'color:#0073aa;font-weight:600;' : 'color:#999;'); ?>"><?php echo ($source === 'online' ? '網站' : '導入'); ?></span></td>
                                <td><?php echo esc_html($order->recipient_name ?: '(空)'); ?></td>
                                <td><?php echo esc_html($order->recipient_address ?: '(空)'); ?></td>
                                <td><?php echo esc_html($order->phone); ?></td>
                                <td><?php echo esc_html($order->email); ?></td>
                                <td><?php echo esc_html($order->product_name); ?></td>
                                <td>NT$ <?php echo number_format($order->amount, 0); ?></td>
                                <td><?php echo $this->get_email_status_html($order); ?></td>
                                <td><?php echo $this->get_viewed_status_html($order); ?></td>
                                <td class="oip-actions">
                                    <a href="#" class="oip-resend-email" data-order-id="<?php echo $order->id; ?>">重發</a>
                                    <a href="#" class="oip-delete-order" data-order-id="<?php echo $order->id; ?>" style="color:#dc3232;">刪除</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <?php if ($data['pages'] > 1): ?>
                <div class="tablenav bottom">
                    <div class="tablenav-pages">
                        <?php
                        $base_url = admin_url('admin.php?page=order-import');
                        if ($viewed_filter) {
                            $base_url .= '&viewed=' . $viewed_filter;
                        }
                        echo paginate_links([
                            'base' => $base_url . '&paged=%#%',
                            'format' => '',
                            'current' => $page,
                            'total' => $data['pages']
                        ]);
                        ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    public function render_import_page() {
        // 檢查導入隊列狀態
        $queue = get_option('oip_import_queue', []);
        $processing = array_filter($queue, function($q) { return $q['status'] === 'processing'; });
        $pending = array_filter($queue, function($q) { return $q['status'] === 'pending'; });
        ?>
        <div class="wrap">
            <h1>導入訂單</h1>
            
            <?php settings_errors('oip_messages'); ?>
            
            <?php if (!empty($processing) || !empty($pending)): ?>
            <div class="notice notice-info" style="padding: 15px;">
                <strong>⏳ 後台處理中...</strong><br>
                <?php if (!empty($processing)): ?>
                    正在導入: <?php echo count($processing); ?> 個文件<br>
                <?php endif; ?>
                <?php if (!empty($pending)): ?>
                    等待處理: <?php echo count($pending); ?> 個文件<br>
                <?php endif; ?>
                <small>請稍後刷新頁面查看訂單列表</small>
            </div>
            <?php endif; ?>
            
            <h2>手動添加訂單</h2>
            <form method="post" class="oip-form">
                <?php wp_nonce_field('oip_import_order', 'oip_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="order_number">訂單號</label></th>
                        <td>
                            <input type="text" name="order_number" id="order_number" placeholder="留空則自動生成">
                            <p class="description">可選填，留空系統會自動生成隨機訂單號</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="recipient_name">收件人 *</label></th>
                        <td><input type="text" name="recipient_name" id="recipient_name" required></td>
                    </tr>
                    <tr>
                        <th><label for="email">郵箱地址 *</label></th>
                        <td><input type="email" name="email" id="email" required></td>
                    </tr>
                    <tr>
                        <th><label for="phone">電話 *</label></th>
                        <td><input type="text" name="phone" id="phone" required></td>
                    </tr>
                    <tr>
                        <th><label for="recipient_address">收件地址 *</label></th>
                        <td><textarea name="recipient_address" id="recipient_address" rows="3" required></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="product_name">商品名稱 *</label></th>
                        <td><textarea name="product_name" id="product_name" rows="2" required></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="amount">消費金額 *</label></th>
                        <td><input type="number" name="amount" id="amount" step="0.01" min="0" required></td>
                    </tr>
                </table>
                <p class="submit">
                    <input type="submit" name="oip_import_single" class="button button-primary" value="導入訂單">
                </p>
            </form>
            
            <hr>
            
            <h2>批量導入</h2>
            <div class="oip-template-box">
                <strong>支持格式：</strong>Excel (.xlsx) 文件<br>
                <strong>欄位順序：</strong>recipient_name, recipient_address, phone, email, product_name, amount<br>
                <strong>訂單號：</strong>系統自動生成（千萬級別隨機數字）<br><br>
                <a href="<?php echo admin_url('admin.php?page=order-import-add&oip_download_xlsx=1'); ?>" class="button button-secondary">📥 下載 Excel 模板</a>
                <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=order-import-add&oip_reset_table=1'), 'oip_reset_table'); ?>" class="button" onclick="return confirm('確定要重置數據表嗎？所有訂單數據將被刪除！');" style="color:#dc3232;">🗑️ 重置數據表</a>
            </div>
            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field('oip_import_csv', 'oip_nonce'); ?>
                <input type="file" name="import_file" accept=".xlsx,.xls" required>
                <p class="submit">
                    <input type="submit" name="oip_import_file" class="button button-primary" value="上傳並導入">
                </p>
            </form>
        </div>
        <?php
    }
    
    public function render_help_page() {
        $login_url = home_url('/customer-login/');
        $orders_url = home_url('/my-orders/');
        ?>
        <div class="wrap">
            <h1>使用說明</h1>
            
            <div style="max-width:900px;">
                
                <div style="background:#fff;border:1px solid #ccd0d4;border-radius:4px;padding:20px;margin-bottom:20px;">
                    <h2 style="margin-top:0;color:#1d2327;">📋 插件功能概述</h2>
                    <p>此插件提供獨立的訂單管理系統，可作為 WooCommerce 的輕量替代方案，適用於：</p>
                    <ul style="list-style:disc;padding-left:20px;">
                        <li>訂單數據從外部系統導入（Excel）</li>
                        <li>不需要購物車、在線支付功能</li>
                        <li>只需讓客戶查看訂單狀態和接收郵件通知</li>
                    </ul>
                </div>
                
                <div style="background:#fff;border:1px solid #ccd0d4;border-radius:4px;padding:20px;margin-bottom:20px;">
                    <h2 style="margin-top:0;color:#1d2327;">🔗 前台頁面網址</h2>
                    <table class="widefat" style="margin-top:10px;">
                        <tr>
                            <th style="width:120px;">頁面</th>
                            <th>網址</th>
                            <th style="width:200px;">說明</th>
                        </tr>
                        <tr>
                            <td><strong>會員登入</strong></td>
                            <td><code><?php echo esc_html($login_url); ?></code></td>
                            <td>客戶登入頁面</td>
                        </tr>
                        <tr>
                            <td><strong>我的訂單</strong></td>
                            <td><code><?php echo esc_html($orders_url); ?></code></td>
                            <td>訂單列表和詳情</td>
                        </tr>
                    </table>
                </div>
                
                <div style="background:#fff3cd;border:1px solid #ffc107;border-radius:4px;padding:20px;margin-bottom:20px;">
                    <h2 style="margin-top:0;color:#856404;">⚠️ 替代 WooCommerce 設置指南</h2>
                    <p style="color:#856404;">如果您的主題原本集成了 WooCommerce，刪除 WooCommerce 後請按以下步驟設置：</p>
                    
                    <h3 style="color:#856404;">步驟 1：修改主題菜單連結</h3>
                    <p>前往 <strong>外觀 → 菜單</strong>，將原本指向 WooCommerce 的連結改為：</p>
                    <ul style="list-style:disc;padding-left:20px;color:#856404;">
                        <li>「我的帳戶」→ 改為 <code>/my-orders/</code></li>
                        <li>「登入」→ 改為 <code>/customer-login/</code></li>
                    </ul>
                    
                    <h3 style="color:#856404;">步驟 2：添加自訂連結</h3>
                    <p>在菜單編輯器中，使用「自訂連結」添加：</p>
                    <ul style="list-style:disc;padding-left:20px;color:#856404;">
                        <li>URL：<code><?php echo esc_html($orders_url); ?></code>，連結文字：「我的訂單」</li>
                        <li>URL：<code><?php echo esc_html($login_url); ?></code>，連結文字：「會員登入」</li>
                    </ul>
                    
                    <h3 style="color:#856404;">步驟 3：處理主題中的硬編碼連結</h3>
                    <p>如果主題中有硬編碼的 WooCommerce 連結（如 /my-account/），可能需要：</p>
                    <ul style="list-style:disc;padding-left:20px;color:#856404;">
                        <li>聯繫主題開發者獲取修改方法</li>
                        <li>或使用子主題覆蓋相關模板文件</li>
                        <li>或使用重定向插件將 /my-account/ 重定向到 /my-orders/</li>
                    </ul>
                </div>
                
                <div style="background:#d4edda;border:1px solid #28a745;border-radius:4px;padding:20px;margin-bottom:20px;">
                    <h2 style="margin-top:0;color:#155724;">✅ 本插件提供的功能</h2>
                    <ul style="list-style:none;padding-left:0;color:#155724;">
                        <li>✓ 獨立的會員登入系統（使用電子郵件登入）</li>
                        <li>✓ 訂單列表頁面（顯示所有訂單）</li>
                        <li>✓ 訂單詳情頁面（顯示單筆訂單詳細資訊）</li>
                        <li>✓ 訂單狀態時間線（裝飾性展示）</li>
                        <li>✓ 訂單確認郵件通知</li>
                        <li>✓ 商品圖片管理（按名稱匹配）</li>
                        <li>✓ 完全獨立的頁面樣式（不受主題影響）</li>
                        <li>✓ 響應式設計（支援手機和電腦）</li>
                    </ul>
                </div>
                
                <div style="background:#fff;border:1px solid #ccd0d4;border-radius:4px;padding:20px;margin-bottom:20px;">
                    <h2 style="margin-top:0;color:#1d2327;">📧 郵件設置</h2>
                    <p>請確保已正確配置 SMTP 設置，否則郵件可能無法發送：</p>
                    <ul style="list-style:disc;padding-left:20px;">
                        <li><a href="<?php echo admin_url('admin.php?page=order-import-smtp'); ?>">SMTP 設置</a> - 配置郵件發送服務器</li>
                        <li><a href="<?php echo admin_url('admin.php?page=order-import-email-template'); ?>">郵件模板</a> - 自訂郵件內容和樣式</li>
                    </ul>
                </div>
                
                <div style="background:#fff;border:1px solid #ccd0d4;border-radius:4px;padding:20px;margin-bottom:20px;">
                    <h2 style="margin-top:0;color:#1d2327;">🖼️ 商品圖片設置</h2>
                    <p>前往 <a href="<?php echo admin_url('admin.php?page=order-import-product-images'); ?>">商品圖片</a> 頁面設置商品名稱與圖片的對應關係。</p>
                    <p>支援模糊匹配：設定「面膜」可匹配「玻尿酸保濕面膜」、「美白面膜」等。</p>
                </div>
                
                <div style="background:#e7f3ff;border:1px solid #0073aa;border-radius:4px;padding:20px;">
                    <h2 style="margin-top:0;color:#0073aa;">💡 使用提示</h2>
                    <ul style="list-style:disc;padding-left:20px;color:#0073aa;">
                        <li>客戶使用電子郵件登入，密碼可任意輸入（針對導入的訂單用戶）</li>
                        <li>批量導入使用 Excel (.xlsx) 格式，可下載模板參考</li>
                        <li>郵件會自動排隊發送，每分鐘處理 20 封</li>
                        <li>訂單狀態時間線為裝飾性展示，日期根據訂單創建時間自動計算</li>
                    </ul>
                </div>
                
            </div>
        </div>
        <?php
    }
    
    // ========== 網站設置頁面 ==========
    public function render_settings_page() {
        // 保存設置
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['oip_save_settings'])) {
            check_admin_referer('oip_settings');
            
            $social = [
                'facebook' => esc_url_raw($_POST['social_facebook'] ?? ''),
                'instagram' => esc_url_raw($_POST['social_instagram'] ?? ''),
                'line' => esc_url_raw($_POST['social_line'] ?? ''),
                'youtube' => esc_url_raw($_POST['social_youtube'] ?? ''),
                'twitter' => esc_url_raw($_POST['social_twitter'] ?? ''),
                'tiktok' => esc_url_raw($_POST['social_tiktok'] ?? ''),
            ];
            update_option('oip_social_links', $social);
            
            $footer = [
                'company_id' => sanitize_text_field($_POST['footer_company_id'] ?? ''),
                'phone' => sanitize_text_field($_POST['footer_phone'] ?? ''),
                'service_hours' => sanitize_text_field($_POST['footer_service_hours'] ?? ''),
                'address' => sanitize_text_field($_POST['footer_address'] ?? ''),
                'email' => sanitize_email($_POST['footer_email'] ?? ''),
            ];
            update_option('oip_footer_info', $footer);
            
            echo '<div class="notice notice-success"><p>設置已保存！</p></div>';
        }
        
        $social = get_option('oip_social_links', []);
        $footer = get_option('oip_footer_info', []);
        ?>
        <div class="wrap">
            <h1>網站設置</h1>
            
            <form method="post">
                <?php wp_nonce_field('oip_settings'); ?>
                
                <h2>社交媒體連結</h2>
                <p class="description">設置頁腳「關注我們」區塊的社交媒體連結，留空則不顯示該圖標。</p>
                <table class="form-table">
                    <tr>
                        <th><label for="social_facebook">Facebook</label></th>
                        <td>
                            <input type="url" name="social_facebook" id="social_facebook" class="regular-text" 
                                   value="<?php echo esc_attr($social['facebook'] ?? ''); ?>" 
                                   placeholder="https://facebook.com/yourpage">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="social_instagram">Instagram</label></th>
                        <td>
                            <input type="url" name="social_instagram" id="social_instagram" class="regular-text" 
                                   value="<?php echo esc_attr($social['instagram'] ?? ''); ?>" 
                                   placeholder="https://instagram.com/yourpage">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="social_line">LINE</label></th>
                        <td>
                            <input type="url" name="social_line" id="social_line" class="regular-text" 
                                   value="<?php echo esc_attr($social['line'] ?? ''); ?>" 
                                   placeholder="https://line.me/yourpage">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="social_youtube">YouTube</label></th>
                        <td>
                            <input type="url" name="social_youtube" id="social_youtube" class="regular-text" 
                                   value="<?php echo esc_attr($social['youtube'] ?? ''); ?>" 
                                   placeholder="https://youtube.com/yourchannel">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="social_twitter">Twitter / X</label></th>
                        <td>
                            <input type="url" name="social_twitter" id="social_twitter" class="regular-text" 
                                   value="<?php echo esc_attr($social['twitter'] ?? ''); ?>" 
                                   placeholder="https://twitter.com/yourpage">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="social_tiktok">TikTok</label></th>
                        <td>
                            <input type="url" name="social_tiktok" id="social_tiktok" class="regular-text" 
                                   value="<?php echo esc_attr($social['tiktok'] ?? ''); ?>" 
                                   placeholder="https://tiktok.com/@yourpage">
                        </td>
                    </tr>
                </table>
                
                <hr>
                
                <h2>頁腳資訊</h2>
                <p class="description">設置頁腳底部顯示的公司資訊。</p>
                <table class="form-table">
                    <tr>
                        <th><label for="footer_company_id">統一編號</label></th>
                        <td>
                            <input type="text" name="footer_company_id" id="footer_company_id" class="regular-text" 
                                   value="<?php echo esc_attr($footer['company_id'] ?? ''); ?>" 
                                   placeholder="12345678">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="footer_phone">客服專線</label></th>
                        <td>
                            <input type="text" name="footer_phone" id="footer_phone" class="regular-text" 
                                   value="<?php echo esc_attr($footer['phone'] ?? ''); ?>" 
                                   placeholder="0800-000-000">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="footer_service_hours">服務時間</label></th>
                        <td>
                            <input type="text" name="footer_service_hours" id="footer_service_hours" class="regular-text" 
                                   value="<?php echo esc_attr($footer['service_hours'] ?? ''); ?>" 
                                   placeholder="週一至週五 9:00-18:00">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="footer_email">客服信箱</label></th>
                        <td>
                            <input type="email" name="footer_email" id="footer_email" class="regular-text" 
                                   value="<?php echo esc_attr($footer['email'] ?? ''); ?>" 
                                   placeholder="service@example.com">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="footer_address">公司地址</label></th>
                        <td>
                            <input type="text" name="footer_address" id="footer_address" class="large-text" 
                                   value="<?php echo esc_attr($footer['address'] ?? ''); ?>" 
                                   placeholder="台北市信義區...">
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="oip_save_settings" class="button button-primary" value="保存設置">
                </p>
            </form>
        </div>
        <?php
    }

    public function render_import_images_page() {
        $nonce = wp_create_nonce('oip_admin_nonce');
        ?>
        <div class="wrap">
            <h1>導入本地圖片</h1>
            <div style="background:#fff;padding:20px;border-radius:8px;margin-top:20px;max-width:600px;">
                <p>此功能會自動掃描 <code>/assets/images/</code> 目錄中的圖片，並將其關聯到對應的商品、Banner 和分類。</p>
                <p><strong>確保圖片已放置在正確的目錄中：</strong></p>
                <ul>
                    <li><code>/assets/images/products/</code> - 產品圖片（12張）</li>
                    <li><code>/assets/images/banners/</code> - Banner 圖片（3張）</li>
                    <li><code>/assets/images/categories/</code> - 分類圖標（6張）</li>
                </ul>
                <button class="button button-primary" id="importBtn" onclick="importImages('<?php echo $nonce; ?>')">開始導入圖片</button>
                <div id="importStatus" style="margin-top:20px;"></div>
            </div>
        </div>
        <script>
        function importImages(nonce) {
            var btn = document.getElementById('importBtn');
            btn.disabled = true;
            btn.textContent = '導入中...';
            
            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=oip_import_images&nonce=' + nonce
            })
            .then(r => r.json())
            .then(res => {
                var status = document.getElementById('importStatus');
                if (res.success) {
                    status.innerHTML = '<div style="background:#d4edda;color:#155724;padding:12px;border-radius:4px;"><strong>✓ 導入成功！</strong><br>' + res.data.message + '</div>';
                } else {
                    status.innerHTML = '<div style="background:#f8d7da;color:#721c24;padding:12px;border-radius:4px;"><strong>✗ 導入失敗</strong><br>' + res.data + '</div>';
                }
                btn.disabled = false;
                btn.textContent = '開始導入圖片';
            });
        }
        </script>
        <?php
    }
}
