<?php
/**
 * SMTP 設置類
 */

if (!defined('ABSPATH')) {
    exit;
}

class OIP_SMTP_Settings {
    
    private $option_name = 'oip_smtp_settings';
    
    public function __construct() {
        add_action('admin_menu', [$this, 'add_settings_page']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('phpmailer_init', [$this, 'configure_smtp'], 999, 1);
        add_action('admin_post_oip_test_email', [$this, 'send_test_email']);
    }
    
    public function add_settings_page() {
        add_submenu_page(
            'order-import',
            'SMTP 設置',
            'SMTP 設置',
            'manage_options',
            'order-import-smtp',
            [$this, 'render_settings_page']
        );
    }
    
    public function register_settings() {
        register_setting($this->option_name, $this->option_name, [$this, 'sanitize_settings']);
    }
    
    public function sanitize_settings($input) {
        $sanitized = [];
        $sanitized['enabled'] = isset($input['enabled']) ? '1' : '0';
        $sanitized['host'] = sanitize_text_field($input['host'] ?? '');
        $sanitized['port'] = absint($input['port'] ?? 587);
        $sanitized['encryption'] = in_array($input['encryption'] ?? '', ['', 'ssl', 'tls']) ? $input['encryption'] : 'tls';
        $sanitized['auth'] = isset($input['auth']) ? '1' : '0';
        $sanitized['username'] = sanitize_text_field($input['username'] ?? '');
        
        if (!empty($input['password'])) {
            $sanitized['password'] = $input['password'];
        } else {
            $old = get_option($this->option_name);
            $sanitized['password'] = $old['password'] ?? '';
        }
        
        $sanitized['from_email'] = sanitize_email($input['from_email'] ?? '');
        $sanitized['from_name'] = sanitize_text_field($input['from_name'] ?? '');
        
        return $sanitized;
    }
    
    public function configure_smtp($phpmailer) {
        $settings = get_option($this->option_name);
        
        if (empty($settings['enabled']) || $settings['enabled'] !== '1') {
            return;
        }
        
        if (empty($settings['host'])) {
            return;
        }
        
        $phpmailer->isSMTP();
        $phpmailer->Host = $settings['host'];
        $phpmailer->Port = intval($settings['port']) ?: 587;
        $phpmailer->SMTPAutoTLS = false;
        
        if (!empty($settings['encryption']) && $settings['encryption'] !== '') {
            $phpmailer->SMTPSecure = $settings['encryption'];
        } else {
            $phpmailer->SMTPSecure = '';
        }
        
        if (!empty($settings['auth']) && $settings['auth'] === '1') {
            $phpmailer->SMTPAuth = true;
            $phpmailer->Username = $settings['username'];
            $phpmailer->Password = $settings['password'];
        } else {
            $phpmailer->SMTPAuth = false;
        }
        
        if (!empty($settings['from_email'])) {
            $phpmailer->From = $settings['from_email'];
            $phpmailer->Sender = $settings['from_email'];
        }
        
        if (!empty($settings['from_name'])) {
            $phpmailer->FromName = $settings['from_name'];
        }
    }
    
    public function send_test_email() {
        if (!current_user_can('manage_options')) {
            wp_die('無權限');
        }
        
        check_admin_referer('oip_test_email');
        
        $to = sanitize_email($_POST['test_email'] ?? '');
        if (empty($to)) {
            wp_redirect(add_query_arg('test_result', 'no_email', admin_url('admin.php?page=order-import-smtp')));
            exit;
        }
        
        global $oip_mail_error;
        $oip_mail_error = '';
        
        add_action('wp_mail_failed', function($error) {
            global $oip_mail_error;
            $oip_mail_error = $error->get_error_message();
        });
        
        $subject = '【測試郵件】SMTP 配置測試';
        $message = '<h2>SMTP 測試成功！</h2><p>如果您收到這封郵件，表示 SMTP 配置正確。</p><p>發送時間：' . current_time('Y-m-d H:i:s') . '</p>';
        
        $headers = ['Content-Type: text/html; charset=UTF-8'];
        $result = wp_mail($to, $subject, $message, $headers);
        
        if ($result) {
            wp_redirect(add_query_arg('test_result', 'success', admin_url('admin.php?page=order-import-smtp')));
        } else {
            set_transient('oip_mail_error', $oip_mail_error, 60);
            wp_redirect(add_query_arg('test_result', 'failed', admin_url('admin.php?page=order-import-smtp')));
        }
        exit;
    }

    
    public function render_settings_page() {
        $settings = get_option($this->option_name, []);
        $test_result = $_GET['test_result'] ?? '';
        ?>
        <div class="wrap">
            <h1>SMTP 郵件設置</h1>
            
            <?php if ($test_result === 'success'): ?>
                <div class="notice notice-success"><p>測試郵件發送成功！請檢查收件箱。</p></div>
            <?php elseif ($test_result === 'failed'): ?>
                <div class="notice notice-error">
                    <p>測試郵件發送失敗，請檢查 SMTP 配置。</p>
                    <?php 
                    $error = get_transient('oip_mail_error');
                    if ($error) {
                        echo '<p><strong>錯誤詳情：</strong>' . esc_html($error) . '</p>';
                        delete_transient('oip_mail_error');
                    }
                    ?>
                </div>
            <?php elseif ($test_result === 'no_email'): ?>
                <div class="notice notice-error"><p>請輸入測試郵箱地址。</p></div>
            <?php endif; ?>
            
            <form method="post" action="options.php">
                <?php settings_fields($this->option_name); ?>
                
                <table class="form-table">
                    <tr>
                        <th>啟用 SMTP</th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo $this->option_name; ?>[enabled]" value="1" 
                                    <?php checked($settings['enabled'] ?? '', '1'); ?>>
                                啟用自定義 SMTP 發送郵件
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="smtp_host">SMTP 伺服器</label></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[host]" id="smtp_host" 
                                value="<?php echo esc_attr($settings['host'] ?? ''); ?>" class="regular-text"
                                placeholder="例如：smtp.gmail.com">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="smtp_port">端口</label></th>
                        <td>
                            <input type="number" name="<?php echo $this->option_name; ?>[port]" id="smtp_port" 
                                value="<?php echo esc_attr($settings['port'] ?? '587'); ?>" class="small-text">
                            <p class="description">常用端口：25, 465 (SSL), 587 (TLS)</p>
                        </td>
                    </tr>
                    <tr>
                        <th>加密方式</th>
                        <td>
                            <select name="<?php echo $this->option_name; ?>[encryption]">
                                <option value="" <?php selected($settings['encryption'] ?? '', ''); ?>>無</option>
                                <option value="ssl" <?php selected($settings['encryption'] ?? '', 'ssl'); ?>>SSL</option>
                                <option value="tls" <?php selected($settings['encryption'] ?? '', 'tls'); ?>>TLS</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>SMTP 驗證</th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo $this->option_name; ?>[auth]" value="1"
                                    <?php checked($settings['auth'] ?? '', '1'); ?>>
                                需要用戶名和密碼驗證
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="smtp_username">用戶名</label></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[username]" id="smtp_username" 
                                value="<?php echo esc_attr($settings['username'] ?? ''); ?>" class="regular-text"
                                placeholder="通常是郵箱地址">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="smtp_password">密碼</label></th>
                        <td>
                            <input type="password" name="<?php echo $this->option_name; ?>[password]" id="smtp_password" 
                                class="regular-text" placeholder="<?php echo empty($settings['password']) ? '' : '••••••••（已保存）'; ?>">
                            <p class="description">Gmail 請使用應用專用密碼</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="from_email">發件人郵箱</label></th>
                        <td>
                            <input type="email" name="<?php echo $this->option_name; ?>[from_email]" id="from_email" 
                                value="<?php echo esc_attr($settings['from_email'] ?? ''); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="from_name">發件人名稱</label></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[from_name]" id="from_name" 
                                value="<?php echo esc_attr($settings['from_name'] ?? ''); ?>" class="regular-text"
                                placeholder="例如：訂單通知">
                        </td>
                    </tr>
                </table>
                
                <?php submit_button('保存設置'); ?>
            </form>
            
            <hr>
            
            <h2>發送測試郵件</h2>
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                <?php wp_nonce_field('oip_test_email'); ?>
                <input type="hidden" name="action" value="oip_test_email">
                <p>
                    <input type="email" name="test_email" placeholder="輸入測試郵箱" class="regular-text" required>
                    <input type="submit" class="button button-secondary" value="發送測試郵件">
                </p>
            </form>
            
            <hr>
            
            <h3>常用 SMTP 配置參考</h3>
            <table class="widefat" style="max-width: 600px;">
                <thead>
                    <tr><th>服務商</th><th>伺服器</th><th>端口</th><th>加密</th></tr>
                </thead>
                <tbody>
                    <tr><td>Gmail</td><td>smtp.gmail.com</td><td>587</td><td>TLS</td></tr>
                    <tr><td>Outlook/Hotmail</td><td>smtp.office365.com</td><td>587</td><td>TLS</td></tr>
                    <tr><td>Yahoo</td><td>smtp.mail.yahoo.com</td><td>587</td><td>TLS</td></tr>
                    <tr><td>阿里雲郵箱</td><td>smtp.aliyun.com</td><td>465</td><td>SSL</td></tr>
                    <tr><td>QQ 郵箱</td><td>smtp.qq.com</td><td>465</td><td>SSL</td></tr>
                    <tr><td>163 郵箱</td><td>smtp.163.com</td><td>465</td><td>SSL</td></tr>
                </tbody>
            </table>
        </div>
        <?php
    }
}
