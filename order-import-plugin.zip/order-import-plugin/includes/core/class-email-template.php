<?php
/**
 * 郵件模板設置
 */

if (!defined('ABSPATH')) {
    exit;
}

class OIP_Email_Template {
    
    private $option_name = 'oip_email_template';
    
    public function __construct() {
        add_action('admin_menu', [$this, 'add_settings_page']);
        add_action('admin_init', [$this, 'register_settings']);
    }
    
    public function add_settings_page() {
        add_submenu_page(
            'order-import',
            '郵件模板',
            '郵件模板',
            'manage_options',
            'order-import-email-template',
            [$this, 'render_settings_page']
        );
    }
    
    public function register_settings() {
        register_setting($this->option_name, $this->option_name, [$this, 'sanitize_settings']);
    }
    
    public function sanitize_settings($input) {
        $sanitized = [];
        $sanitized['subject'] = sanitize_text_field($input['subject'] ?? '');
        $sanitized['header_title'] = sanitize_text_field($input['header_title'] ?? '');
        $sanitized['header_color'] = sanitize_hex_color($input['header_color'] ?? '#4a90d9');
        $sanitized['greeting'] = sanitize_text_field($input['greeting'] ?? '');
        $sanitized['intro_text'] = wp_kses_post($input['intro_text'] ?? '');
        $sanitized['footer_text'] = wp_kses_post($input['footer_text'] ?? '');
        $sanitized['contact_text'] = sanitize_text_field($input['contact_text'] ?? '');
        $sanitized['contact_link'] = esc_url_raw($input['contact_link'] ?? '');
        $sanitized['contact_link_text'] = sanitize_text_field($input['contact_link_text'] ?? '');
        $sanitized['show_login_info'] = isset($input['show_login_info']) ? '1' : '0';
        $sanitized['login_button_text'] = sanitize_text_field($input['login_button_text'] ?? '');
        $sanitized['login_account_label'] = sanitize_text_field($input['login_account_label'] ?? '');
        $sanitized['login_password_hint'] = sanitize_text_field($input['login_password_hint'] ?? '');
        $sanitized['closing_text'] = sanitize_text_field($input['closing_text'] ?? '');
        $sanitized['show_site_url'] = isset($input['show_site_url']) ? '1' : '0';
        $sanitized['line_id'] = sanitize_text_field($input['line_id'] ?? '');
        $sanitized['customer_service_phone'] = sanitize_text_field($input['customer_service_phone'] ?? '');
        $sanitized['show_faq'] = isset($input['show_faq']) ? '1' : '0';
        return $sanitized;
    }
    
    public static function get_settings() {
        $defaults = [
            'subject' => '訂單確認 - {order_number}',
            'header_title' => '訂單確認通知',
            'header_color' => '#ee4d2d',
            'greeting' => '親愛的 {recipient_name}，您好！',
            'intro_text' => '感謝您的訂購！我們已收到您的訂單，以下是您的訂單詳情：',
            'footer_text' => '此郵件由 {site_name} 系統自動發送，請勿直接回覆。',
            'contact_text' => '如有任何問題，請隨時與我們聯繫',
            'contact_link' => '',
            'contact_link_text' => '聯繫我們',
            'show_login_info' => '1',
            'login_button_text' => '查看我的訂單',
            'login_account_label' => '登入帳號（您的電子郵件）：',
            'login_password_hint' => '密碼：任意輸入即可登入',
            'closing_text' => '祝您購物愉快！',
            'show_site_url' => '0',
            'line_id' => '',
            'customer_service_phone' => '',
            'show_faq' => '1'
        ];
        
        $settings = get_option('oip_email_template', []);
        return wp_parse_args($settings, $defaults);
    }
    
    public function render_settings_page() {
        $settings = self::get_settings();
        ?>
        <div class="wrap">
            <h1>郵件模板設置</h1>
            
            <?php settings_errors(); ?>
            
            <p>可用變量：<code>{order_number}</code> <code>{recipient_name}</code> <code>{email}</code> <code>{site_name}</code> <code>{site_url}</code></p>
            
            <form method="post" action="options.php">
                <?php settings_fields($this->option_name); ?>
                
                <table class="form-table">
                    <tr>
                        <th><label for="subject">郵件主題</label></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[subject]" id="subject" 
                                value="<?php echo esc_attr($settings['subject']); ?>" class="large-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="header_title">標題文字</label></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[header_title]" id="header_title" 
                                value="<?php echo esc_attr($settings['header_title']); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="header_color">標題背景顏色</label></th>
                        <td>
                            <input type="color" name="<?php echo $this->option_name; ?>[header_color]" id="header_color" 
                                value="<?php echo esc_attr($settings['header_color']); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="greeting">問候語</label></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[greeting]" id="greeting" 
                                value="<?php echo esc_attr($settings['greeting']); ?>" class="large-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="intro_text">開頭說明</label></th>
                        <td>
                            <textarea name="<?php echo $this->option_name; ?>[intro_text]" id="intro_text" 
                                rows="3" class="large-text"><?php echo esc_textarea($settings['intro_text']); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="contact_text">聯繫提示文字</label></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[contact_text]" id="contact_text" 
                                value="<?php echo esc_attr($settings['contact_text']); ?>" class="large-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="contact_link">聯繫我們連結</label></th>
                        <td>
                            <input type="url" name="<?php echo $this->option_name; ?>[contact_link]" id="contact_link" 
                                value="<?php echo esc_attr($settings['contact_link']); ?>" class="regular-text" placeholder="https://example.com/contact">
                            <p class="description">留空則不顯示連結</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="contact_link_text">連結文字</label></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[contact_link_text]" id="contact_link_text" 
                                value="<?php echo esc_attr($settings['contact_link_text']); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="line_id">LINE ID</label></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[line_id]" id="line_id" 
                                value="<?php echo esc_attr($settings['line_id']); ?>" class="regular-text" placeholder="@yourlineid">
                            <p class="description">客服 LINE ID，顯示在郵件中方便客戶聯繫（留空則不顯示）</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="customer_service_phone">客服電話</label></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[customer_service_phone]" id="customer_service_phone" 
                                value="<?php echo esc_attr($settings['customer_service_phone']); ?>" class="regular-text" placeholder="02-1234-5678">
                            <p class="description">客服電話，顯示在郵件中（留空則不顯示）</p>
                        </td>
                    </tr>
                    <tr>
                        <th>顯示常見問題</th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo $this->option_name; ?>[show_faq]" value="1"
                                    <?php checked($settings['show_faq'], '1'); ?>>
                                在郵件中顯示常見問題區塊
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th>顯示登入資訊</th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo $this->option_name; ?>[show_login_info]" value="1"
                                    <?php checked($settings['show_login_info'], '1'); ?>>
                                顯示「查看我的訂單」按鈕和登入帳號
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="login_button_text">按鈕文字</label></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[login_button_text]" id="login_button_text" 
                                value="<?php echo esc_attr($settings['login_button_text']); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="login_account_label">帳號標籤</label></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[login_account_label]" id="login_account_label" 
                                value="<?php echo esc_attr($settings['login_account_label']); ?>" class="regular-text">
                            <p class="description">例如：登入帳號：</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="login_password_hint">密碼提示</label></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[login_password_hint]" id="login_password_hint" 
                                value="<?php echo esc_attr($settings['login_password_hint']); ?>" class="large-text">
                            <p class="description">例如：密碼：任意輸入即可登入（留空則不顯示）</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="closing_text">結尾祝福語</label></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[closing_text]" id="closing_text" 
                                value="<?php echo esc_attr($settings['closing_text']); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="footer_text">頁腳文字</label></th>
                        <td>
                            <textarea name="<?php echo $this->option_name; ?>[footer_text]" id="footer_text" 
                                rows="2" class="large-text"><?php echo esc_textarea($settings['footer_text']); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th>顯示網站連結</th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo $this->option_name; ?>[show_site_url]" value="1"
                                    <?php checked($settings['show_site_url'], '1'); ?>>
                                在頁腳顯示網站網址
                            </label>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button('保存設置'); ?>
            </form>
            
            <hr>
            <h2>預覽</h2>
            <p>保存設置後，發送測試郵件可在 <a href="<?php echo admin_url('admin.php?page=order-import-smtp'); ?>">SMTP 設置</a> 頁面進行。</p>
        </div>
        <?php
    }
}
