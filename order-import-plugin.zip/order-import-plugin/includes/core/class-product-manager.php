<?php
/**
 * 商品管理類 - 弹窗式编辑
 */

if (!defined('ABSPATH')) {
    exit;
}

class OIP_Product_Manager {
    
    public function __construct() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('wp_ajax_oip_save_product', [$this, 'ajax_save_product']);
        add_action('wp_ajax_oip_delete_product', [$this, 'ajax_delete_product']);
        add_action('wp_ajax_oip_get_product', [$this, 'ajax_get_product']);
        add_action('wp_ajax_oip_save_category', [$this, 'ajax_save_category']);
        add_action('wp_ajax_oip_delete_category', [$this, 'ajax_delete_category']);
        add_action('wp_ajax_oip_get_category', [$this, 'ajax_get_category']);
        add_action('wp_ajax_oip_save_banner', [$this, 'ajax_save_banner']);
        add_action('wp_ajax_oip_delete_banner', [$this, 'ajax_delete_banner']);
        add_action('wp_ajax_oip_get_banner', [$this, 'ajax_get_banner']);
        add_action('wp_ajax_oip_import_images', [$this, 'ajax_import_images']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
    }
    
    public static function create_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'oip_products';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            slug varchar(255) NOT NULL,
            description text,
            price decimal(10,2) NOT NULL DEFAULT 0,
            original_price decimal(10,2) DEFAULT NULL,
            category_id bigint(20) DEFAULT 0,
            image varchar(500),
            gallery text,
            stock int(11) DEFAULT 999,
            sales int(11) DEFAULT 0,
            rating decimal(2,1) DEFAULT 4.5,
            status varchar(20) DEFAULT 'publish',
            sort_order int(11) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY category_id (category_id),
            KEY status (status)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        // 分類表
        $cat_table = $wpdb->prefix . 'oip_categories';
        $sql2 = "CREATE TABLE IF NOT EXISTS $cat_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            slug varchar(100) NOT NULL,
            icon varchar(500),
            sort_order int(11) DEFAULT 0,
            PRIMARY KEY (id)
        ) $charset_collate;";
        dbDelta($sql2);
        
        // 輪播圖表
        $banner_table = $wpdb->prefix . 'oip_banners';
        $sql3 = "CREATE TABLE IF NOT EXISTS $banner_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            title varchar(255),
            image varchar(500) NOT NULL,
            link varchar(500),
            sort_order int(11) DEFAULT 0,
            status tinyint(1) DEFAULT 1,
            PRIMARY KEY (id)
        ) $charset_collate;";
        dbDelta($sql3);
        
        self::insert_sample_data();
    }
    
    public static function insert_sample_data() {
        global $wpdb;
        if (get_option('oip_sample_data_imported')) return;
        $cat_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}oip_categories");
        if ($cat_count > 0) { update_option('oip_sample_data_imported', true); return; }
        
        $categories = [
            ['name' => '手機配件', 'slug' => 'phone-accessories', 'sort_order' => 1],
            ['name' => '電腦周邊', 'slug' => 'computer-peripherals', 'sort_order' => 2],
            ['name' => '智能穿戴', 'slug' => 'wearables', 'sort_order' => 3],
            ['name' => '耳機音響', 'slug' => 'audio', 'sort_order' => 4],
            ['name' => '充電設備', 'slug' => 'chargers', 'sort_order' => 5],
            ['name' => '保護殼膜', 'slug' => 'cases', 'sort_order' => 6],
        ];
        foreach ($categories as $cat) { $wpdb->insert($wpdb->prefix . 'oip_categories', $cat); }
        
        $products = [
            ['name' => 'iPhone 15 Pro Max 透明防摔殼', 'slug' => 'iphone15-case', 'price' => 299, 'original_price' => 599, 'category_id' => 6, 'stock' => 999, 'sales' => 2847, 'rating' => 4.8, 'status' => 'publish'],
            ['name' => 'iPhone 15 鋼化玻璃保護貼 2片裝', 'slug' => 'iphone15-glass', 'price' => 199, 'original_price' => 399, 'category_id' => 6, 'stock' => 999, 'sales' => 5623, 'rating' => 4.7, 'status' => 'publish'],
            ['name' => 'AirPods Pro 2 藍牙耳機', 'slug' => 'airpods-pro2', 'price' => 7490, 'original_price' => 7990, 'category_id' => 4, 'stock' => 50, 'sales' => 1523, 'rating' => 4.9, 'status' => 'publish'],
            ['name' => 'Sony WH-1000XM5 無線降噪耳機', 'slug' => 'sony-xm5', 'price' => 10900, 'original_price' => 11900, 'category_id' => 4, 'stock' => 30, 'sales' => 756, 'rating' => 4.9, 'status' => 'publish'],
            ['name' => 'Apple Watch Series 9 智慧手錶', 'slug' => 'apple-watch-s9', 'price' => 12900, 'original_price' => 13900, 'category_id' => 3, 'stock' => 30, 'sales' => 892, 'rating' => 4.7, 'status' => 'publish'],
            ['name' => '小米手環 8', 'slug' => 'mi-band-8', 'price' => 1095, 'original_price' => 1295, 'category_id' => 3, 'stock' => 200, 'sales' => 2156, 'rating' => 4.6, 'status' => 'publish'],
            ['name' => '65W GaN 氮化鎵快充充電器', 'slug' => 'gan-charger-65w', 'price' => 699, 'original_price' => 1299, 'category_id' => 5, 'stock' => 500, 'sales' => 5621, 'rating' => 4.6, 'status' => 'publish'],
            ['name' => 'Anker 10000mAh 行動電源', 'slug' => 'anker-powerbank', 'price' => 899, 'original_price' => 1299, 'category_id' => 5, 'stock' => 300, 'sales' => 4521, 'rating' => 4.7, 'status' => 'publish'],
            ['name' => 'Logitech MX Master 3S 無線滑鼠', 'slug' => 'mx-master-3s', 'price' => 3290, 'original_price' => 3990, 'category_id' => 2, 'stock' => 80, 'sales' => 1247, 'rating' => 4.8, 'status' => 'publish'],
            ['name' => 'Keychron K3 超薄機械鍵盤', 'slug' => 'keychron-k3', 'price' => 2490, 'original_price' => 2990, 'category_id' => 2, 'stock' => 40, 'sales' => 623, 'rating' => 4.8, 'status' => 'publish'],
            ['name' => '車用磁吸手機支架', 'slug' => 'car-phone-mount', 'price' => 399, 'original_price' => 699, 'category_id' => 1, 'stock' => 500, 'sales' => 3456, 'rating' => 4.5, 'status' => 'publish'],
            ['name' => '手機雲台穩定器', 'slug' => 'phone-gimbal', 'price' => 2990, 'original_price' => 3990, 'category_id' => 1, 'stock' => 50, 'sales' => 567, 'rating' => 4.6, 'status' => 'publish'],
        ];
        foreach ($products as $p) { $wpdb->insert($wpdb->prefix . 'oip_products', $p); }
        
        $banners = [
            ['title' => '新品上市', 'image' => 'https://placehold.co/1200x480/ee4d2d/white?text=新品上市', 'sort_order' => 1, 'status' => 1],
            ['title' => '限時特賣', 'image' => 'https://placehold.co/1200x480/ff6633/white?text=限時特賣', 'sort_order' => 2, 'status' => 1],
        ];
        foreach ($banners as $b) { $wpdb->insert($wpdb->prefix . 'oip_banners', $b); }
        
        update_option('oip_sample_data_imported', true);
    }
    
    /**
     * 自動掃描並導入本地圖片
     */
    public static function auto_import_local_images() {
        global $wpdb;
        $plugin_file = dirname(dirname(dirname(__FILE__))) . '/order-import-plugin.php';
        $images_dir = dirname(dirname(dirname(__FILE__))) . '/assets/images';
        $imported_count = 0;
        
        // 產品圖片對應表
        $product_image_map = [
            'iphone15-case.jpg' => 'iPhone 15 Pro Max 透明防摔殼',
            'iphone15-glass.jpg' => 'iPhone 15 鋼化玻璃保護貼 2片裝',
            'airpods-pro2.jpg' => 'AirPods Pro 2 藍牙耳機',
            'sony-xm5.jpg' => 'Sony WH-1000XM5 無線降噪耳機',
            'apple-watch-s9.jpg' => 'Apple Watch Series 9 智慧手錶',
            'mi-band-8.jpg' => '小米手環 8',
            'gan-charger-65w.jpg' => '65W GaN 氮化鎵快充充電器',
            'anker-powerbank.jpg' => 'Anker 10000mAh 行動電源',
            'mx-master-3s.jpg' => 'Logitech MX Master 3S 無線滑鼠',
            'keychron-k3.jpg' => 'Keychron K3 超薄機械鍵盤',
            'car-phone-mount.jpg' => '車用磁吸手機支架',
            'phone-gimbal.jpg' => '手機雲台穩定器',
        ];
        
        // 掃描產品圖片
        $products_dir = $images_dir . '/products';
        if (is_dir($products_dir)) {
            foreach ($product_image_map as $filename => $product_name) {
                $filepath = $products_dir . '/' . $filename;
                if (file_exists($filepath)) {
                    $image_url = plugins_url('assets/images/products/' . $filename, $plugin_file);
                    $wpdb->update(
                        $wpdb->prefix . 'oip_products',
                        ['image' => $image_url],
                        ['name' => $product_name],
                        ['%s'],
                        ['%s']
                    );
                    $imported_count++;
                }
            }
        }
        
        // Banner 圖片對應表
        $banner_image_map = [
            'banner-new-products.jpg' => '新品上市',
            'banner-flash-sale.jpg' => '限時特賣',
            'banner-hot-products.jpg' => '熱銷商品',
        ];
        
        // 掃描 Banner 圖片
        $banners_dir = $images_dir . '/banners';
        if (is_dir($banners_dir)) {
            foreach ($banner_image_map as $filename => $banner_title) {
                $filepath = $banners_dir . '/' . $filename;
                if (file_exists($filepath)) {
                    $image_url = plugins_url('assets/images/banners/' . $filename, $plugin_file);
                    $wpdb->update(
                        $wpdb->prefix . 'oip_banners',
                        ['image' => $image_url],
                        ['title' => $banner_title],
                        ['%s'],
                        ['%s']
                    );
                    $imported_count++;
                }
            }
        }
        
        // 分類圖標對應表
        $category_image_map = [
            'category-phone-accessories.png' => '手機配件',
            'category-computer-peripherals.png' => '電腦周邊',
            'category-wearables.png' => '智能穿戴',
            'category-audio.png' => '耳機音響',
            'category-chargers.png' => '充電設備',
            'category-cases.png' => '保護殼膜',
        ];
        
        // 掃描分類圖標
        $categories_dir = $images_dir . '/categories';
        if (is_dir($categories_dir)) {
            foreach ($category_image_map as $filename => $category_name) {
                $filepath = $categories_dir . '/' . $filename;
                if (file_exists($filepath)) {
                    $image_url = plugins_url('assets/images/categories/' . $filename, $plugin_file);
                    $wpdb->update(
                        $wpdb->prefix . 'oip_categories',
                        ['icon' => $image_url],
                        ['name' => $category_name],
                        ['%s'],
                        ['%s']
                    );
                    $imported_count++;
                }
            }
        }
        
        return "成功導入 {$imported_count} 個圖片資源。";
    }

    public function add_menu() {
        add_submenu_page('order-import', '商品管理', '商品管理', 'manage_options', 'oip-products', [$this, 'render_products_page']);
        add_submenu_page('order-import', '商品分類', '商品分類', 'manage_options', 'oip-categories', [$this, 'render_categories_page']);
        add_submenu_page('order-import', '輪播圖', '輪播圖', 'manage_options', 'oip-banners', [$this, 'render_banners_page']);
    }
    
    public function enqueue_scripts($hook) {
        if (strpos($hook, 'oip-products') !== false || strpos($hook, 'oip-categories') !== false || strpos($hook, 'oip-banners') !== false) {
            wp_enqueue_media();
        }
    }
    
    // ========== AJAX 處理 ==========
    public function ajax_save_product() {
        check_ajax_referer('oip_admin_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('權限不足');
        
        global $wpdb;
        $table = $wpdb->prefix . 'oip_products';
        $data = [
            'name' => sanitize_text_field($_POST['name']),
            'slug' => sanitize_title($_POST['name']),
            'description' => wp_kses_post($_POST['description'] ?? ''),
            'price' => floatval($_POST['price']),
            'original_price' => !empty($_POST['original_price']) ? floatval($_POST['original_price']) : null,
            'category_id' => intval($_POST['category_id']),
            'image' => esc_url_raw($_POST['image'] ?? ''),
            'stock' => intval($_POST['stock'] ?? 999),
            'sales' => intval($_POST['sales'] ?? 0),
            'status' => sanitize_text_field($_POST['status'] ?? 'publish'),
            'sort_order' => intval($_POST['sort_order'] ?? 0)
        ];
        
        $id = intval($_POST['id'] ?? 0);
        if ($id > 0) {
            $wpdb->update($table, $data, ['id' => $id]);
        } else {
            $wpdb->insert($table, $data);
            $id = $wpdb->insert_id;
        }
        wp_send_json_success(['id' => $id]);
    }
    
    public function ajax_delete_product() {
        check_ajax_referer('oip_admin_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('權限不足');
        global $wpdb;
        $wpdb->delete($wpdb->prefix . 'oip_products', ['id' => intval($_POST['id'])]);
        wp_send_json_success();
    }
    
    public function ajax_get_product() {
        check_ajax_referer('oip_admin_nonce', 'nonce');
        $product = self::get_product(intval($_GET['id']));
        wp_send_json_success($product);
    }
    
    public function ajax_save_category() {
        check_ajax_referer('oip_admin_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('權限不足');
        
        global $wpdb;
        $table = $wpdb->prefix . 'oip_categories';
        $data = [
            'name' => sanitize_text_field($_POST['name']),
            'slug' => sanitize_title($_POST['name']),
            'icon' => esc_url_raw($_POST['icon'] ?? ''),
            'sort_order' => intval($_POST['sort_order'] ?? 0)
        ];
        
        $id = intval($_POST['id'] ?? 0);
        if ($id > 0) {
            $wpdb->update($table, $data, ['id' => $id]);
        } else {
            $wpdb->insert($table, $data);
            $id = $wpdb->insert_id;
        }
        wp_send_json_success(['id' => $id]);
    }
    
    public function ajax_delete_category() {
        check_ajax_referer('oip_admin_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('權限不足');
        global $wpdb;
        $wpdb->delete($wpdb->prefix . 'oip_categories', ['id' => intval($_POST['id'])]);
        wp_send_json_success();
    }
    
    public function ajax_get_category() {
        check_ajax_referer('oip_admin_nonce', 'nonce');
        $cat = self::get_category(intval($_GET['id']));
        wp_send_json_success($cat);
    }
    
    public function ajax_save_banner() {
        check_ajax_referer('oip_admin_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('權限不足');
        
        global $wpdb;
        $table = $wpdb->prefix . 'oip_banners';
        $data = [
            'title' => sanitize_text_field($_POST['title'] ?? ''),
            'image' => esc_url_raw($_POST['image']),
            'link' => esc_url_raw($_POST['link'] ?? ''),
            'sort_order' => intval($_POST['sort_order'] ?? 0),
            'status' => intval($_POST['status'] ?? 1)
        ];
        
        $id = intval($_POST['id'] ?? 0);
        if ($id > 0) {
            $wpdb->update($table, $data, ['id' => $id]);
        } else {
            $wpdb->insert($table, $data);
            $id = $wpdb->insert_id;
        }
        wp_send_json_success(['id' => $id]);
    }
    
    public function ajax_delete_banner() {
        check_ajax_referer('oip_admin_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('權限不足');
        global $wpdb;
        $wpdb->delete($wpdb->prefix . 'oip_banners', ['id' => intval($_POST['id'])]);
        wp_send_json_success();
    }
    
    public function ajax_get_banner() {
        check_ajax_referer('oip_admin_nonce', 'nonce');
        global $wpdb;
        $banner = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}oip_banners WHERE id = %d", intval($_GET['id'])));
        wp_send_json_success($banner);
    }

    // ========== 靜態方法 ==========
    public static function get_products($args = []) {
        global $wpdb;
        $table = $wpdb->prefix . 'oip_products';
        $where = "WHERE 1=1";
        if (!empty($args['category_id'])) $where .= $wpdb->prepare(" AND category_id = %d", $args['category_id']);
        if (!empty($args['status'])) $where .= $wpdb->prepare(" AND status = %s", $args['status']);
        if (!empty($args['search'])) $where .= $wpdb->prepare(" AND name LIKE %s", '%' . $wpdb->esc_like($args['search']) . '%');
        $order = "ORDER BY sort_order ASC, id DESC";
        
        if (!empty($args['paged']) && !empty($args['per_page'])) {
            $page = max(1, intval($args['paged']));
            $per_page = intval($args['per_page']);
            $offset = ($page - 1) * $per_page;
            $total = $wpdb->get_var("SELECT COUNT(*) FROM $table $where");
            $products = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table $where $order LIMIT %d, %d", $offset, $per_page));
            return ['products' => $products, 'total' => $total, 'pages' => ceil($total / $per_page), 'current_page' => $page];
        }
        
        $limit = !empty($args['limit']) ? $wpdb->prepare("LIMIT %d", $args['limit']) : "";
        return $wpdb->get_results("SELECT * FROM $table $where $order $limit");
    }
    
    public static function get_product($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}oip_products WHERE id = %d", $id));
    }
    
    public static function get_categories() {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}oip_categories ORDER BY sort_order ASC, id ASC");
    }
    
    public static function get_category($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}oip_categories WHERE id = %d", $id));
    }
    
    public static function get_banners() {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}oip_banners WHERE status = 1 ORDER BY sort_order ASC, id ASC");
    }

    // ========== 商品管理頁面 ==========
    public function render_products_page() {
        global $wpdb;
        $categories = self::get_categories();
        $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $filter_cat = isset($_GET['cat']) ? intval($_GET['cat']) : 0;
        $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        
        $args = ['paged' => $paged, 'per_page' => 20];
        if ($filter_cat > 0) $args['category_id'] = $filter_cat;
        if ($search) $args['search'] = $search;
        $data = self::get_products($args);
        $products = $data['products'];
        $total_pages = $data['pages'];
        $total = $data['total'];
        
        $all_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}oip_products");
        $cat_counts = [];
        foreach ($categories as $cat) {
            $cat_counts[$cat->id] = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}oip_products WHERE category_id = %d", $cat->id));
        }
        ?>
        <div class="wrap">
            <h1>商品管理 <button class="page-title-action" onclick="openProductModal()">新增商品</button></h1>
            
            <ul class="subsubsub">
                <li><a href="<?php echo admin_url('admin.php?page=oip-products'); ?>" class="<?php echo !$filter_cat && !$search ? 'current' : ''; ?>">全部 (<?php echo $all_count; ?>)</a></li>
                <?php foreach ($categories as $cat): ?>
                | <li><a href="<?php echo admin_url('admin.php?page=oip-products&cat=' . $cat->id); ?>" class="<?php echo $filter_cat === (int)$cat->id ? 'current' : ''; ?>"><?php echo esc_html($cat->name); ?> (<?php echo $cat_counts[$cat->id] ?? 0; ?>)</a></li>
                <?php endforeach; ?>
            </ul>
            
            <form method="get" style="float:right;margin:5px 0;">
                <input type="hidden" name="page" value="oip-products">
                <?php if ($filter_cat): ?><input type="hidden" name="cat" value="<?php echo $filter_cat; ?>"><?php endif; ?>
                <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="搜索商品...">
                <button type="submit" class="button">搜索</button>
            </form>
            
            <table class="wp-list-table widefat fixed striped" style="clear:both;margin-top:10px;">
                <thead><tr><th width="60">圖片</th><th>名稱</th><th width="80">分類</th><th width="100">售價</th><th width="50">庫存</th><th width="50">已售</th><th width="50">狀態</th><th width="100">操作</th></tr></thead>
                <tbody>
                <?php if (empty($products)): ?>
                    <tr><td colspan="8">暫無商品</td></tr>
                <?php else: foreach ($products as $p): $cat = $p->category_id ? self::get_category($p->category_id) : null; ?>
                    <tr>
                        <td><?php if ($p->image): ?><img src="<?php echo esc_url($p->image); ?>" style="width:50px;height:50px;object-fit:cover;"><?php else: ?>-<?php endif; ?></td>
                        <td><strong><?php echo esc_html($p->name); ?></strong></td>
                        <td><?php echo $cat ? esc_html($cat->name) : '-'; ?></td>
                        <td>$<?php echo number_format($p->price); ?><?php if ($p->original_price): ?><br><del style="color:#999;font-size:11px;">$<?php echo number_format($p->original_price); ?></del><?php endif; ?></td>
                        <td><?php echo $p->stock; ?></td>
                        <td><?php echo $p->sales; ?></td>
                        <td><?php echo $p->status === 'publish' ? '<span style="color:green;">上架</span>' : '<span style="color:#999;">下架</span>'; ?></td>
                        <td><a href="#" onclick="editProduct(<?php echo $p->id; ?>);return false;">編輯</a> | <a href="#" onclick="deleteProduct(<?php echo $p->id; ?>);return false;" style="color:#dc3232;">刪除</a></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
            
            <?php if ($total_pages > 1): ?>
            <div class="tablenav bottom"><div class="tablenav-pages">
                <?php
                $base_url = admin_url('admin.php?page=oip-products');
                if ($filter_cat) $base_url .= '&cat=' . $filter_cat;
                if ($search) $base_url .= '&s=' . urlencode($search);
                echo paginate_links(['base' => $base_url . '&paged=%#%', 'current' => $paged, 'total' => $total_pages]);
                ?>
            </div></div>
            <?php endif; ?>
        </div>
        
        <!-- 商品彈窗 -->
        <div id="productModal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);z-index:100000;">
            <div style="background:#fff;width:600px;max-width:90%;max-height:90%;overflow:auto;margin:50px auto;border-radius:8px;box-shadow:0 5px 30px rgba(0,0,0,.3);">
                <div style="padding:15px 20px;border-bottom:1px solid #ddd;display:flex;justify-content:space-between;align-items:center;">
                    <h2 style="margin:0;" id="productModalTitle">新增商品</h2>
                    <button onclick="closeProductModal()" style="background:none;border:none;font-size:24px;cursor:pointer;">&times;</button>
                </div>
                <form id="productForm" style="padding:20px;">
                    <input type="hidden" name="id" id="p_id">
                    <table class="form-table" style="margin:0;">
                        <tr><th style="width:100px;">名稱 *</th><td><input type="text" name="name" id="p_name" class="regular-text" required></td></tr>
                        <tr><th>分類</th><td><select name="category_id" id="p_category_id"><option value="0">-- 無 --</option><?php foreach ($categories as $cat): ?><option value="<?php echo $cat->id; ?>"><?php echo esc_html($cat->name); ?></option><?php endforeach; ?></select></td></tr>
                        <tr><th>售價 *</th><td><input type="number" name="price" id="p_price" step="1" min="0" required style="width:120px;"> $</td></tr>
                        <tr><th>原價</th><td><input type="number" name="original_price" id="p_original_price" step="1" min="0" style="width:120px;"> $</td></tr>
                        <tr><th>圖片</th><td><input type="url" name="image" id="p_image" class="regular-text"> <button type="button" class="button" onclick="selectImg('p_image')">選擇</button><div id="p_image_preview" style="margin-top:5px;"></div></td></tr>
                        <tr><th>庫存</th><td><input type="number" name="stock" id="p_stock" value="999" min="0" style="width:80px;"></td></tr>
                        <tr><th>已售</th><td><input type="number" name="sales" id="p_sales" value="0" min="0" style="width:80px;"></td></tr>
                        <tr><th>排序</th><td><input type="number" name="sort_order" id="p_sort_order" value="0" style="width:80px;"></td></tr>
                        <tr><th>狀態</th><td><select name="status" id="p_status"><option value="publish">上架</option><option value="draft">下架</option></select></td></tr>
                    </table>
                    <p style="margin-top:20px;"><button type="submit" class="button button-primary">保存</button> <button type="button" class="button" onclick="closeProductModal()">取消</button></p>
                </form>
            </div>
        </div>
        <?php $this->render_admin_scripts('product'); ?>
        <?php
    }

    // ========== 分類管理頁面 ==========
    public function render_categories_page() {
        $categories = self::get_categories();
        ?>
        <div class="wrap">
            <h1>商品分類 <button class="page-title-action" onclick="openCategoryModal()">新增分類</button></h1>
            
            <table class="wp-list-table widefat fixed striped" style="max-width:600px;margin-top:20px;">
                <thead><tr><th width="60">圖標</th><th>名稱</th><th width="60">排序</th><th width="100">操作</th></tr></thead>
                <tbody>
                <?php if (empty($categories)): ?>
                    <tr><td colspan="4">暫無分類</td></tr>
                <?php else: foreach ($categories as $cat): ?>
                    <tr>
                        <td><?php if ($cat->icon): ?><img src="<?php echo esc_url($cat->icon); ?>" style="width:40px;height:40px;object-fit:cover;"><?php else: ?>-<?php endif; ?></td>
                        <td><strong><?php echo esc_html($cat->name); ?></strong></td>
                        <td><?php echo $cat->sort_order; ?></td>
                        <td><a href="#" onclick="editCategory(<?php echo $cat->id; ?>);return false;">編輯</a> | <a href="#" onclick="deleteCategory(<?php echo $cat->id; ?>);return false;" style="color:#dc3232;">刪除</a></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- 分類彈窗 -->
        <div id="categoryModal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);z-index:100000;">
            <div style="background:#fff;width:450px;max-width:90%;margin:100px auto;border-radius:8px;box-shadow:0 5px 30px rgba(0,0,0,.3);">
                <div style="padding:15px 20px;border-bottom:1px solid #ddd;display:flex;justify-content:space-between;align-items:center;">
                    <h2 style="margin:0;" id="categoryModalTitle">新增分類</h2>
                    <button onclick="closeCategoryModal()" style="background:none;border:none;font-size:24px;cursor:pointer;">&times;</button>
                </div>
                <form id="categoryForm" style="padding:20px;">
                    <input type="hidden" name="id" id="c_id">
                    <table class="form-table" style="margin:0;">
                        <tr><th style="width:80px;">名稱 *</th><td><input type="text" name="name" id="c_name" class="regular-text" required></td></tr>
                        <tr><th>圖標</th><td><input type="url" name="icon" id="c_icon" class="regular-text"> <button type="button" class="button" onclick="selectImg('c_icon')">選擇</button></td></tr>
                        <tr><th>排序</th><td><input type="number" name="sort_order" id="c_sort_order" value="0" style="width:80px;"></td></tr>
                    </table>
                    <p style="margin-top:20px;"><button type="submit" class="button button-primary">保存</button> <button type="button" class="button" onclick="closeCategoryModal()">取消</button></p>
                </form>
            </div>
        </div>
        <?php $this->render_admin_scripts('category'); ?>
        <?php
    }
    
    // ========== 輪播圖管理頁面 ==========
    public function render_banners_page() {
        global $wpdb;
        $banners = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}oip_banners ORDER BY sort_order ASC, id ASC");
        ?>
        <div class="wrap">
            <h1>輪播圖管理 <button class="page-title-action" onclick="openBannerModal()">新增輪播圖</button></h1>
            
            <table class="wp-list-table widefat fixed striped" style="max-width:800px;margin-top:20px;">
                <thead><tr><th width="150">圖片</th><th>標題</th><th width="60">排序</th><th width="60">狀態</th><th width="100">操作</th></tr></thead>
                <tbody>
                <?php if (empty($banners)): ?>
                    <tr><td colspan="5">暫無輪播圖</td></tr>
                <?php else: foreach ($banners as $b): ?>
                    <tr>
                        <td><img src="<?php echo esc_url($b->image); ?>" style="width:140px;height:50px;object-fit:cover;"></td>
                        <td><?php echo esc_html($b->title ?: '-'); ?></td>
                        <td><?php echo $b->sort_order; ?></td>
                        <td><?php echo $b->status ? '<span style="color:green;">啟用</span>' : '<span style="color:#999;">停用</span>'; ?></td>
                        <td><a href="#" onclick="editBanner(<?php echo $b->id; ?>);return false;">編輯</a> | <a href="#" onclick="deleteBanner(<?php echo $b->id; ?>);return false;" style="color:#dc3232;">刪除</a></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- 輪播圖彈窗 -->
        <div id="bannerModal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);z-index:100000;">
            <div style="background:#fff;width:500px;max-width:90%;margin:100px auto;border-radius:8px;box-shadow:0 5px 30px rgba(0,0,0,.3);">
                <div style="padding:15px 20px;border-bottom:1px solid #ddd;display:flex;justify-content:space-between;align-items:center;">
                    <h2 style="margin:0;" id="bannerModalTitle">新增輪播圖</h2>
                    <button onclick="closeBannerModal()" style="background:none;border:none;font-size:24px;cursor:pointer;">&times;</button>
                </div>
                <form id="bannerForm" style="padding:20px;">
                    <input type="hidden" name="id" id="b_id">
                    <table class="form-table" style="margin:0;">
                        <tr><th style="width:80px;">標題</th><td><input type="text" name="title" id="b_title" class="regular-text"></td></tr>
                        <tr><th>圖片 *</th><td><input type="url" name="image" id="b_image" class="regular-text" required> <button type="button" class="button" onclick="selectImg('b_image')">選擇</button><div id="b_image_preview" style="margin-top:5px;"></div></td></tr>
                        <tr><th>連結</th><td><input type="url" name="link" id="b_link" class="regular-text" placeholder="點擊跳轉網址"></td></tr>
                        <tr><th>排序</th><td><input type="number" name="sort_order" id="b_sort_order" value="0" style="width:80px;"></td></tr>
                        <tr><th>狀態</th><td><select name="status" id="b_status"><option value="1">啟用</option><option value="0">停用</option></select></td></tr>
                    </table>
                    <p style="margin-top:20px;"><button type="submit" class="button button-primary">保存</button> <button type="button" class="button" onclick="closeBannerModal()">取消</button></p>
                </form>
            </div>
        </div>
        <?php $this->render_admin_scripts('banner'); ?>
        <?php
    }

    // ========== 管理腳本 ==========
    private function render_admin_scripts($type) {
        $nonce = wp_create_nonce('oip_admin_nonce');
        ?>
        <script>
        var oipNonce = '<?php echo $nonce; ?>';
        
        function selectImg(inputId) {
            var uploader = wp.media({title:'選擇圖片',button:{text:'使用此圖片'},multiple:false});
            uploader.on('select', function() {
                var url = uploader.state().get('selection').first().toJSON().url;
                document.getElementById(inputId).value = url;
                var preview = document.getElementById(inputId + '_preview');
                if (preview) preview.innerHTML = '<img src="' + url + '" style="max-width:150px;">';
            });
            uploader.open();
        }
        
        <?php if ($type === 'product'): ?>
        function openProductModal(id) {
            document.getElementById('productModalTitle').textContent = id ? '編輯商品' : '新增商品';
            document.getElementById('productForm').reset();
            document.getElementById('p_id').value = '';
            document.getElementById('p_image_preview').innerHTML = '';
            document.getElementById('productModal').style.display = 'block';
        }
        function closeProductModal() { document.getElementById('productModal').style.display = 'none'; }
        
        function editProduct(id) {
            fetch(ajaxurl + '?action=oip_get_product&id=' + id + '&nonce=' + oipNonce)
                .then(r => r.json()).then(res => {
                    if (res.success && res.data) {
                        var p = res.data;
                        document.getElementById('p_id').value = p.id;
                        document.getElementById('p_name').value = p.name || '';
                        document.getElementById('p_category_id').value = p.category_id || 0;
                        document.getElementById('p_price').value = p.price || '';
                        document.getElementById('p_original_price').value = p.original_price || '';
                        document.getElementById('p_image').value = p.image || '';
                        document.getElementById('p_stock').value = p.stock || 999;
                        document.getElementById('p_sales').value = p.sales || 0;
                        document.getElementById('p_sort_order').value = p.sort_order || 0;
                        document.getElementById('p_status').value = p.status || 'publish';
                        document.getElementById('p_image_preview').innerHTML = p.image ? '<img src="' + p.image + '" style="max-width:150px;">' : '';
                        document.getElementById('productModalTitle').textContent = '編輯商品';
                        document.getElementById('productModal').style.display = 'block';
                    }
                });
        }
        
        function deleteProduct(id) {
            if (!confirm('確定刪除此商品？')) return;
            fetch(ajaxurl, {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=oip_delete_product&id=' + id + '&nonce=' + oipNonce})
                .then(r => r.json()).then(res => { if (res.success) location.reload(); else alert('刪除失敗'); });
        }
        
        document.getElementById('productForm').addEventListener('submit', function(e) {
            e.preventDefault();
            var fd = new FormData(this);
            fd.append('action', 'oip_save_product');
            fd.append('nonce', oipNonce);
            fetch(ajaxurl, {method:'POST',body:fd}).then(r => r.json()).then(res => {
                if (res.success) location.reload(); else alert('保存失敗');
            });
        });
        <?php endif; ?>
        
        <?php if ($type === 'category'): ?>
        function openCategoryModal() {
            document.getElementById('categoryModalTitle').textContent = '新增分類';
            document.getElementById('categoryForm').reset();
            document.getElementById('c_id').value = '';
            document.getElementById('categoryModal').style.display = 'block';
        }
        function closeCategoryModal() { document.getElementById('categoryModal').style.display = 'none'; }
        
        function editCategory(id) {
            fetch(ajaxurl + '?action=oip_get_category&id=' + id + '&nonce=' + oipNonce)
                .then(r => r.json()).then(res => {
                    if (res.success && res.data) {
                        var c = res.data;
                        document.getElementById('c_id').value = c.id;
                        document.getElementById('c_name').value = c.name || '';
                        document.getElementById('c_icon').value = c.icon || '';
                        document.getElementById('c_sort_order').value = c.sort_order || 0;
                        document.getElementById('categoryModalTitle').textContent = '編輯分類';
                        document.getElementById('categoryModal').style.display = 'block';
                    }
                });
        }
        
        function deleteCategory(id) {
            if (!confirm('確定刪除此分類？')) return;
            fetch(ajaxurl, {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=oip_delete_category&id=' + id + '&nonce=' + oipNonce})
                .then(r => r.json()).then(res => { if (res.success) location.reload(); else alert('刪除失敗'); });
        }
        
        document.getElementById('categoryForm').addEventListener('submit', function(e) {
            e.preventDefault();
            var fd = new FormData(this);
            fd.append('action', 'oip_save_category');
            fd.append('nonce', oipNonce);
            fetch(ajaxurl, {method:'POST',body:fd}).then(r => r.json()).then(res => {
                if (res.success) location.reload(); else alert('保存失敗');
            });
        });
        <?php endif; ?>
        
        <?php if ($type === 'banner'): ?>
        function openBannerModal() {
            document.getElementById('bannerModalTitle').textContent = '新增輪播圖';
            document.getElementById('bannerForm').reset();
            document.getElementById('b_id').value = '';
            document.getElementById('b_image_preview').innerHTML = '';
            document.getElementById('bannerModal').style.display = 'block';
        }
        function closeBannerModal() { document.getElementById('bannerModal').style.display = 'none'; }
        
        function editBanner(id) {
            fetch(ajaxurl + '?action=oip_get_banner&id=' + id + '&nonce=' + oipNonce)
                .then(r => r.json()).then(res => {
                    if (res.success && res.data) {
                        var b = res.data;
                        document.getElementById('b_id').value = b.id;
                        document.getElementById('b_title').value = b.title || '';
                        document.getElementById('b_image').value = b.image || '';
                        document.getElementById('b_link').value = b.link || '';
                        document.getElementById('b_sort_order').value = b.sort_order || 0;
                        document.getElementById('b_status').value = b.status || 1;
                        document.getElementById('b_image_preview').innerHTML = b.image ? '<img src="' + b.image + '" style="max-width:200px;">' : '';
                        document.getElementById('bannerModalTitle').textContent = '編輯輪播圖';
                        document.getElementById('bannerModal').style.display = 'block';
                    }
                });
        }
        
        function deleteBanner(id) {
            if (!confirm('確定刪除此輪播圖？')) return;
            fetch(ajaxurl, {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=oip_delete_banner&id=' + id + '&nonce=' + oipNonce})
                .then(r => r.json()).then(res => { if (res.success) location.reload(); else alert('刪除失敗'); });
        }
        
        document.getElementById('bannerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            var fd = new FormData(this);
            fd.append('action', 'oip_save_banner');
            fd.append('nonce', oipNonce);
            fetch(ajaxurl, {method:'POST',body:fd}).then(r => r.json()).then(res => {
                if (res.success) location.reload(); else alert('保存失敗');
            });
        });
        <?php endif; ?>
        </script>
        <?php
    }
}
