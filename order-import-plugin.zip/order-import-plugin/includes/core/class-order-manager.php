<?php
if (!defined('ABSPATH')) {
    exit;
}

class OIP_Order_Manager {
    
    public static function maybe_create_table($force_recreate = false) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_orders';
        $charset_collate = $wpdb->get_charset_collate();
        
        // 強制重建表
        if ($force_recreate) {
            $wpdb->query("DROP TABLE IF EXISTS $table_name");
        }
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            order_number varchar(100) NOT NULL,
            recipient_name varchar(200) NOT NULL,
            recipient_address text NOT NULL,
            phone varchar(50) NOT NULL,
            email varchar(200) NOT NULL,
            product_name text NOT NULL,
            amount decimal(10,2) NOT NULL,
            user_id bigint(20) DEFAULT 0,
            source varchar(20) DEFAULT 'imported',
            status varchar(50) DEFAULT 'pending',
            email_sent tinyint(1) DEFAULT 0,
            email_sent_at datetime DEFAULT NULL,
            email_error text DEFAULT NULL,
            is_viewed tinyint(1) DEFAULT 0,
            viewed_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY order_number (order_number)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    public static function import_order($data, $send_email_now = false) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_orders';
        
        // 如果沒有訂單號或訂單號為空，自動生成
        if (!isset($data['order_number']) || trim($data['order_number']) === '') {
            $data['order_number'] = oip_generate_order_number();
        }
        
        $required = ['order_number', 'recipient_name', 'recipient_address', 'phone', 'email', 'product_name', 'amount'];
        foreach ($required as $field) {
            if (!isset($data[$field]) || trim($data[$field]) === '') {
                return new WP_Error('missing_field', "缺少必填字段: $field (收到的欄位: " . implode(', ', array_keys($data)) . ")");
            }
        }
        
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table_name WHERE order_number = %s",
            $data['order_number']
        ));
        
        if ($exists) {
            // 如果訂單號重複，重新生成一個
            $data['order_number'] = oip_generate_order_number();
        }
        
        $user_id = OIP_User_Manager::get_or_create_user($data['email'], $data['recipient_name']);
        
        if (is_wp_error($user_id)) {
            return $user_id;
        }
        
        self::maybe_create_table();
        
        // 設置訂單來源（默認為 imported，除非明確指定為 online）
        $source = isset($data['source']) ? $data['source'] : 'imported';
        
        // 直接用 SQL 插入
        $sql = $wpdb->prepare(
            "INSERT INTO $table_name (order_number, recipient_name, recipient_address, phone, email, product_name, amount, user_id, source, status, email_sent, created_at) VALUES (%s, %s, %s, %s, %s, %s, %f, %d, %s, %s, %d, %s)",
            sanitize_text_field($data['order_number']),
            sanitize_text_field($data['recipient_name']),
            sanitize_textarea_field($data['recipient_address']),
            sanitize_text_field($data['phone']),
            sanitize_email($data['email']),
            sanitize_textarea_field($data['product_name']),
            floatval($data['amount']),
            $user_id,
            $source,
            'confirmed',
            0,
            current_time('mysql')
        );
        
        $result = $wpdb->query($sql);
        
        if ($result === false) {
            return new WP_Error('db_error', '數據庫插入失敗: ' . $wpdb->last_error);
        }
        
        $order_id = $wpdb->insert_id;
        
        // 單筆導入時立即發送郵件，批量導入時由 cron 異步處理
        if ($send_email_now) {
            // 从数据库读取完整的订单数据（包含 created_at）
            $order = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table_name WHERE id = %d",
                $order_id
            ));
            
            if ($order) {
                $data['created_at'] = $order->created_at;
                $email_sent = OIP_Email_Sender::send_order_confirmation($data);
                self::update_email_status($order_id, $email_sent);
            }
        }
        
        return $order_id;
    }
    
    public static function update_email_status($order_id, $success, $error_message = '') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_orders';
        
        $wpdb->update(
            $table_name,
            [
                'email_sent' => $success ? 1 : 0,
                'email_sent_at' => $success ? current_time('mysql') : null,
                'email_error' => $success ? null : $error_message
            ],
            ['id' => $order_id]
        );
    }
    
    public static function resend_email($order_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_orders';
        
        $order = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE id = %d",
            $order_id
        ));
        
        if (!$order) {
            return '訂單不存在';
        }
        
        $data = [
            'order_number' => $order->order_number,
            'recipient_name' => $order->recipient_name,
            'recipient_address' => $order->recipient_address,
            'phone' => $order->phone,
            'email' => $order->email,
            'product_name' => $order->product_name,
            'amount' => $order->amount,
            'created_at' => $order->created_at
        ];
        
        $result = OIP_Email_Sender::send_order_confirmation($data);
        
        if ($result) {
            self::update_email_status($order_id, true);
            return true;
        } else {
            self::update_email_status($order_id, false, '郵件發送失敗');
            return '郵件發送失敗，請檢查SMTP設置';
        }
    }
    
    public static function delete_order($order_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_orders';
        return $wpdb->delete($table_name, ['id' => $order_id], ['%d']);
    }
    
    /**
     * 從 Excel 文件導入（異步版本，導入後不立即發郵件）
     */
    public static function import_from_excel_async($file_path) {
        $results = ['success' => 0, 'failed' => 0, 'errors' => []];
        
        $zip = new ZipArchive();
        if ($zip->open($file_path) !== true) {
            $results['errors'][] = '無法打開 Excel 文件';
            return $results;
        }
        
        // 讀取共享字符串
        $shared_strings = [];
        $shared_xml = $zip->getFromName('xl/sharedStrings.xml');
        if ($shared_xml) {
            $xml = simplexml_load_string($shared_xml);
            foreach ($xml->si as $si) {
                $shared_strings[] = (string)$si->t;
            }
        }
        
        // 讀取工作表
        $sheet_xml = $zip->getFromName('xl/worksheets/sheet1.xml');
        $zip->close();
        
        if (!$sheet_xml) {
            $results['errors'][] = '無法讀取工作表';
            return $results;
        }
        
        $xml = simplexml_load_string($sheet_xml);
        $rows = [];
        
        foreach ($xml->sheetData->row as $row) {
            $row_data = [];
            foreach ($row->c as $cell) {
                $value = '';
                if (isset($cell->v)) {
                    $value = (string)$cell->v;
                    if (isset($cell['t']) && (string)$cell['t'] === 's') {
                        $value = $shared_strings[(int)$value] ?? '';
                    }
                }
                $row_data[] = $value;
            }
            $rows[] = $row_data;
        }
        
        if (count($rows) < 2) {
            $results['errors'][] = 'Excel 文件沒有數據';
            return $results;
        }
        
        $header = array_shift($rows);
        $header = array_map('trim', $header);
        
        foreach ($rows as $row_num => $row) {
            if (count($row) < count($header)) {
                $row = array_pad($row, count($header), '');
            }
            
            $data = array_combine($header, array_map('trim', $row));
            
            // 跳過空行（檢查收件人是否為空）
            if (empty($data['recipient_name'])) continue;
            
            // 不立即發送郵件，由 cron 處理
            $result = self::import_order($data, false);
            
            if (is_wp_error($result)) {
                $results['failed']++;
                $results['errors'][] = '第' . ($row_num + 2) . '行: ' . $result->get_error_message();
            } else {
                $results['success']++;
            }
        }
        
        return $results;
    }
    
    /**
     * 從 Excel 文件導入
     */
    public static function import_from_excel($file_path) {
        $results = ['success' => 0, 'failed' => 0, 'errors' => []];
        
        $zip = new ZipArchive();
        if ($zip->open($file_path) !== true) {
            $results['errors'][] = '無法打開 Excel 文件';
            return $results;
        }
        
        // 讀取共享字符串
        $shared_strings = [];
        $shared_xml = $zip->getFromName('xl/sharedStrings.xml');
        if ($shared_xml) {
            $xml = simplexml_load_string($shared_xml);
            foreach ($xml->si as $si) {
                $shared_strings[] = (string)$si->t;
            }
        }
        
        // 讀取工作表
        $sheet_xml = $zip->getFromName('xl/worksheets/sheet1.xml');
        $zip->close();
        
        if (!$sheet_xml) {
            $results['errors'][] = '無法讀取工作表';
            return $results;
        }
        
        $xml = simplexml_load_string($sheet_xml);
        $rows = [];
        
        foreach ($xml->sheetData->row as $row) {
            $row_data = [];
            foreach ($row->c as $cell) {
                $value = '';
                if (isset($cell->v)) {
                    $value = (string)$cell->v;
                    // 如果是共享字符串
                    if (isset($cell['t']) && (string)$cell['t'] === 's') {
                        $value = $shared_strings[(int)$value] ?? '';
                    }
                }
                $row_data[] = $value;
            }
            $rows[] = $row_data;
        }
        
        if (count($rows) < 2) {
            $results['errors'][] = 'Excel 文件沒有數據';
            return $results;
        }
        
        // 第一行是表頭
        $header = array_shift($rows);
        $header = array_map('trim', $header);
        
        foreach ($rows as $row_num => $row) {
            if (count($row) < count($header)) {
                $row = array_pad($row, count($header), '');
            }
            
            $data = array_combine($header, array_map('trim', $row));
            
            // 跳過空行（檢查收件人是否為空）
            if (empty($data['recipient_name'])) continue;
            
            $result = self::import_order($data);
            
            if (is_wp_error($result)) {
                $results['failed']++;
                $results['errors'][] = '第' . ($row_num + 2) . '行: ' . $result->get_error_message();
            } else {
                $results['success']++;
            }
        }
        
        return $results;
    }
    
    public static function import_from_csv($file_path) {
        $results = ['success' => 0, 'failed' => 0, 'errors' => []];
        
        // 讀取整個文件內容
        $content = file_get_contents($file_path);
        
        // 移除 BOM
        if (substr($content, 0, 3) === "\xEF\xBB\xBF") {
            $content = substr($content, 3);
        }
        
        // 檢測是否包含高位字節（非ASCII）
        $has_high_bytes = preg_match('/[\x80-\xFF]/', $content);
        
        if ($has_high_bytes) {
            // 檢查是否是有效的 UTF-8
            $is_valid_utf8 = preg_match('//u', $content);
            
            if (!$is_valid_utf8) {
                // 不是有效 UTF-8，嘗試從 GBK 轉換
                $converted = @iconv('GBK', 'UTF-8//IGNORE', $content);
                if ($converted !== false) {
                    $content = $converted;
                    $results['encoding'] = '已從 GBK 轉換為 UTF-8';
                } else {
                    // 嘗試 GB18030
                    $converted = @iconv('GB18030', 'UTF-8//IGNORE', $content);
                    if ($converted !== false) {
                        $content = $converted;
                        $results['encoding'] = '已從 GB18030 轉換為 UTF-8';
                    }
                }
            }
        }
        
        // 統一換行符
        $content = str_replace(["\r\n", "\r"], "\n", $content);
        
        // 分割行
        $lines = explode("\n", trim($content));
        
        if (count($lines) < 2) {
            $results['failed']++;
            $results['errors'][] = 'CSV文件格式錯誤或沒有數據';
            return $results;
        }
        
        // 解析表頭
        $header_line = array_shift($lines);
        $header = str_getcsv($header_line);
        $header = array_map('trim', $header);
        
        // 記錄表頭用於調試
        $results['debug_header'] = $header;
        
        foreach ($lines as $line_num => $line) {
            if (empty(trim($line))) continue;
            
            $row = str_getcsv($line);
            
            if (count($row) !== count($header)) {
                $results['failed']++;
                $results['errors'][] = '第' . ($line_num + 2) . '行：列數不匹配 (期望' . count($header) . '列，實際' . count($row) . '列)';
                continue;
            }
            
            $data = array_combine($header, array_map('trim', $row));
            
            $result = self::import_order($data);
            
            if (is_wp_error($result)) {
                $results['failed']++;
                $results['errors'][] = ($data['order_number'] ?? '未知') . ': ' . $result->get_error_message();
            } else {
                $results['success']++;
            }
        }
        
        return $results;
    }
    
    public static function get_user_orders($user_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_orders';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name WHERE user_id = %d ORDER BY created_at DESC",
            $user_id
        ));
    }
    
    public static function get_all_orders($page = 1, $per_page = 20, $viewed_filter = '') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_orders';
        $offset = ($page - 1) * $per_page;
        
        $where = '';
        if ($viewed_filter === 'viewed') {
            $where = 'WHERE is_viewed = 1';
        } elseif ($viewed_filter === 'not_viewed') {
            $where = 'WHERE is_viewed = 0';
        }
        
        $orders = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name $where ORDER BY created_at DESC LIMIT %d OFFSET %d",
            $per_page, $offset
        ));
        
        $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where");
        
        return [
            'orders' => $orders,
            'total' => $total,
            'pages' => ceil($total / $per_page)
        ];
    }
    
    public static function get_order($order_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_orders';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE id = %d",
            $order_id
        ));
    }
    
    /**
     * 標記訂單為已查看
     */
    public static function mark_as_viewed($order_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_orders';
        
        return $wpdb->update(
            $table_name,
            [
                'is_viewed' => 1,
                'viewed_at' => current_time('mysql')
            ],
            ['id' => $order_id],
            ['%d', '%s'],
            ['%d']
        );
    }
    
    /**
     * 根據訂單號獲取訂單
     */
    public static function get_order_by_number($order_number) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_orders';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE order_number = %s",
            $order_number
        ));
    }
}
