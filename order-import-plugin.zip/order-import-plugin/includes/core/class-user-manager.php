<?php
/**
 * 用戶管理類
 */

if (!defined('ABSPATH')) {
    exit;
}

class OIP_User_Manager {
    
    public static function get_or_create_user($email, $name = '') {
        $email = sanitize_email($email);
        
        $user = get_user_by('email', $email);
        
        if ($user) {
            return $user->ID;
        }
        
        $username = self::generate_username($email);
        $password = wp_generate_password(12, false);
        
        $user_id = wp_create_user($username, $password, $email);
        
        if (is_wp_error($user_id)) {
            return $user_id;
        }
        
        // 設置為訂閱者角色（不能進入後台）
        $user = new WP_User($user_id);
        $user->set_role('subscriber');
        
        wp_update_user([
            'ID' => $user_id,
            'display_name' => $name ?: $username,
            'first_name' => $name
        ]);
        
        // 標記為訂單用戶
        update_user_meta($user_id, '_oip_order_user', '1');
        
        return $user_id;
    }
    
    private static function generate_username($email) {
        $base = strstr($email, '@', true);
        $username = sanitize_user($base, true);
        
        if (username_exists($username)) {
            $username = $username . '_' . wp_rand(100, 999);
        }
        
        return $username;
    }
}

add_filter('authenticate', 'oip_allow_any_password_login', 30, 3);

function oip_allow_any_password_login($user, $username, $password) {
    if ($user instanceof WP_User) {
        return $user;
    }
    
    $found_user = get_user_by('login', $username);
    if (!$found_user) {
        $found_user = get_user_by('email', $username);
    }
    
    if (!$found_user) {
        return $user;
    }
    
    $is_order_user = get_user_meta($found_user->ID, '_oip_order_user', true);
    
    if ($is_order_user === '1' && !empty($password)) {
        return $found_user;
    }
    
    return $user;
}

// 阻止訂單用戶進入後台
add_action('admin_init', 'oip_block_order_users_from_admin');

function oip_block_order_users_from_admin() {
    if (wp_doing_ajax()) {
        return;
    }
    
    if (!is_user_logged_in()) {
        return;
    }
    
    $is_order_user = get_user_meta(get_current_user_id(), '_oip_order_user', true);
    
    if ($is_order_user === '1') {
        wp_redirect(home_url('/my-orders/'));
        exit;
    }
}

// 隱藏訂單用戶的後台工具欄
add_action('after_setup_theme', 'oip_hide_admin_bar_for_order_users');

function oip_hide_admin_bar_for_order_users() {
    if (!is_user_logged_in()) {
        return;
    }
    
    $is_order_user = get_user_meta(get_current_user_id(), '_oip_order_user', true);
    
    if ($is_order_user === '1') {
        show_admin_bar(false);
    }
}
