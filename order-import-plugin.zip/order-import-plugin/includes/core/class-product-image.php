<?php
/**
 * 商品圖片管理
 */

if (!defined('ABSPATH')) {
    exit;
}

class OIP_Product_Image {
    
    private $option_name = 'oip_product_images';
    
    public function __construct() {
        add_action('admin_menu', [$this, 'add_menu_page']);
        add_action('admin_init', [$this, 'handle_actions']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_media']);
    }
    
    public function add_menu_page() {
        add_submenu_page(
            'order-import',
            '商品圖片',
            '商品圖片',
            'manage_options',
            'order-import-product-images',
            [$this, 'render_page']
        );
    }
    
    public function enqueue_media($hook) {
        if (strpos($hook, 'order-import-product-images') !== false) {
            wp_enqueue_media();
        }
    }
    
    public function handle_actions() {
        if (!current_user_can('manage_options')) return;
        
        // 新增商品圖片
        if (isset($_POST['oip_add_product_image']) && wp_verify_nonce($_POST['_wpnonce'], 'oip_product_image')) {
            $name = sanitize_text_field($_POST['product_name']);
            $image = esc_url_raw($_POST['product_image']);
            if (!empty($name) && !empty($image)) {
                $images = $this->get_all();
                $images[$name] = $image;
                update_option($this->option_name, $images);
                wp_redirect(admin_url('admin.php?page=order-import-product-images&msg=added'));
                exit;
            }
        }
        
        // 刪除商品圖片
        if (isset($_GET['delete_product']) && wp_verify_nonce($_GET['_wpnonce'], 'delete_product_image')) {
            $name = sanitize_text_field($_GET['delete_product']);
            $images = $this->get_all();
            if (isset($images[$name])) {
                unset($images[$name]);
                update_option($this->option_name, $images);
            }
            wp_redirect(admin_url('admin.php?page=order-import-product-images&msg=deleted'));
            exit;
        }
    }
    
    public static function get_all() {
        return get_option('oip_product_images', []);
    }
    
    public static function get_image($product_name, $source = 'imported') {
        global $wpdb;
        
        // 如果是網站下單，直接從產品表中查找（精確匹配商品名稱）
        if ($source === 'online') {
            // 處理訂單中可能包含數量的情況（如 "商品名 x2"）
            // 先去除數量後綴
            $clean_name = preg_replace('/\s+x\d+$/i', '', trim($product_name));
            
            // 從產品表查找
            $product = $wpdb->get_row($wpdb->prepare(
                "SELECT image FROM {$wpdb->prefix}oip_products WHERE name = %s",
                $clean_name
            ));
            
            if ($product && !empty($product->image)) {
                return $product->image;
            }
            
            // 如果找不到，返回空（客戶下單的商品一定在產品表中）
            return '';
        }
        
        // 以下是導入訂單的邏輯（從商品圖片設置中模糊匹配）
        $images = self::get_all();
        
        // 精確匹配
        if (isset($images[$product_name])) {
            return $images[$product_name];
        }
        
        // 模糊匹配（商品名稱包含關鍵字）
        foreach ($images as $name => $url) {
            if (stripos($product_name, $name) !== false || stripos($name, $product_name) !== false) {
                return $url;
            }
        }
        
        return '';
    }
    
    public function render_page() {
        $images = $this->get_all();
        $msg = $_GET['msg'] ?? '';
        ?>
        <div class="wrap">
            <h1>商品圖片管理</h1>
            
            <?php if ($msg === 'added'): ?>
                <div class="notice notice-success"><p>商品圖片已新增！</p></div>
            <?php elseif ($msg === 'deleted'): ?>
                <div class="notice notice-success"><p>商品圖片已刪除！</p></div>
            <?php endif; ?>
            
            <p>設定商品名稱與圖片的對應關係，訂單頁面和郵件會自動顯示對應的商品圖片。</p>
            
            <div style="background:#fff3cd;border:1px solid #ffc107;border-radius:4px;padding:15px;margin-bottom:20px;max-width:800px;">
                <p style="margin:0 0 10px;font-weight:600;color:#856404;">📌 匹配規則說明：</p>
                <ul style="margin:0;padding-left:20px;color:#856404;">
                    <li><strong>精確匹配：</strong>商品名稱完全相同時優先匹配</li>
                    <li><strong>模糊匹配：</strong>訂單商品名稱「包含」設定的關鍵字即可匹配</li>
                </ul>
                <p style="margin:10px 0 0;color:#856404;font-size:13px;">
                    <strong>範例：</strong>設定「面膜」→ 可匹配「玻尿酸保濕面膜」、「美白面膜」、「蝸牛面膜組合」等<br>
                    <strong>範例：</strong>設定「精華液」→ 可匹配「玻尿酸精華液」、「美白精華液30ml」等
                </p>
            </div>
            
            <h2>新增商品圖片</h2>
            <form method="post" style="background:#fff;padding:20px;border:1px solid #ccc;margin-bottom:20px;max-width:600px;">
                <?php wp_nonce_field('oip_product_image'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="product_name">商品名稱</label></th>
                        <td><input type="text" name="product_name" id="product_name" class="regular-text" required placeholder="例如：玻尿酸面膜"></td>
                    </tr>
                    <tr>
                        <th><label for="product_image">商品圖片</label></th>
                        <td>
                            <input type="url" name="product_image" id="product_image" class="regular-text" required placeholder="https://...">
                            <button type="button" class="button" id="upload_image_btn">選擇圖片</button>
                            <p class="description">建議使用正方形圖片（如 300x300），系統會自動選擇適合的尺寸</p>
                            <div id="image_preview" style="margin-top:10px;"></div>
                        </td>
                    </tr>
                </table>
                <p><button type="submit" name="oip_add_product_image" class="button button-primary">新增商品圖片</button></p>
            </form>
            
            <h2>已設定的商品圖片</h2>
            <?php if (empty($images)): ?>
                <p>尚未設定任何商品圖片。</p>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped" style="max-width:800px;">
                    <thead>
                        <tr>
                            <th style="width:60px;">圖片</th>
                            <th>商品名稱</th>
                            <th>圖片網址</th>
                            <th style="width:80px;">操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($images as $name => $url): ?>
                        <tr>
                            <td><img src="<?php echo esc_url($url); ?>" style="width:50px;height:50px;object-fit:cover;border-radius:4px;"></td>
                            <td><strong><?php echo esc_html($name); ?></strong></td>
                            <td><code style="font-size:11px;word-break:break-all;"><?php echo esc_html($url); ?></code></td>
                            <td>
                                <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=order-import-product-images&delete_product=' . urlencode($name)), 'delete_product_image'); ?>" 
                                   class="button button-small" 
                                   onclick="return confirm('確定要刪除此商品圖片嗎？');">刪除</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            var mediaUploader;
            $('#upload_image_btn').click(function(e) {
                e.preventDefault();
                if (mediaUploader) {
                    mediaUploader.open();
                    return;
                }
                mediaUploader = wp.media({
                    title: '選擇商品圖片',
                    button: { text: '使用此圖片' },
                    multiple: false
                });
                mediaUploader.on('select', function() {
                    var attachment = mediaUploader.state().get('selection').first().toJSON();
                    // 優先使用 medium 尺寸，如果沒有則用原圖
                    var imageUrl = attachment.sizes && attachment.sizes.medium ? attachment.sizes.medium.url : attachment.url;
                    $('#product_image').val(imageUrl);
                    $('#image_preview').html('<img src="' + imageUrl + '" style="max-width:150px;max-height:150px;border-radius:4px;">');
                });
                mediaUploader.open();
            });
            
            $('#product_image').on('change keyup', function() {
                var url = $(this).val();
                if (url) {
                    $('#image_preview').html('<img src="' + url + '" style="max-width:150px;max-height:150px;border-radius:4px;" onerror="this.style.display=\'none\'">');
                } else {
                    $('#image_preview').html('');
                }
            });
        });
        </script>
        <?php
    }
}
