<?php
/**
 * 郵件發送類 - 響應式設計
 */

if (!defined('ABSPATH')) {
    exit;
}

class OIP_Email_Sender {
    
    public static function send_order_confirmation($order_data) {
        $settings = OIP_Email_Template::get_settings();
        
        $to = $order_data['email'];
        $subject = self::replace_variables($settings['subject'], $order_data);
        
        $message = self::get_email_template($order_data, $settings);
        
        $site_name = get_bloginfo('name');
        $admin_email = get_option('admin_email');
        
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $site_name . ' <' . $admin_email . '>',
            'Reply-To: ' . $admin_email,
            'X-Mailer: WordPress/' . get_bloginfo('version'),
            'MIME-Version: 1.0',
            'List-Unsubscribe: <mailto:' . $admin_email . '?subject=unsubscribe>'
        ];
        
        return wp_mail($to, $subject, $message, $headers);
    }
    
    private static function replace_variables($text, $order_data) {
        $replacements = [
            '{order_number}' => $order_data['order_number'] ?? '',
            '{recipient_name}' => $order_data['recipient_name'] ?? '顧客',
            '{email}' => $order_data['email'] ?? '',
            '{site_name}' => get_bloginfo('name'),
            '{site_url}' => home_url()
        ];
        
        return str_replace(array_keys($replacements), array_values($replacements), $text);
    }
    
    private static function get_product_image_html($product_name) {
        $image_url = OIP_Product_Image::get_image($product_name);
        if (!empty($image_url)) {
            $base64 = self::url_to_base64($image_url);
            if ($base64) {
                return '<img src="' . $base64 . '" alt="" style="width:60px;height:60px;object-fit:cover;border-radius:4px;vertical-align:middle;margin-right:10px;">';
            }
            return '<img src="' . esc_url($image_url) . '" alt="" style="width:60px;height:60px;object-fit:cover;border-radius:4px;vertical-align:middle;margin-right:10px;">';
        }
        return '';
    }
    
    private static function url_to_base64($url) {
        $upload_dir = wp_upload_dir();
        $upload_url = $upload_dir['baseurl'];
        $upload_path = $upload_dir['basedir'];
        
        if (strpos($url, $upload_url) === 0) {
            $file_path = str_replace($upload_url, $upload_path, $url);
            if (file_exists($file_path)) {
                $image_data = file_get_contents($file_path);
                $mime_type = mime_content_type($file_path);
                return 'data:' . $mime_type . ';base64,' . base64_encode($image_data);
            }
        }
        
        $response = wp_remote_get($url, ['timeout' => 10]);
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $image_data = wp_remote_retrieve_body($response);
            $content_type = wp_remote_retrieve_header($response, 'content-type');
            if ($image_data && $content_type) {
                return 'data:' . $content_type . ';base64,' . base64_encode($image_data);
            }
        }
        
        return false;
    }
    
    private static function get_email_template($order_data, $settings) {
        $site_name = get_bloginfo('name');
        $site_url = home_url();
        $main_color = !empty($settings['header_color']) ? $settings['header_color'] : '#ee4d2d';
        
        // 确保 created_at 存在，如果不存在使用当前时间
        if (empty($order_data['created_at'])) {
            $order_data['created_at'] = current_time('mysql');
        }
        
        // 使用訂單查詢頁面 URL（不需要登入）
        $order_search_url = home_url('/order-search/?email=' . urlencode($order_data['email']));
        $contact_url = home_url('/?oip_shop=contact');
        
        $order_number = $order_data['order_number'];
        $track_search_url = oip_get_tracking_url($order_number, $order_search_url, 'view_order');
        
        // 聯繫我們連結 - 優先使用設置的連結，否則使用預設
        $contact_link = !empty($settings['contact_link']) ? $settings['contact_link'] : $contact_url;
        $track_contact_url = oip_get_tracking_url($order_number, $contact_link, 'contact');
        
        $recipient_name = !empty($order_data['recipient_name']) ? $order_data['recipient_name'] : '顧客';
        $recipient_address = !empty($order_data['recipient_address']) ? $order_data['recipient_address'] : '未提供';
        $phone = !empty($order_data['phone']) ? $order_data['phone'] : '未提供';
        
        $header_title = self::replace_variables($settings['header_title'], $order_data);
        $greeting = self::replace_variables($settings['greeting'], $order_data);
        $intro_text = self::replace_variables($settings['intro_text'], $order_data);
        $closing_text = self::replace_variables($settings['closing_text'], $order_data);
        $footer_text = self::replace_variables($settings['footer_text'], $order_data);
        
        $footer_url_html = '';
        if ($settings['show_site_url'] === '1') {
            $footer_url_html = '<p style="margin-top:10px;"><a href="' . esc_url($site_url) . '" style="color:' . $main_color . ';text-decoration:none;">' . esc_html($site_url) . '</a></p>';
        }
        
        // 常見問題區塊
        $faq_html = '';
        if ($settings['show_faq'] === '1') {
            $faq_html = '
            <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:20px;border:1px solid #e0e0e0;border-radius:8px;overflow:hidden;">
                <tr><td style="background:#fafafa;padding:12px 15px;border-bottom:1px solid #e0e0e0;font-size:14px;color:#333;font-weight:600;">常見問題</td></tr>
                <tr><td style="padding:15px;">
                    <p style="margin:0 0 12px;"><strong style="color:#333;font-size:13px;">Q：我可以修改訂單嗎？</strong><br><span style="color:#666;font-size:12px;line-height:1.6;">A：訂單成立後如需修改收貨資訊，請於出貨前聯繫客服處理。</span></p>
                    <p style="margin:0 0 12px;"><strong style="color:#333;font-size:13px;">Q：什麼時候會收到商品？</strong><br><span style="color:#666;font-size:12px;line-height:1.6;">A：一般訂單會在 3-5 個工作天內送達。</span></p>
                    <p style="margin:0 0 12px;"><strong style="color:#333;font-size:13px;">Q：收到商品有問題怎麼辦？</strong><br><span style="color:#666;font-size:12px;line-height:1.6;">A：請於收貨後 7 天內聯繫客服，我們將協助您處理。</span></p>
                    <p style="margin:0;"><strong style="color:#333;font-size:13px;">Q：如何查詢訂單狀態？</strong><br><span style="color:#666;font-size:12px;line-height:1.6;">A：點擊上方「查看我的訂單」按鈕，即可直接查看您的所有訂單。</span></p>
                </td></tr>
            </table>';
        }

        $html = '<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="x-apple-disable-message-reformatting">
    <title>' . esc_html($header_title) . '</title>
    <!--[if mso]>
    <noscript>
        <xml>
            <o:OfficeDocumentSettings>
                <o:PixelsPerInch>96</o:PixelsPerInch>
            </o:OfficeDocumentSettings>
        </xml>
    </noscript>
    <![endif]-->
    <style type="text/css">
        body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
        table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
        img { -ms-interpolation-mode: bicubic; border: 0; height: auto; line-height: 100%; outline: none; text-decoration: none; }
        body { height: 100% !important; margin: 0 !important; padding: 0 !important; width: 100% !important; }
        a[x-apple-data-detectors] { color: inherit !important; text-decoration: none !important; font-size: inherit !important; font-family: inherit !important; font-weight: inherit !important; line-height: inherit !important; }
        @media only screen and (max-width: 620px) {
            .mobile-padding { padding: 15px !important; }
            .mobile-stack { display: block !important; width: 100% !important; }
            .mobile-center { text-align: center !important; }
            .mobile-btn { display: block !important; width: 100% !important; margin: 5px 0 !important; }
            .mobile-btn a { display: block !important; padding: 14px 20px !important; }
        }
    </style>
</head>
<body style="margin:0;padding:0;background-color:#f5f5f5;font-family:-apple-system,BlinkMacSystemFont,\'Microsoft JhengHei\',\'Segoe UI\',Roboto,Helvetica,Arial,sans-serif;">
    
    <!-- 預覽文字 -->
    <div style="display:none;font-size:1px;color:#f5f5f5;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;">
        訂單 ' . esc_html($order_data['order_number']) . ' 已成立，感謝您的訂購！
    </div>
    
    <!-- 外層容器 -->
    <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="background-color:#f5f5f5;">
        <tr>
            <td align="center" style="padding:20px 10px;">
                
                <!-- 主要內容區塊 -->
                <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;background-color:#ffffff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
                    
                    <!-- Header -->
                    <tr>
                        <td style="background:' . $main_color . ';padding:20px 25px;">
                            <table role="presentation" cellpadding="0" cellspacing="0" width="100%">
                                <tr>
                                    <td style="color:#ffffff;font-size:20px;font-weight:700;">' . esc_html($site_name) . '</td>
                                    <td style="text-align:right;color:rgba(255,255,255,0.9);font-size:12px;">訂單確認</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                    <!-- 訂單確認標題 -->
                    <tr>
                        <td style="padding:20px 25px 10px;" class="mobile-padding">
                            <h2 style="color:#333;font-size:20px;margin:0;font-weight:700;text-align:center;">訂單確認</h2>
                            <p style="color:#666;font-size:13px;margin:8px 0 0;text-align:center;">感謝購買使用「先買後付」服務</p>
                        </td>
                    </tr>
                    
                    <!-- 重要通知 -->
                    <tr>
                        <td style="padding:0 25px 20px;" class="mobile-padding">
                            <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="background:#fff3e0;border:2px solid #f57c00;border-radius:8px;">
                                <tr>
                                    <td style="padding:15px;">
                                        <p style="margin:0;color:#f57c00;font-size:15px;font-weight:700;">重要通知</p>
                                        <p style="margin:8px 0 0;color:#856404;font-size:13px;line-height:1.6;">出貨後開始計時，逾期付款將會上報信用機構。</p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                    <!-- 主要內容 -->
                    <tr>
                        <td style="padding:0 25px 25px;" class="mobile-padding">
                            
                            <!-- 訂單資訊 -->
                            <h3 style="color:#333;font-size:16px;margin:0 0 12px;font-weight:600;border-bottom:2px solid #f0f0f0;padding-bottom:8px;">訂單資訊</h3>
                            <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="margin-bottom:20px;">
                                <tr>
                                    <td style="padding:6px 0;color:#666;font-size:13px;width:100px;">訂單編號</td>
                                    <td style="padding:6px 0;color:#333;font-size:13px;font-weight:600;">' . esc_html($order_data['order_number']) . '</td>
                                </tr>
                                <tr>
                                    <td style="padding:6px 0;color:#666;font-size:13px;">下單時間</td>
                                    <td style="padding:6px 0;color:#333;font-size:13px;">' . date('Y/m/d H:i', strtotime($order_data['created_at'])) . '</td>
                                </tr>
                                <tr>
                                    <td style="padding:6px 0;color:#666;font-size:13px;">預計出貨時間</td>
                                    <td style="padding:6px 0;color:#333;font-size:13px;">' . date('Y/m/d', strtotime('+3 days', strtotime($order_data['created_at']))) . '</td>
                                </tr>
                            </table>
                            
                            <!-- 商品明細 -->
                            <h3 style="color:#333;font-size:16px;margin:0 0 12px;font-weight:600;border-bottom:2px solid #f0f0f0;padding-bottom:8px;">商品明細</h3>
                            <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="margin-bottom:20px;border:1px solid #e0e0e0;border-radius:6px;">
                                <tr>
                                    <td style="padding:15px;">
                                        <table role="presentation" cellpadding="0" cellspacing="0" width="100%">
                                            <tr>
                                                <td style="width:70px;vertical-align:top;">' . self::get_product_image_html($order_data['product_name']) . '</td>
                                                <td style="padding-left:12px;vertical-align:top;">
                                                    <p style="margin:0 0 8px;color:#333;font-size:14px;font-weight:600;line-height:1.5;">' . esc_html($order_data['product_name']) . '</p>
                                                    <p style="margin:0;color:#666;font-size:13px;">數量：1</p>
                                                </td>
                                                <td style="text-align:right;vertical-align:top;white-space:nowrap;">
                                                    <p style="margin:0;color:#ee4d2d;font-size:16px;font-weight:700;">$' . number_format($order_data['amount'], 0) . '</p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- 訂單總計 -->
                            <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="margin-bottom:20px;background:#f9f9f9;border-radius:6px;">
                                <tr>
                                    <td style="padding:15px;">
                                        <table role="presentation" cellpadding="0" cellspacing="0" width="100%">
                                            <tr>
                                                <td style="color:#666;font-size:13px;padding:4px 0;">商品小計</td>
                                                <td style="text-align:right;color:#333;font-size:13px;padding:4px 0;">$' . number_format($order_data['amount'], 0) . '</td>
                                            </tr>
                                            <tr>
                                                <td style="color:#666;font-size:13px;padding:4px 0;">運費</td>
                                                <td style="text-align:right;color:#333;font-size:13px;padding:4px 0;">免運費</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="border-top:1px solid #e0e0e0;padding-top:10px;margin-top:8px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="color:#333;font-size:15px;font-weight:600;padding:8px 0 0;">訂單總計</td>
                                                <td style="text-align:right;color:#ee4d2d;font-size:20px;font-weight:700;padding:8px 0 0;">$' . number_format($order_data['amount'], 0) . '</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- 運送資訊 -->
                            <h3 style="color:#333;font-size:16px;margin:0 0 12px;font-weight:600;border-bottom:2px solid #f0f0f0;padding-bottom:8px;">運送資訊</h3>
                            <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="margin-bottom:20px;">
                                <tr>
                                    <td style="padding:6px 0;color:#666;font-size:13px;width:100px;">收件人</td>
                                    <td style="padding:6px 0;color:#333;font-size:13px;">' . esc_html($recipient_name) . '</td>
                                </tr>
                                <tr>
                                    <td style="padding:6px 0;color:#666;font-size:13px;">電話</td>
                                    <td style="padding:6px 0;color:#333;font-size:13px;">' . esc_html($phone) . '</td>
                                </tr>
                                <tr>
                                    <td style="padding:6px 0;color:#666;font-size:13px;vertical-align:top;">地址</td>
                                    <td style="padding:6px 0;color:#333;font-size:13px;line-height:1.5;">' . esc_html($recipient_address) . '</td>
                                </tr>
                            </table>
                            
                            <!-- 付款人 -->
                            <h3 style="color:#333;font-size:16px;margin:0 0 12px;font-weight:600;border-bottom:2px solid #f0f0f0;padding-bottom:8px;">付款人</h3>
                            <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="margin-bottom:20px;">
                                <tr>
                                    <td style="padding:6px 0;color:#666;font-size:13px;width:100px;">姓名</td>
                                    <td style="padding:6px 0;color:#333;font-size:13px;">' . esc_html($recipient_name) . '</td>
                                </tr>
                                <tr>
                                    <td style="padding:6px 0;color:#666;font-size:13px;">銀行</td>
                                    <td style="padding:6px 0;color:#333;font-size:13px;">已綁定 - 先買後付</td>
                                </tr>
                                <tr>
                                    <td style="padding:6px 0;color:#666;font-size:13px;">電話</td>
                                    <td style="padding:6px 0;color:#333;font-size:13px;">' . esc_html($phone) . '</td>
                                </tr>
                                <tr>
                                    <td style="padding:6px 0;color:#666;font-size:13px;">郵箱</td>
                                    <td style="padding:6px 0;color:#333;font-size:13px;">' . esc_html($order_data['email']) . '</td>
                                </tr>
                            </table>
                            
                            <!-- 操作按鈕 -->
                            <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="margin:25px 0;">
                                <tr>
                                    <td style="text-align:center;">
                                        <!--[if mso]>
                                        <table cellpadding="0" cellspacing="0" style="margin:0 auto;">
                                            <tr>
                                                <td style="padding:0 8px;">
                                        <![endif]-->
                                        <div class="mobile-btn" style="display:inline-block;margin:0 8px;">
                                            <a href="' . esc_url($track_search_url) . '" style="display:inline-block;background:linear-gradient(135deg, #ff6b35 0%, #ee4d2d 100%);color:#ffffff;padding:16px 32px;text-decoration:none;border-radius:50px;font-size:16px;font-weight:700;box-shadow:0 4px 12px rgba(238,77,45,0.3);min-width:160px;text-align:center;">查看我的訂單</a>
                                        </div>
                                        <!--[if mso]>
                                                </td>
                                                <td style="padding:0 8px;">
                                        <![endif]-->
                                        <div class="mobile-btn" style="display:inline-block;margin:0 8px;">
                                            <a href="' . (!empty($settings['line_id']) ? 'https://line.me/R/ti/p/@' . urlencode(ltrim($settings['line_id'], '@')) : esc_url($track_contact_url)) . '" style="display:inline-block;background:#06c755;color:#ffffff;padding:16px 32px;text-decoration:none;border-radius:50px;font-size:16px;font-weight:700;box-shadow:0 4px 12px rgba(6,199,85,0.3);min-width:160px;text-align:center;">聯繫客服</a>
                                        </div>
                                        <!--[if mso]>
                                                </td>
                                            </tr>
                                        </table>
                                        <![endif]-->
                                    </td>
                                </tr>
                            </table>
                            
                            ' . $faq_html . '
                            
                            <!-- 溫馨提示 -->
                            <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="margin-bottom:20px;">
                                <tr>
                                    <td style="background:#f9f9f9;border-radius:8px;padding:15px;">
                                        <p style="margin:0 0 8px;color:#666;font-size:13px;font-weight:600;">溫馨提示</p>
                                        <p style="margin:0;color:#888;font-size:12px;line-height:1.8;">
                                            • 請確認收貨地址及電話正確，以免影響配送<br>
                                            • 商品送達時請當面檢查，如有問題請拒收<br>
                                            • 如需修改訂單資訊，請盡快聯繫客服
                                        </p>
                                    </td>
                                </tr>
                            </table>
                            
                            <p style="color:#666;font-size:14px;margin:0;line-height:1.7;">' . esc_html($closing_text) . '</p>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background:#fafafa;padding:20px 25px;text-align:center;border-top:1px solid #e0e0e0;">
                            <p style="color:#999;font-size:12px;margin:0;line-height:1.8;">' . nl2br(esc_html($footer_text)) . '</p>
                            ' . $footer_url_html . '
                            <p style="color:#ccc;font-size:11px;margin:15px 0 0;">© ' . date('Y') . ' ' . esc_html($site_name) . '</p>
                        </td>
                    </tr>
                    
                </table>
                
            </td>
        </tr>
    </table>
    
</body>
</html>';
        
        return $html;
    }
}
