<?php
/**
 * 商城前台 - 主控制器
 * 負責路由和公共方法（header/footer/styles/product card）
 */

if (!defined('ABSPATH')) {
    exit;
}

class OIP_Shop_Frontend {
    
    public function __construct() {
        // 載入頁面類
        require_once __DIR__ . '/class-shop-pages-main.php';
        require_once __DIR__ . '/class-shop-pages-cart.php';
        require_once __DIR__ . '/class-shop-pages-info.php';
        require_once __DIR__ . '/class-shop-pages-member.php';
        require_once __DIR__ . '/class-shop-pages-promo.php';
        
        add_action('template_redirect', [$this, 'override_template'], 1);
    }
    
    public function override_template() {
        if (isset($_GET['oip_page']) || isset($_GET['oip_logout'])) {
            return;
        }
        
        if (isset($_GET['oip_shop'])) {
            $page = sanitize_text_field($_GET['oip_shop']);
            $this->route_page($page);
            exit;
        }
        
        if (is_front_page() || is_home()) {
            OIP_Shop_Pages_Main::render_home($this);
            exit;
        }
    }
    
    private function route_page($page) {
        switch ($page) {
            // Main pages
            case 'home': OIP_Shop_Pages_Main::render_home($this); break;
            case 'category': OIP_Shop_Pages_Main::render_category($this); break;
            case 'product': OIP_Shop_Pages_Main::render_product($this); break;
            case 'search': OIP_Shop_Pages_Main::render_search($this); break;
            
            // Cart pages
            case 'cart': OIP_Shop_Pages_Cart::render_cart($this); break;
            case 'checkout': OIP_Shop_Pages_Cart::render_checkout($this); break;
            
            // Promo pages
            case 'flash-sale': OIP_Shop_Pages_Promo::render_flash_sale($this); break;
            case 'new-arrivals': OIP_Shop_Pages_Promo::render_new_arrivals($this); break;
            case 'best-sellers': OIP_Shop_Pages_Promo::render_best_sellers($this); break;
            
            // Info pages
            case 'about': OIP_Shop_Pages_Info::render_about($this); break;
            case 'contact': OIP_Shop_Pages_Info::render_contact($this); break;
            case 'faq': OIP_Shop_Pages_Info::render_faq($this); break;
            case 'shipping': OIP_Shop_Pages_Info::render_shipping($this); break;
            case 'returns': OIP_Shop_Pages_Info::render_returns($this); break;
            case 'privacy': OIP_Shop_Pages_Info::render_privacy($this); break;
            case 'terms': OIP_Shop_Pages_Info::render_terms($this); break;
            
            // Member pages
            case 'coupons': OIP_Shop_Pages_Member::render_coupons($this); break;
            case 'member': OIP_Shop_Pages_Member::render_member($this); break;
            case 'wishlist': OIP_Shop_Pages_Member::render_wishlist($this); break;
            
            default: wp_redirect(home_url()); exit;
        }
    }

    // ========== 公共樣式 ==========
    public function get_styles() {
        return '
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:"Noto Sans TC","Microsoft JhengHei","微軟正黑體","PingFang TC","蘋方-繁",Helvetica,Arial,sans-serif;background:#f5f5f5;color:#333;line-height:1.6;font-size:14px;-webkit-font-smoothing:antialiased}
a{text-decoration:none;color:inherit}
img{max-width:100%;height:auto}
.top-bar{background:#ee4d2d;color:#fff;font-size:12px;padding:8px 0}
.top-bar-inner{max-width:1200px;margin:0 auto;padding:0 15px;display:flex;justify-content:space-between;align-items:center}
.top-bar a{color:#fff;margin-left:12px}
.top-bar a:hover{opacity:.8}
.main-header{background:linear-gradient(180deg,#ee4d2d 0%,#f53d2d 100%);padding:15px 0}
.header-inner{max-width:1200px;margin:0 auto;padding:0 15px;display:flex;align-items:flex-start;gap:25px}
.logo{display:flex;align-items:center;gap:10px;color:#fff;font-size:26px;font-weight:700;flex-shrink:0;height:44px}
.logo svg{width:45px;height:45px;fill:#fff}
.search-wrap{flex:1;display:flex;flex-direction:column;gap:8px}
.search-box{display:flex;background:#fff;border-radius:4px;overflow:hidden;height:44px}
.search-box input{flex:1;padding:0 15px;border:none;outline:none;font-size:14px}
.search-box button{padding:0 25px;background:#fb6445;color:#fff;border:none;cursor:pointer;font-size:14px}
.search-box button:hover{background:#ee4d2d}
.search-tags{display:flex;gap:15px;flex-wrap:wrap}
.search-tags a{color:rgba(255,255,255,.9);font-size:12px}
.search-tags a:hover{color:#fff}
.header-actions{display:flex;align-items:flex-start;gap:15px;flex-shrink:0;padding-top:2px}
.header-actions a{color:#fff;display:flex;flex-direction:column;align-items:center;gap:4px;font-size:11px;position:relative}
.header-actions a:hover{opacity:.9}
.header-actions svg{width:24px;height:24px;fill:#fff}
.cart-badge{position:absolute;top:-5px;right:-8px;background:#fff;color:#ee4d2d;font-size:10px;padding:1px 5px;border-radius:10px;font-weight:700}
.main-nav{background:#fff;border-bottom:1px solid #e8e8e8;position:sticky;top:0;z-index:100;box-shadow:0 1px 3px rgba(0,0,0,.08)}
.nav-inner{max-width:1200px;margin:0 auto;padding:0 15px;display:flex;align-items:center;justify-content:space-between}
.nav-menu{display:flex;gap:0;align-items:center}
.nav-menu>a,.nav-menu>.dropdown>a{padding:15px 18px;font-size:14px;color:#333;transition:all .2s;border-bottom:2px solid transparent;display:block}
.nav-menu>a:hover,.nav-menu>a.active,.nav-menu>.dropdown:hover>a{color:#ee4d2d;border-bottom-color:#ee4d2d;background:#fff5f5}
.nav-menu .dropdown{position:relative}
.nav-menu .dropdown>a::after{content:" ▾";font-size:10px}
.nav-menu .dropdown-content{display:none;position:absolute;top:100%;left:0;background:#fff;min-width:180px;box-shadow:0 4px 12px rgba(0,0,0,.15);border-radius:0 0 4px 4px;z-index:200;border-top:2px solid #ee4d2d}
.nav-menu .dropdown:hover .dropdown-content{display:block}
.nav-menu .dropdown-content a{display:block;padding:12px 20px;font-size:14px;color:#333;border-bottom:1px solid #f5f5f5}
.nav-menu .dropdown-content a:hover{background:#fff5f5;color:#ee4d2d}
.nav-right{display:flex;align-items:center;gap:15px;font-size:13px;color:#666}
.nav-right svg{width:18px;height:18px;fill:#ee4d2d;vertical-align:middle;margin-right:5px}
.shop-main{max-width:1200px;margin:0 auto;padding:20px 15px}
.banner-slider{background:#fff;border-radius:8px;overflow:hidden;position:relative;height:0;padding-bottom:40%;box-shadow:0 2px 8px rgba(0,0,0,.08)}
.banner-slider img{position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;display:block}
.banner-dots{position:absolute;bottom:15px;left:50%;transform:translateX(-50%);display:flex;gap:8px;z-index:10}
.banner-dots span{width:10px;height:10px;border-radius:50%;background:rgba(255,255,255,.5);cursor:pointer;transition:all .2s}
.banner-dots span.active{background:#fff;transform:scale(1.2)}
.banner-nav{position:absolute;top:50%;transform:translateY(-50%);width:40px;height:40px;background:rgba(0,0,0,.3);color:#fff;border:none;cursor:pointer;font-size:20px;z-index:10;transition:all .2s}
.banner-nav:hover{background:rgba(0,0,0,.5)}
.banner-nav.prev{left:10px;border-radius:4px}
.banner-nav.next{right:10px;border-radius:4px}
.side-banner:hover{transform:translateY(-3px);box-shadow:0 6px 20px rgba(0,0,0,.15)}
.cat-section{background:#fff;border-radius:4px;padding:20px;margin-bottom:20px}
.cat-section h3{font-size:16px;color:#333;margin-bottom:15px;display:flex;align-items:center;gap:10px}
.cat-section h3::before{content:"";width:4px;height:20px;background:#ee4d2d;border-radius:2px}
.cat-grid{display:flex;flex-wrap:wrap;gap:10px;justify-content:center}
.cat-item{flex:1 1 auto;min-width:100px;max-width:150px;text-align:center;padding:15px 10px;border-radius:8px;transition:all .2s;cursor:pointer}
.cat-item:hover{background:#fff5f5;transform:translateY(-3px)}
.cat-item .icon{width:50px;height:50px;margin:0 auto 10px;background:linear-gradient(135deg,#fff5f5,#ffe8e8);border-radius:12px;display:flex;align-items:center;justify-content:center}
.cat-item .icon svg{width:28px;height:28px;fill:#ee4d2d}
.cat-item span{font-size:12px;color:#333;display:block;line-height:1.3}
.flash-section{background:linear-gradient(90deg,#f53d2d,#ff6633);border-radius:4px;padding:20px;margin-bottom:20px;color:#fff}
.flash-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:15px}
.flash-title{display:flex;align-items:center;gap:15px;font-size:18px;font-weight:700}
.flash-title svg{width:24px;height:24px;fill:#fff}
.countdown{display:flex;gap:5px}
.countdown span{background:#333;padding:5px 8px;border-radius:4px;font-size:14px;font-weight:700;min-width:30px;text-align:center}
.flash-more{color:#fff;font-size:14px;display:flex;align-items:center;gap:5px}
.product-card{background:#fff;border-radius:4px;overflow:hidden;transition:all .2s;border:1px solid #e8e8e8;position:relative}
.product-card:hover{box-shadow:0 4px 20px rgba(0,0,0,.12);transform:translateY(-3px);border-color:#ee4d2d}
.product-card .badge{position:absolute;top:10px;left:0;background:#ee4d2d;color:#fff;padding:3px 8px;font-size:11px;border-radius:0 4px 4px 0}
.product-card .badge.sale{background:#f53d2d}
.product-card .badge.new{background:#00bfa5}
.product-card .badge.hot{background:#ff6633}
.product-img{width:100%;aspect-ratio:1;object-fit:cover;display:block;background:#f5f5f5}
.product-info{padding:12px}
.product-name{font-size:13px;color:#333;line-height:1.4;height:37px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;margin-bottom:8px}
.product-price{display:flex;align-items:baseline;gap:8px;margin-bottom:6px}
.product-price .current{color:#ee4d2d;font-size:16px;font-weight:600}
.product-price .current small{font-size:12px}
.product-price .original{color:#999;font-size:12px;text-decoration:line-through}
.product-meta{display:flex;justify-content:space-between;align-items:center;font-size:11px;color:#999}
.product-rating{color:#ffce3d}
.product-sold{color:#666}
.product-location{display:flex;align-items:center;gap:3px;margin-top:6px;font-size:11px;color:#999}
.product-location svg{width:12px;height:12px;fill:#999}
.section-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;padding-bottom:15px;border-bottom:2px solid #ee4d2d}
.section-title{font-size:18px;color:#ee4d2d;font-weight:500;display:flex;align-items:center;gap:10px}
.section-title svg{width:24px;height:24px;fill:#ee4d2d}
.section-more{color:#ee4d2d;font-size:14px;display:flex;align-items:center;gap:5px}
.section-more:hover{text-decoration:underline}
.shop-footer{background:#fff;border-top:4px solid #ee4d2d;margin-top:40px}
.footer-main{max-width:1200px;margin:0 auto;padding:40px 15px;display:grid;grid-template-columns:repeat(4,1fr);gap:30px}
.footer-col h4{font-size:14px;color:#333;margin-bottom:15px;font-weight:600}
.footer-col a{display:block;font-size:13px;color:#666;margin-bottom:10px}
.footer-col a:hover{color:#ee4d2d}
.footer-col .social{display:flex;gap:10px;margin-top:10px}
.footer-col .social a{width:36px;height:36px;background:#f5f5f5;border-radius:50%;display:flex;align-items:center;justify-content:center}
.footer-col .social svg{width:18px;height:18px;fill:#666}
.footer-col .social a:hover{background:#ee4d2d}
.footer-col .social a:hover svg{fill:#fff}
.footer-payment{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}
.footer-payment span{background:#f5f5f5;padding:5px 12px;border-radius:4px;font-size:11px;color:#666}
.footer-bottom{background:#f5f5f5;padding:20px 0;text-align:center}
.footer-bottom p{font-size:12px;color:#999;max-width:1200px;margin:0 auto;padding:0 15px}
@media(max-width:1024px){
.cat-item{min-width:80px;max-width:120px}
.footer-main{grid-template-columns:repeat(2,1fr)}
}
@media(max-width:768px){
.top-bar{display:none}
.header-inner{flex-wrap:wrap;gap:10px;padding:10px 15px}
.logo{font-size:18px;gap:6px}
.logo svg{width:30px;height:30px}
.search-wrap{order:3;width:100%;margin-top:5px}
.search-tags{display:none}
.header-actions{gap:8px}
.header-actions a{padding:5px 8px;font-size:10px;gap:2px}
.header-actions svg{width:22px;height:22px}
.nav-menu{overflow-x:auto;width:100%;scrollbar-width:none}
.nav-menu::-webkit-scrollbar{display:none}
.nav-menu>a,.nav-menu>.dropdown>a{padding:10px 12px;font-size:13px;white-space:nowrap}
.nav-right{display:none}
.banner-slider{padding-bottom:50%}
.cat-section{padding:15px}
.cat-grid{gap:8px}
.cat-item{min-width:70px;max-width:100px;padding:10px 5px}
.cat-item .icon{width:40px;height:40px;margin-bottom:6px}
.cat-item .icon svg{width:22px;height:22px}
.cat-item span{font-size:11px}
.flash-section{padding:15px}
.flash-header{flex-wrap:wrap;gap:10px}
.flash-title{font-size:14px;gap:8px}
.countdown span{padding:3px 5px;font-size:12px;min-width:24px}
.product-info{padding:10px}
.product-name{font-size:12px;height:34px}
.product-price .current{font-size:14px}
.section-header{margin-bottom:15px;padding-bottom:10px}
.section-title{font-size:15px;gap:8px}
.footer-main{text-align:left;padding:25px 15px;gap:15px}
.footer-col h4{margin-bottom:10px;font-size:13px}
.footer-col a{font-size:12px;margin-bottom:8px}
.shop-main{padding:15px 10px}
}
@media(max-width:480px){
.cat-item{min-width:60px;max-width:80px;padding:8px 3px}
.cat-item .icon{width:36px;height:36px}
.cat-item .icon svg{width:20px;height:20px}
.cat-item span{font-size:10px}
.shop-main{padding:10px 8px}
}
</style>';
    }


    // ========== 公共頭部 ==========
    public function get_header($title = '') {
        $site_name = get_bloginfo('name');
        $is_logged_in = is_user_logged_in();
        $categories = OIP_Product_Manager::get_categories();
        $cart_count = isset($_COOKIE['oip_cart']) ? count(json_decode(stripslashes($_COOKIE['oip_cart']), true) ?: []) : 0;
        $page_title = $title ? $title . ' - ' . $site_name : $site_name . ' - 線上購物';
        
        $html = '<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>' . esc_html($page_title) . '</title>
<link href="' . plugins_url('assets/css/bootstrap.min.css', dirname(dirname(__FILE__))) . '" rel="stylesheet">
<link href="' . plugins_url('assets/css/noto-sans-tc.css', dirname(dirname(__FILE__))) . '" rel="stylesheet">
' . $this->get_styles() . '
</head>
<body>
<div class="top-bar">
    <div class="top-bar-inner">
        <div>
            <span>歡迎來到 ' . esc_html($site_name) . '</span>
            <a href="' . home_url('/?oip_shop=about') . '">關於我們</a>
            <a href="' . esc_url(oip_get_contact_url()) . '"' . (oip_get_line_id() ? ' target="_blank" rel="noopener"' : '') . '>聯繫客服</a>
        </div>
        <div>
            <a href="' . home_url('/?oip_shop=faq') . '">幫助中心</a>
            <a href="' . home_url('/?oip_shop=member') . '">會員中心</a>
            ' . ($is_logged_in ? 
                '<a href="' . home_url('/?oip_page=orders') . '">我的訂單</a>
                <a href="' . home_url('/?oip_logout=1') . '">登出</a>' : 
                '<a href="' . home_url('/?oip_page=login') . '">登入</a>') . '
        </div>
    </div>
</div>
<header class="main-header">
    <div class="header-inner">
        <a href="' . home_url() . '" class="logo">
            <svg viewBox="0 0 24 24"><path d="M18 6h-2c0-2.21-1.79-4-4-4S8 3.79 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6-2c1.1 0 2 .9 2 2h-4c0-1.1.9-2 2-2zm6 16H6V8h2v2c0 .55.45 1 1 1s1-.45 1-1V8h4v2c0 .55.45 1 1 1s1-.45 1-1V8h2v12z"/></svg>
            ' . esc_html($site_name) . '
        </a>
        <div class="search-wrap">
            <form class="search-box" action="' . home_url() . '" method="get">
                <input type="hidden" name="oip_shop" value="search">
                <input type="text" name="q" placeholder="搜尋商品..." value="' . esc_attr($_GET['q'] ?? '') . '">
                <button type="submit">
                    <svg width="20" height="20" fill="#fff" viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
                </button>
            </form>
            <div class="search-tags">
                <a href="' . home_url('/?oip_shop=flash-sale') . '">限時特賣</a>
                <a href="' . home_url('/?oip_shop=new-arrivals') . '">新品上市</a>
                <a href="' . home_url('/?oip_shop=best-sellers') . '">熱銷排行</a>
            </div>
        </div>
        <div class="header-actions">
            <a href="' . home_url('/order-search/') . '">
                <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
                <span>訂單查詢</span>
            </a>
            <a href="' . home_url('/?oip_page=login') . '">
                <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
                <span>登入</span>
            </a>
            <a href="' . home_url('/?oip_shop=cart') . '">
                <svg viewBox="0 0 24 24"><path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/></svg>
                <span>購物車</span>
                ' . ($cart_count > 0 ? '<span class="cart-badge">' . $cart_count . '</span>' : '') . '
            </a>
        </div>
    </div>
</header>
<nav class="main-nav">
    <div class="nav-inner">
        <div class="nav-menu">
            <a href="' . home_url() . '" class="' . (!isset($_GET['oip_shop']) && !isset($_GET['oip_page']) ? 'active' : '') . '">首頁</a>
            <div class="dropdown">
                <a href="#">全部分類</a>
                <div class="dropdown-content">';
        foreach ($categories as $cat) {
            $html .= '<a href="' . home_url('/?oip_shop=category&cat=' . $cat->slug) . '">' . esc_html($cat->name) . '</a>';
        }
        $html .= '</div>
            </div>
            <a href="' . home_url('/?oip_shop=flash-sale') . '">限時特賣</a>
            <a href="' . home_url('/?oip_shop=new-arrivals') . '">新品上市</a>
            <a href="' . home_url('/?oip_shop=best-sellers') . '">熱銷排行</a>';
        foreach (array_slice($categories, 0, 3) as $cat) {
            $html .= '<a href="' . home_url('/?oip_shop=category&cat=' . $cat->slug) . '">' . esc_html($cat->name) . '</a>';
        }
        $html .= '</div>
        <div class="nav-right">
            <span><svg viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>全台配送</span>
        </div>
    </div>
</nav>';
        return $html;
    }

    // ========== 公共底部 ==========
    public function get_footer() {
        $site_name = get_bloginfo('name');
        $social = get_option('oip_social_links', []);
        $footer_info = get_option('oip_footer_info', []);
        
        // 社交媒體圖標 SVG
        $social_icons = [
            'facebook' => '<svg viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>',
            'instagram' => '<svg viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z"/></svg>',
            'line' => '<svg viewBox="0 0 24 24"><path d="M19.365 9.863c.349 0 .63.285.63.631 0 .345-.281.63-.63.63H17.61v1.125h1.755c.349 0 .63.283.63.63 0 .344-.281.629-.63.629h-2.386c-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63h2.386c.346 0 .627.285.627.63 0 .349-.281.63-.63.63H17.61v1.125h1.755zm-3.855 3.016c0 .27-.174.51-.432.596-.064.021-.133.031-.199.031-.211 0-.391-.09-.51-.25l-2.443-3.317v2.94c0 .344-.279.629-.631.629-.346 0-.626-.285-.626-.629V8.108c0-.27.173-.51.43-.595.06-.023.136-.033.194-.033.195 0 .375.104.495.254l2.462 3.33V8.108c0-.345.282-.63.63-.63.345 0 .63.285.63.63v4.771zm-5.741 0c0 .344-.282.629-.631.629-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63.346 0 .628.285.628.63v4.771zm-2.466.629H4.917c-.345 0-.63-.285-.63-.629V8.108c0-.345.285-.63.63-.63.348 0 .63.285.63.63v4.141h1.756c.348 0 .629.283.629.63 0 .344-.282.629-.629.629M24 10.314C24 4.943 18.615.572 12 .572S0 4.943 0 10.314c0 4.811 4.27 8.842 10.035 9.608.391.082.923.258 1.058.59.12.301.079.766.038 1.08l-.164 1.02c-.045.301-.24 1.186 1.049.645 1.291-.539 6.916-4.078 9.436-6.975C23.176 14.393 24 12.458 24 10.314"/></svg>',
            'youtube' => '<svg viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
            'twitter' => '<svg viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
            'tiktok' => '<svg viewBox="0 0 24 24"><path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/></svg>',
        ];
        
        // 生成社交媒體連結 HTML
        $social_html = '';
        foreach ($social_icons as $key => $icon) {
            if (!empty($social[$key])) {
                $social_html .= '<a href="' . esc_url($social[$key]) . '" target="_blank" rel="noopener">' . $icon . '</a>';
            }
        }
        
        // 頁腳底部資訊
        $footer_bottom_info = '';
        if (!empty($footer_info['company_id'])) {
            $footer_bottom_info .= ' | 統編：' . esc_html($footer_info['company_id']);
        }
        if (!empty($footer_info['phone'])) {
            $footer_bottom_info .= ' | 客服專線：' . esc_html($footer_info['phone']);
        }
        if (!empty($footer_info['service_hours'])) {
            $footer_bottom_info .= ' | ' . esc_html($footer_info['service_hours']);
        }
        
        $html = '
<footer class="shop-footer">
    <div class="footer-main">
        <div class="footer-col">
            <h4>客戶服務</h4>
            <a href="' . home_url('/?oip_shop=faq') . '">常見問題</a>
            <a href="' . home_url('/?oip_shop=shipping') . '">配送說明</a>
            <a href="' . home_url('/?oip_shop=returns') . '">退換貨政策</a>
            <a href="' . esc_url(oip_get_contact_url()) . '"' . (oip_get_line_id() ? ' target="_blank" rel="noopener"' : '') . '>聯繫客服</a>
        </div>
        <div class="footer-col">
            <h4>關於我們</h4>
            <a href="' . home_url('/?oip_shop=about') . '">公司介紹</a>
            <a href="' . home_url('/?oip_shop=privacy') . '">隱私政策</a>
            <a href="' . home_url('/?oip_shop=terms') . '">服務條款</a>
        </div>
        <div class="footer-col">
            <h4>付款方式</h4>
            <div class="footer-payment">
                <span>貨到付款</span>
                <span>信用卡</span>
                <span>ATM轉帳</span>
            </div>
            <h4 style="margin-top:20px">物流配送</h4>
            <div class="footer-payment">
                <span>宅配到府</span>
                <span>超商取貨</span>
            </div>
        </div>
        <div class="footer-col">
            <h4>關注我們</h4>';
        
        if (!empty($social_html)) {
            $html .= '<div class="social">' . $social_html . '</div>';
        } else {
            $html .= '<p style="font-size:13px;color:#999;">敬請期待</p>';
        }
        
        $html .= '
        </div>
    </div>
    <div class="footer-bottom">
        <p>© ' . date('Y') . ' ' . esc_html($site_name) . ' 版權所有' . $footer_bottom_info . '</p>
    </div>
</footer>
<script src="' . plugins_url('assets/js/bootstrap.bundle.min.js', dirname(dirname(__FILE__))) . '"></script>
</body>
</html>';
        
        return $html;
    }

    // ========== 商品卡片 ==========
    public function render_product_card($product, $show_badge = true, $col_class = '') {
        $discount = 0;
        if ($product->original_price && $product->original_price > $product->price) {
            $discount = round((1 - $product->price / $product->original_price) * 100);
        }
        $wrapper_class = $col_class ?: 'col-6 col-md-4 col-lg-3';
        
        $html = '<div class="' . $wrapper_class . ' mb-3">';
        $html .= '<a href="' . home_url('/?oip_shop=product&id=' . $product->id) . '" class="product-card d-block h-100">';
        
        if ($show_badge && $discount >= 20) {
            $html .= '<span class="badge sale">-' . $discount . '%</span>';
        } elseif ($show_badge && $product->sales > 1000) {
            $html .= '<span class="badge hot">熱賣</span>';
        }
        
        if ($product->image) {
            $html .= '<img src="' . esc_url($product->image) . '" alt="' . esc_attr($product->name) . '" class="product-img">';
        } else {
            $html .= '<div class="product-img d-flex align-items-center justify-content-center" style="background:#f8f8f8">
                <svg width="50" height="50" fill="#ddd" viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg>
            </div>';
        }
        
        $html .= '<div class="product-info">
            <div class="product-name">' . esc_html($product->name) . '</div>
            <div class="product-price">
                <span class="current"><small>$</small>' . number_format($product->price) . '</span>';
        if ($product->original_price && $product->original_price > $product->price) {
            $html .= '<span class="original">$' . number_format($product->original_price) . '</span>';
        }
        if ($product->original_price && $product->original_price > $product->price) {
            $html .= '<span class="original">$' . number_format($product->original_price) . '</span>';
        }
        $html .= '</div>
            <div class="product-meta">
                <span class="product-rating">★ ' . number_format($product->rating, 1) . '</span>
                <span class="product-sold">已售 ' . ($product->sales >= 1000 ? number_format($product->sales / 1000, 1) . 'k' : $product->sales) . '</span>
            </div>
        </div></a></div>';
        
        return $html;
    }
    
    // ========== 商品網格 ==========
    public function render_product_grid($products, $cols = 5) {
        if (empty($products)) return '';
        $col_class = 'col-6 col-md-4 col-lg-3';
        if ($cols == 6) $col_class = 'col-6 col-md-4 col-lg-2';
        if ($cols == 5) $col_class = 'col-6 col-md-4 col-lg';
        
        $html = '<div class="row g-2 g-md-3">';
        foreach ($products as $p) {
            $html .= $this->render_product_card($p, true, $col_class);
        }
        $html .= '</div>';
        return $html;
    }

    // ========== 分類圖標 ==========
    public function get_category_icons() {
        return [
            'phone-accessories' => '<path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"/>',
            'computer-peripherals' => '<path d="M20 18c1.1 0 1.99-.9 1.99-2L22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2H0v2h24v-2h-4zM4 6h16v10H4V6z"/>',
            'default' => '<path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z"/>'
        ];
    }
}
