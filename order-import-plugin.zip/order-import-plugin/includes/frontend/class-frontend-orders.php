<?php
/**
 * 前台頁面 - 訂單列表/詳情/個人資料
 * 使用商城統一頭部
 */

if (!defined('ABSPATH')) exit;

class OIP_Frontend_Orders {
    
    // ========== 訂單查詢頁面（不需要登录）==========
    public static function render_order_search() {
        $contact_link = oip_get_contact_url();
        $is_line = (bool) oip_get_line_id();
        
        // 处理邮箱查询 - 支持 GET 和 POST
        $email = '';
        if (isset($_GET['email']) && !empty($_GET['email'])) {
            $email = sanitize_email($_GET['email']);
        } elseif (isset($_POST['email']) && !empty($_POST['email'])) {
            $email = sanitize_email($_POST['email']);
        }
        
        $orders = [];
        $search_attempted = false;
        
        if (!empty($email)) {
            $search_attempted = true;
            global $wpdb;
            $orders = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}custom_orders WHERE email = %s ORDER BY created_at DESC",
                $email
            ));
        }
        
        // 使用商城統一頭部
        $shop = new OIP_Shop_Frontend();
        echo $shop->get_header('訂單查詢');
        echo self::get_orders_styles();
        ?>
<div class="page-container">
    <?php if (!empty($orders)): ?>
        <!-- 直接显示所有订单明细 -->
        <?php foreach ($orders as $index => $order): ?>
            <?php if ($index > 0): ?><div style="height:30px"></div><?php endif; ?>
            <?php self::render_order_detail($order, $contact_link, $email, true); ?>
        <?php endforeach; ?>
    <?php else: ?>
    <div class="order-search-container">
        <div class="search-card">
            <div class="search-header">
                <svg viewBox="0 0 24 24" width="48" height="48"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" fill="#ee4d2d"/></svg>
                <h1>訂單查詢</h1>
                <p>輸入您的 Email 查詢訂單資訊</p>
            </div>
            
            <form method="get" class="search-form">
                <div class="search-input-group">
                    <svg viewBox="0 0 24 24" width="20" height="20"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z" fill="#999"/></svg>
                    <input type="email" name="email" placeholder="請輸入您的 Email" value="<?php echo esc_attr($email); ?>" required>
                </div>
                <button type="submit" class="search-btn">
                    <svg viewBox="0 0 24 24" width="20" height="20"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" fill="#fff"/></svg>
                    查詢訂單
                </button>
            </form>
            
            <?php if ($search_attempted && empty($orders)): ?>
            <div class="search-result empty">
                <svg viewBox="0 0 24 24" width="64" height="64"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z" fill="#ff4d4f"/></svg>
                <h3>查無訂單</h3>
                <p>此 Email 沒有相關訂單記錄</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
        <?php
        echo $shop->get_footer();
    }
    
    // ========== 訂單頁面（需要登录）==========
    public static function render_orders($frontend) {
        $contact_link = oip_get_contact_url();
        $is_line = (bool) oip_get_line_id();
        
        // 处理邮箱查询
        $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
        $orders = [];
        $search_attempted = false;
        
        if (!empty($email) && isset($_POST['search_orders'])) {
            $search_attempted = true;
            global $wpdb;
            $orders = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}custom_orders WHERE email = %s ORDER BY created_at DESC",
                $email
            ));
        }
        
        $view_order = isset($_GET['order']) ? sanitize_text_field($_GET['order']) : null;
        $single_order = null;
        
        // 如果指定了订单号，查找该订单
        if ($view_order && !empty($orders)) {
            foreach ($orders as $o) {
                if ($o->order_number === $view_order) { $single_order = $o; break; }
            }
        }
        // 如果查询结果只有一个订单，直接显示明细
        elseif ($search_attempted && count($orders) === 1) {
            $single_order = $orders[0];
        }
        
        // 使用商城統一頭部
        $shop = new OIP_Shop_Frontend();
        echo $shop->get_header('訂單查詢');
        echo self::get_orders_styles();
        ?>
<div class="page-container">
    <?php if ($single_order): ?>
    <?php self::render_order_detail($single_order, $contact_link, $email); ?>
    <?php else: ?>
    <div class="order-search-container">
        <div class="search-card">
            <div class="search-header">
                <svg viewBox="0 0 24 24" width="48" height="48"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" fill="#ee4d2d"/></svg>
                <h1>訂單查詢</h1>
                <p>輸入您的 Email 查詢訂單資訊</p>
            </div>
            
            <form method="post" class="search-form">
                <div class="search-input-group">
                    <svg viewBox="0 0 24 24" width="20" height="20"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z" fill="#999"/></svg>
                    <input type="email" name="email" placeholder="請輸入您的 Email" value="<?php echo esc_attr($email); ?>" required>
                </div>
                <button type="submit" name="search_orders" class="search-btn">
                    <svg viewBox="0 0 24 24" width="20" height="20"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" fill="#fff"/></svg>
                    查詢訂單
                </button>
            </form>
            
            <?php if ($search_attempted && empty($orders)): ?>
            <div class="search-result empty">
                <svg viewBox="0 0 24 24" width="64" height="64"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z" fill="#ff4d4f"/></svg>
                <h3>查無訂單</h3>
                <p>此 Email 沒有相關訂單記錄</p>
            </div>
            <?php endif; ?>
        </div>
        
        <?php if (count($orders) > 1): ?>
        <div class="orders-list">
            <div class="list-header">
                <h2>找到 <?php echo count($orders); ?> 筆訂單</h2>
                <span class="email-badge"><?php echo esc_html($email); ?></span>
            </div>
            
            <?php foreach ($orders as $order): 
                $source = isset($order->source) ? $order->source : 'imported';
                $products = self::parse_product_list($order->product_name, $source, $order->amount);
                $first_product = !empty($products) ? $products[0] : null;
                $product_image = $first_product ? $first_product['image'] : '';
            ?>
            <div class="order-card">
                <div class="order-header">
                    <div class="order-number">訂單編號：<strong><?php echo esc_html($order->order_number); ?></strong>
                    <span class="order-date"><?php echo date('Y-m-d H:i', strtotime($order->created_at)); ?></span></div>
                    <div class="order-status processing">處理中</div>
                </div>
                <div class="order-body">
                    <div class="order-product">
                        <div class="order-product-img">
                            <?php if ($product_image): ?><img src="<?php echo esc_url($product_image); ?>" alt="">
                            <?php else: ?><svg viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg><?php endif; ?>
                        </div>
                        <div class="order-product-info">
                            <div class="order-product-name">
                                <?php if (count($products) > 1): ?>
                                    <?php echo esc_html($first_product['name']); ?> 等 <?php echo count($products); ?> 件商品
                                <?php else: ?>
                                    <?php echo esc_html($order->product_name); ?>
                                <?php endif; ?>
                            </div>
                            <div class="order-product-meta">
                                <?php if (count($products) > 1): ?>
                                    共 <?php echo array_sum(array_column($products, 'qty')); ?> 件 | 收件人：<?php echo esc_html($order->recipient_name ?: '—'); ?>
                                <?php else: ?>
                                    數量：<?php echo $first_product ? $first_product['qty'] : 1; ?> | 收件人：<?php echo esc_html($order->recipient_name ?: '—'); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="order-product-price"><div class="price">$<?php echo number_format($order->amount, 0); ?></div></div>
                    </div>
                </div>
                <div class="order-footer">
                    <div class="order-total">訂單金額：<span>$<?php echo number_format($order->amount, 0); ?></span></div>
                    <div class="order-actions">
                        <a href="<?php echo home_url('/?oip_page=orders&order=' . urlencode($order->order_number)); ?>" class="btn-primary">查看詳情</a>
                        <a href="<?php echo esc_url($contact_link); ?>" target="_blank" rel="noopener" class="btn-outline"><?php echo $is_line ? 'LINE 客服' : '聯繫客服'; ?></a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
        <?php
        echo $shop->get_footer();
    }
    
    // ========== 訂單詳情 ==========
    private static function render_order_detail($order, $contact_link, $email = '', $hide_back = false) {
        $source = isset($order->source) ? $order->source : 'imported';
        $products = self::parse_product_list($order->product_name, $source, $order->amount);
        $is_line = (bool) oip_get_line_id();
        
        // 隐私保护：只隐藏地址
        $masked_address = self::mask_address($order->recipient_address);
        
        // 返回链接
        $back_url = !empty($email) ? home_url('/?oip_page=orders') : home_url('/?oip_page=orders');
        ?>
<div class="detail-container">
    <?php if (!$hide_back): ?>
    <a href="<?php echo esc_url($back_url); ?>" class="detail-back">← 返回<?php echo !empty($email) ? '查詢' : '訂單列表'; ?></a>
    <?php endif; ?>
    
    <!-- 右上角状态提示 -->
    <div class="order-status-badge">
        <svg viewBox="0 0 24 24" width="16" height="16"><circle cx="12" cy="12" r="10" fill="#52c41a"/><path d="M9 12l2 2 4-4" stroke="#fff" stroke-width="2" fill="none"/></svg>
        系統自動請款中
    </div>
    
    <div class="detail-card">
        <div class="detail-header">
            <div>
                <h2>訂單編號</h2>
                <div class="order-number-large"><?php echo esc_html($order->order_number); ?></div>
            </div>
        </div>
        
        <!-- 订单流程进度条 -->
        <div class="order-progress">
            <div class="progress-step active">
                <div class="progress-icon">
                    <svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                </div>
                <div class="progress-label">訂單成立</div>
                <div class="progress-time"><?php echo date('Y/m/d H:i', strtotime($order->created_at)); ?></div>
            </div>
            <div class="progress-line active"></div>
            <div class="progress-step active">
                <div class="progress-icon">
                    <svg viewBox="0 0 24 24"><path d="M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-5-2c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm11 15H4v-2h16v2zm0-5H4V8h5.08L7 10.83 8.62 12 11 8.76l1-1.36 1 1.36L15.38 12 17 10.83 14.92 8H20v6z"/></svg>
                </div>
                <div class="progress-label">商品準備</div>
                <div class="progress-time">處理中</div>
            </div>
            <div class="progress-line"></div>
            <div class="progress-step">
                <div class="progress-icon">
                    <svg viewBox="0 0 24 24"><path d="M18 18.5c.83 0 1.5-.67 1.5-1.5s-.67-1.5-1.5-1.5-1.5.67-1.5 1.5.67 1.5 1.5 1.5zm1.5-9H17V12h4.46L19.5 9.5zM6 18.5c.83 0 1.5-.67 1.5-1.5s-.67-1.5-1.5-1.5-1.5.67-1.5 1.5.67 1.5 1.5 1.5zM20 8l3 4v5h-2c0 1.66-1.34 3-3 3s-3-1.34-3-3H9c0 1.66-1.34 3-3 3s-3-1.34-3-3H1V6c0-1.11.89-2 2-2h14v4h3zM8 6H4v6h4V6z"/></svg>
                </div>
                <div class="progress-label">已出庫</div>
                <div class="progress-time">等待中</div>
            </div>
        </div>
    </div>

    <div class="detail-card">
        <h3 class="detail-title">
            <svg viewBox="0 0 24 24" width="18" height="18" style="vertical-align:middle;margin-right:8px;fill:#333"><path d="M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-5-2c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm11 15H4v-2h16v2zm0-5H4V8h5.08L7 10.83 8.62 12 11 8.76l1-1.36 1 1.36L15.38 12 17 10.83 14.92 8H20v6z"/></svg>
            商品明細
        </h3>
        <?php foreach ($products as $product): ?>
        <div class="product-row" style="<?php echo $product !== end($products) ? 'border-bottom:1px solid #f0f0f0;padding-bottom:15px;margin-bottom:15px;' : ''; ?>">
            <div class="product-img">
                <?php if ($product['image']): ?><img src="<?php echo esc_url($product['image']); ?>">
                <?php else: ?><svg width="50" height="50" fill="#ddd" viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg><?php endif; ?>
            </div>
            <div class="product-info">
                <h4><?php echo esc_html($product['name']); ?></h4>
                <p>數量：<?php echo $product['qty']; ?></p>
            </div>
            <div class="product-price">$<?php echo number_format($order->amount, 0); ?></div>
        </div>
        <?php endforeach; ?>
        <div class="product-total">
            <span>訂單總額</span>
            <strong>$<?php echo number_format($order->amount, 0); ?></strong>
        </div>
    </div>

    <div class="detail-card">
        <h3 class="detail-title">
            <svg viewBox="0 0 24 24" width="18" height="18" style="vertical-align:middle;margin-right:8px;fill:#333"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
            訂購資訊
        </h3>
        <div class="detail-grid cols-2">
            <div>
                <span class="label">用戶</span>
                <span class="value">
                    <?php echo esc_html($order->recipient_name ?: '—'); ?>
                    <span class="verified-badge">
                        <svg viewBox="0 0 24 24" width="14" height="14"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z" fill="#52c41a"/></svg>
                        實名
                    </span>
                </span>
            </div>
            <div><span class="label">付款方式</span><span class="value"><span style="background:#fff3e0;color:#f57c00;padding:4px 10px;border-radius:4px;font-weight:600;display:inline-block;">金融卡認證+信用購(先買後付)</span></span></div>
            <div><span class="label">聯絡電話</span><span class="value"><?php echo esc_html($order->phone ?: '—'); ?></span></div>
            <div><span class="label">下單時間</span><span class="value"><?php echo date('Y/m/d H:i', strtotime($order->created_at)); ?></span></div>
            <div><span class="label">預計出貨時間</span><span class="value"><?php echo date('Y/m/d', strtotime('+3 days', strtotime($order->created_at))); ?></span></div>
        </div>
    </div>

    <div class="detail-card">
        <h3 class="detail-title">
            <svg viewBox="0 0 24 24" width="18" height="18" style="vertical-align:middle;margin-right:8px;fill:#333"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>
            收件資訊
        </h3>
        <div class="detail-grid">
            <div>
                <span class="label">收貨人</span>
                <span class="value">
                    **
                    <span class="privacy-badge">
                        <svg viewBox="0 0 24 24" width="12" height="12"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z" fill="#999"/></svg>
                        隱私保護
                    </span>
                </span>
            </div>
            <div class="full-width">
                <span class="label">地址</span>
                <span class="value">
                    <?php echo esc_html($masked_address); ?>
                    <span class="privacy-badge">
                        <svg viewBox="0 0 24 24" width="12" height="12"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z" fill="#999"/></svg>
                        隱私保護
                    </span>
                </span>
            </div>
        </div>
    </div>

    <div class="detail-actions">
        <a href="<?php echo esc_url($contact_link); ?>" target="_blank" rel="noopener" class="btn-contact-large">
            <svg viewBox="0 0 24 24" width="20" height="20" style="fill:#fff;margin-right:8px;"><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 12h-2v-2h2v2zm0-4h-2V6h2v4z"/></svg>
            聯繫客服
        </a>
    </div>
</div>
        <?php
    }
    
    // ========== 隐私保护函数 ==========
    private static function mask_address($address) {
        if (empty($address)) return '***';
        $len = mb_strlen($address);
        if ($len <= 8) return str_repeat('*', $len) . '號 (隱私保護)';
        return mb_substr($address, 0, 8) . str_repeat('*', min($len - 8, 5)) . '號 (隱私保護)';
    }
    
    // ========== 解析商品列表 ==========
    private static function parse_product_list($product_string, $source = 'imported', $total_amount = 0) {
        global $wpdb;
        
        if (empty($product_string)) {
            return [];
        }
        
        // 分割商品（格式：商品名 x数量, 商品名 x数量）
        $items = array_map('trim', explode(',', $product_string));
        $products = [];
        $total_calculated = 0;
        
        foreach ($items as $item) {
            // 解析商品名和数量
            if (preg_match('/^(.+?)\s*x\s*(\d+)$/u', $item, $matches)) {
                $name = trim($matches[1]);
                $qty = intval($matches[2]);
            } else {
                $name = trim($item);
                $qty = 1;
            }
            
            // 获取商品图片和价格
            $image = '';
            $unit_price = 0;
            
            if ($source === 'online') {
                // 客户下单：从产品表获取
                $product = $wpdb->get_row($wpdb->prepare(
                    "SELECT image, price FROM {$wpdb->prefix}oip_products WHERE name = %s LIMIT 1",
                    $name
                ));
                if ($product) {
                    $image = $product->image;
                    $unit_price = floatval($product->price);
                }
            } else {
                // 后台导入：使用模糊匹配
                $image = OIP_Product_Image::get_image($name);
            }
            
            $products[] = [
                'name' => $name,
                'qty' => $qty,
                'unit_price' => $unit_price,
                'price' => $unit_price * $qty,
                'image' => $image
            ];
            
            $total_calculated += $unit_price * $qty;
        }
        
        // 如果是在线订单且提供了总金额，按比例调整价格
        if ($source === 'online' && $total_amount > 0 && $total_calculated > 0) {
            $ratio = $total_amount / $total_calculated;
            foreach ($products as &$product) {
                $product['price'] = round($product['price'] * $ratio, 2);
            }
        } elseif ($source === 'online' && $total_amount > 0 && count($products) > 0) {
            // 如果无法从产品表获取价格，平均分配总金额
            $avg_price = $total_amount / count($products);
            foreach ($products as &$product) {
                $product['price'] = round($avg_price, 2);
            }
        }
        
        return $products;
    }
    
    // ========== 個人資料頁 ==========
    public static function render_profile($frontend) {
        if (!is_user_logged_in()) {
            wp_redirect(home_url('/?oip_page=login')); exit;
        }
        
        $user = wp_get_current_user();
        $shop = new OIP_Shop_Frontend();
        
        echo $shop->get_header('個人資料');
        echo self::get_orders_styles();
        ?>
<div class="page-container">
    <div class="account-layout">
        <?php echo self::render_sidebar($user, 'profile'); ?>
        
        <div class="account-main">
            <h1 class="page-title">
                <svg viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
                個人資料
            </h1>
            
            <div class="profile-form">
                <div class="form-group">
                    <label>電子郵件</label>
                    <input type="email" value="<?php echo esc_attr($user->user_email); ?>" readonly>
                </div>
                <div class="form-group">
                    <label>顯示名稱</label>
                    <input type="text" value="<?php echo esc_attr($user->display_name); ?>" readonly>
                </div>
            </div>
        </div>
    </div>
</div>
        <?php
        echo $shop->get_footer();
    }
    
    // ========== 側邊欄 ==========
    private static function render_sidebar($user, $active = 'orders') {
        $contact_url = oip_get_contact_url();
        $is_line = (bool) oip_get_line_id();
        $contact_target = $is_line ? ' target="_blank" rel="noopener"' : '';
        $contact_text = $is_line ? 'LINE 客服' : '聯繫客服';
        
        return '<div class="account-sidebar">
            <div class="user-card">
                <div class="user-avatar">' . strtoupper(mb_substr($user->display_name ?: $user->user_email, 0, 1)) . '</div>
                <div class="user-name">' . esc_html($user->display_name ?: '會員') . '</div>
                <div class="user-email">' . esc_html($user->user_email) . '</div>
            </div>
            <div class="sidebar-menu">
                <a href="' . home_url('/?oip_page=orders') . '" class="' . ($active === 'orders' ? 'active' : '') . '">
                    <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>我的訂單</a>
                <a href="' . home_url('/order-search/') . '">
                    <svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>訂單查詢</a>
                <a href="' . home_url('/?oip_page=profile') . '" class="' . ($active === 'profile' ? 'active' : '') . '">
                    <svg viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>個人資料</a>
                <a href="' . home_url('/?oip_shop=wishlist') . '">
                    <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>願望清單</a>
                <a href="' . esc_url($contact_url) . '"' . $contact_target . '>
                    <svg viewBox="0 0 24 24">' . ($is_line ? '<path d="M19.365 9.863c.349 0 .63.285.63.631 0 .345-.281.63-.63.63H17.61v1.125h1.755c.349 0 .63.283.63.63 0 .344-.281.629-.63.629h-2.386c-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63h2.386c.346 0 .627.285.627.63 0 .349-.281.63-.63.63H17.61v1.125h1.755zm-3.855 3.016c0 .27-.174.51-.432.596-.064.021-.133.031-.199.031-.211 0-.391-.09-.51-.25l-2.443-3.317v2.94c0 .344-.279.629-.631.629-.346 0-.626-.285-.626-.629V8.108c0-.27.173-.51.43-.595.06-.023.136-.033.194-.033.195 0 .375.104.495.254l2.462 3.33V8.108c0-.345.282-.63.63-.63.345 0 .63.285.63.63v4.771zm-5.741 0c0 .344-.282.629-.631.629-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63.346 0 .628.285.628.63v4.771zm-2.466.629H4.917c-.345 0-.63-.285-.63-.629V8.108c0-.345.285-.63.63-.63.348 0 .63.285.63.63v4.141h1.756c.348 0 .629.283.629.63 0 .344-.282.629-.629.629M24 10.314C24 4.943 18.615.572 12 .572S0 4.943 0 10.314c0 4.811 4.27 8.842 10.035 9.608.391.082.923.258 1.058.59.12.301.079.766.038 1.08l-.164 1.02c-.045.301-.24 1.186 1.049.645 1.291-.539 6.916-4.078 9.436-6.975C23.176 14.393 24 12.458 24 10.314"/>' : '<path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 12h-2v-2h2v2zm0-4h-2V6h2v4z"/>') . '</svg>' . $contact_text . '</a>
                <a href="' . home_url('/?oip_logout=1') . '">
                    <svg viewBox="0 0 24 24"><path d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z"/></svg>登出</a>
            </div>
        </div>';
    }
    
    // ========== 訂單頁樣式 ==========
    private static function get_orders_styles() {
        return '<style>
.page-container{max-width:1200px;margin:0 auto;padding:20px 15px;min-height:60vh}
.order-search-container{max-width:900px;margin:0 auto}
.search-card{background:#fff;border-radius:16px;padding:40px;box-shadow:0 4px 20px rgba(0,0,0,.08);margin-bottom:30px}
.search-header{text-align:center;margin-bottom:35px}
.search-header svg{margin-bottom:20px}
.search-header h1{font-size:28px;color:#333;margin:0 0 10px;font-weight:600}
.search-header p{font-size:15px;color:#999;margin:0}
.search-form{max-width:500px;margin:0 auto}
.search-input-group{position:relative;margin-bottom:20px}
.search-input-group svg{position:absolute;left:16px;top:50%;transform:translateY(-50%);pointer-events:none}
.search-input-group input{width:100%;padding:16px 16px 16px 48px;border:2px solid #e8e8e8;border-radius:12px;font-size:15px;transition:all .3s}
.search-input-group input:focus{border-color:#ee4d2d;outline:none;box-shadow:0 0 0 3px rgba(238,77,45,.1)}
.search-btn{width:100%;padding:16px;background:linear-gradient(135deg,#ee4d2d,#ff6633);color:#fff;border:none;border-radius:12px;font-size:16px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:all .3s}
.search-btn:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(238,77,45,.3)}
.search-result.empty{text-align:center;padding:40px 20px;margin-top:30px;background:#fff5f5;border-radius:12px}
.search-result.empty svg{margin-bottom:15px}
.search-result.empty h3{font-size:18px;color:#ff4d4f;margin:0 0 8px}
.search-result.empty p{font-size:14px;color:#999;margin:0}
.orders-list{background:#fff;border-radius:16px;padding:30px;box-shadow:0 4px 20px rgba(0,0,0,.08)}
.list-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:25px;padding-bottom:20px;border-bottom:2px solid #f0f0f0}
.list-header h2{font-size:20px;color:#333;margin:0;font-weight:600}
.email-badge{background:#f0f0f0;color:#666;padding:8px 16px;border-radius:20px;font-size:13px}
.order-card{border:1px solid #f0f0f0;border-radius:12px;margin-bottom:16px;overflow:hidden;transition:all .2s}
.order-card:hover{border-color:#ee4d2d;box-shadow:0 4px 16px rgba(238,77,45,.12)}
.order-header{background:#fafafa;padding:16px 20px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #f0f0f0}
.order-number{font-size:14px;color:#333}
.order-number strong{color:#ee4d2d}
.order-date{color:#999;margin-left:15px;font-size:13px}
.order-status{padding:6px 14px;border-radius:20px;font-size:12px;font-weight:500}
.order-status.processing{background:#fff3e0;color:#f57c00}
.order-body{padding:20px}
.order-product{display:flex;gap:16px;align-items:center}
.order-product-img{width:80px;height:80px;background:#f8f8f8;border-radius:8px;display:flex;align-items:center;justify-content:center;overflow:hidden}
.order-product-img img{width:100%;height:100%;object-fit:cover}
.order-product-img svg{width:40px;height:40px;fill:#ddd}
.order-product-info{flex:1}
.order-product-name{font-size:15px;color:#333;margin-bottom:6px;font-weight:500}
.order-product-meta{font-size:13px;color:#999}
.order-product-price{text-align:right}
.order-product-price .price{font-size:20px;color:#ee4d2d;font-weight:700}
.order-footer{background:#fafafa;padding:16px 20px;display:flex;justify-content:space-between;align-items:center;border-top:1px solid #f0f0f0}
.order-total{font-size:14px;color:#666}
.order-total span{font-size:20px;color:#ee4d2d;font-weight:700;margin-left:10px}
.order-actions{display:flex;gap:10px}
.order-actions a,.btn-primary,.btn-outline{padding:10px 24px;border-radius:8px;font-size:14px;transition:all .2s;display:inline-block;text-align:center}
.order-actions .btn-primary,.btn-primary{background:linear-gradient(135deg,#ee4d2d,#ff6633);color:#fff}
.order-actions .btn-primary:hover,.btn-primary:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(238,77,45,.3)}
.order-actions .btn-outline,.btn-outline{border:1px solid #ee4d2d;color:#ee4d2d;background:#fff}
.order-actions .btn-outline:hover,.btn-outline:hover{background:#fff5f5}
.detail-container{max-width:800px;margin:0 auto;position:relative}
.detail-back{display:inline-block;color:#ee4d2d;font-size:14px;margin-bottom:20px}
.detail-back:hover{text-decoration:underline}
.order-status-badge{position:absolute;top:0;right:0;background:#f6ffed;border:1px solid #b7eb8f;color:#52c41a;padding:8px 16px;border-radius:20px;font-size:13px;display:flex;align-items:center;gap:6px;font-weight:500}
.order-status-badge svg{flex-shrink:0}
.detail-card{background:#fff;border-radius:12px;padding:25px;margin-bottom:20px;box-shadow:0 2px 12px rgba(0,0,0,.06)}
.detail-header{margin-bottom:25px}
.detail-header h2{font-size:14px;color:#999;margin:0 0 8px;font-weight:400}
.order-number-large{font-size:18px;color:#333;font-weight:600;letter-spacing:0.5px;word-break:break-all;line-height:1.3}
.order-progress{display:flex;align-items:center;justify-content:space-between;margin-top:30px;padding:20px 0}
.progress-step{flex:1;text-align:center;position:relative}
.progress-icon{width:50px;height:50px;border-radius:50%;background:#f0f0f0;margin:0 auto 12px;display:flex;align-items:center;justify-content:center;transition:all .3s}
.progress-step.active .progress-icon{background:#52c41a}
.progress-icon svg{width:24px;height:24px;fill:#999}
.progress-step.active .progress-icon svg{fill:#fff}
.progress-label{font-size:14px;color:#666;margin-bottom:4px;font-weight:500}
.progress-step.active .progress-label{color:#52c41a}
.progress-time{font-size:12px;color:#999}
.progress-line{flex:1;height:2px;background:#f0f0f0;margin:0 -10px;position:relative;top:-35px}
.progress-line.active{background:#52c41a}
.detail-title{font-size:16px;color:#333;margin:0 0 20px;padding-bottom:15px;border-bottom:1px solid #f0f0f0;display:flex;align-items:center}
.detail-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}
.detail-grid .full-width{grid-column:span 2}
.detail-grid .label{display:block;font-size:13px;color:#999;margin-bottom:4px}
.detail-grid .value{font-size:14px;color:#333}
.verified-badge{display:inline-flex;align-items:center;gap:4px;background:#f6ffed;color:#52c41a;padding:2px 8px;border-radius:12px;font-size:12px;margin-left:8px}
.privacy-badge{display:inline-flex;align-items:center;gap:4px;background:#fafafa;color:#999;padding:2px 8px;border-radius:12px;font-size:11px;margin-left:8px}
.product-row{display:flex;gap:20px;align-items:center}
.product-img{width:100px;height:100px;background:#f8f8f8;border-radius:8px;overflow:hidden;display:flex;align-items:center;justify-content:center}
.product-img img{width:100%;height:100%;object-fit:cover}
.product-info{flex:1}
.product-info h4{font-size:16px;color:#333;margin:0 0 8px}
.product-info p{font-size:14px;color:#999;margin:0}
.product-price{font-size:22px;color:#ee4d2d;font-weight:700}
.product-total{display:flex;justify-content:space-between;align-items:center;padding-top:20px;margin-top:20px;border-top:2px solid #f0f0f0}
.product-total span{font-size:16px;color:#666}
.product-total strong{font-size:24px;color:#ee4d2d;font-weight:700}
.detail-actions{display:flex;gap:15px;justify-content:center;margin-top:30px}
.btn-contact-large{padding:16px 40px;border-radius:12px;font-size:18px;font-weight:600;transition:all .3s;display:inline-flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#ff6b35,#ee4d2d);color:#fff;border:none;cursor:pointer;box-shadow:0 4px 16px rgba(238,77,45,.3);min-width:280px}
.btn-contact-large:hover{transform:translateY(-2px);box-shadow:0 6px 24px rgba(238,77,45,.5)}
.btn-line{padding:10px 24px;border-radius:8px;font-size:14px;transition:all .2s;display:inline-flex;align-items:center;justify-content:center;gap:8px;background:#06c755;color:#fff;border:none;cursor:pointer}
.btn-line:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(6,199,85,.3)}
@media(max-width:768px){
.search-card{padding:30px 20px}
.search-header h1{font-size:24px}
.search-header svg{width:40px;height:40px}
.orders-list{padding:20px}
.list-header{flex-direction:column;align-items:flex-start;gap:10px}
.order-header{padding:14px 16px;flex-wrap:wrap;gap:8px}
.order-date{display:block;margin-left:0;margin-top:4px}
.order-body{padding:16px}
.order-product{gap:12px}
.order-product-img{width:70px;height:70px}
.order-product-name{font-size:14px}
.order-product-price .price{font-size:18px}
.order-footer{padding:14px 16px;flex-direction:column;gap:12px;align-items:stretch}
.order-total{text-align:center}
.order-actions{justify-content:center;flex-wrap:wrap}
.order-actions a{padding:10px 20px;font-size:13px;flex:1;min-width:120px}
.order-status-badge{position:static;margin-bottom:15px;justify-content:center}
.order-progress{padding:15px 0;overflow-x:auto}
.progress-step{min-width:80px}
.progress-line{flex:0 0 30px;min-width:30px}
.progress-icon{width:40px;height:40px}
.progress-icon svg{width:18px;height:18px}
.progress-label{font-size:12px}
.progress-time{font-size:10px}
.detail-grid{grid-template-columns:1fr}
.detail-grid .full-width{grid-column:span 1}
.detail-grid .cols-2{grid-template-columns:1fr}
.product-row{flex-direction:column;text-align:center;align-items:center}
.product-img{margin:0 auto}
.product-info{text-align:center}
.product-price{font-size:20px}
.detail-actions{flex-direction:column;gap:10px;padding:0 15px}
.detail-actions a{width:100%;padding:18px 20px;font-size:18px;min-width:auto}
.btn-contact-large{min-width:auto;width:100%;font-size:18px;padding:18px 20px}
.detail-card{padding:20px}
.detail-title{font-size:15px}
.order-number-large{font-size:15px;word-break:break-all;line-height:1.3;letter-spacing:0.3px}
.search-input-group input{font-size:16px;padding:14px 14px 14px 46px}
.search-btn{font-size:15px;padding:14px}
}
@media(max-width:480px){
.page-container{padding:15px 10px}
.search-card{padding:25px 15px;border-radius:12px}
.search-header h1{font-size:20px}
.search-header p{font-size:14px}
.order-card{border-radius:10px}
.order-product-img{width:60px;height:60px}
.order-product-name{font-size:13px}
.order-product-meta{font-size:12px}
.order-product-price .price{font-size:16px}
.order-total span{font-size:18px}
.detail-card{padding:15px;border-radius:10px}
.product-img{width:80px;height:80px}
.product-info h4{font-size:15px}
.product-total strong{font-size:20px}
}
</style>';
    }
}
