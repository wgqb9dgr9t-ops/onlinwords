<?php
/**
 * 前台頁面 - 訂單列表/詳情/個人資料
 * 使用商城統一頭部
 */

if (!defined('ABSPATH')) exit;

class OIP_Frontend_Orders {
    
    // ========== 訂單頁面 ==========
    public static function render_orders($frontend) {
        $is_logged_in = is_user_logged_in();
        $user = $is_logged_in ? wp_get_current_user() : null;
        $orders = $is_logged_in ? OIP_Order_Manager::get_user_orders(get_current_user_id()) : [];
        
        // 使用全局 LINE 客服連結
        $contact_link = oip_get_contact_url();
        $is_line = (bool) oip_get_line_id();
        
        $view_order = isset($_GET['order']) ? sanitize_text_field($_GET['order']) : null;
        $single_order = null;
        if ($view_order && $is_logged_in) {
            foreach ($orders as $o) {
                if ($o->order_number === $view_order) { $single_order = $o; break; }
            }
        }
        
        // 使用商城統一頭部
        $shop = new OIP_Shop_Frontend();
        echo $shop->get_header('我的訂單');
        echo self::get_orders_styles();
        ?>
<div class="page-container">
    <?php if (!$is_logged_in): ?>
    <div class="account-main">
        <div class="login-prompt">
            <svg viewBox="0 0 24 24"><path d="M18 6h-2c0-2.21-1.79-4-4-4S8 3.79 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6-2c1.1 0 2 .9 2 2h-4c0-1.1.9-2 2-2zm6 16H6V8h2v2c0 .55.45 1 1 1s1-.45 1-1V8h4v2c0 .55.45 1 1 1s1-.45 1-1V8h2v12z"/></svg>
            <h3>查看我的訂單</h3>
            <p>登入會員即可查看訂單狀態、追蹤物流進度</p>
            <a href="<?php echo home_url('/?oip_page=login&redirect_to=' . urlencode(home_url('/?oip_page=orders'))); ?>">立即登入</a>
        </div>
    </div>
    <?php elseif ($single_order): ?>
    <?php self::render_order_detail($single_order, $contact_link); ?>
    <?php else: ?>
    <div class="account-layout">
        <?php echo self::render_sidebar($user); ?>
        
        <div class="account-main">
            <h1 class="page-title">
                <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
                我的訂單
            </h1>
            
            <div class="order-tabs">
                <div class="order-tab active">全部訂單</div>
                <div class="order-tab">處理中</div>
                <div class="order-tab">已出貨</div>
                <div class="order-tab">已完成</div>
            </div>
            
            <?php if (empty($orders)): ?>
            <div class="empty-state">
                <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14z"/></svg>
                <h3>目前沒有訂單</h3>
                <p>快去選購喜歡的商品吧！</p>
                <a href="<?php echo home_url(); ?>">去購物</a>
            </div>
            <?php else: ?>
            <?php foreach ($orders as $order): 
                $source = isset($order->source) ? $order->source : 'imported';
                
                // 解析商品列表（格式：商品名 x数量, 商品名 x数量）
                $products = self::parse_product_list($order->product_name, $source, $order->amount);
                $first_product = !empty($products) ? $products[0] : null;
                $product_image = $first_product ? $first_product['image'] : '';
            ?>
            <div class="order-card">
                <div class="order-header">
                    <div class="order-number">訂單編號：<strong><?php echo esc_html($order->order_number); ?></strong>
                    <span class="order-date"><?php echo date('Y-m-d H:i', strtotime($order->created_at)); ?></span></div>
                    <div class="order-status processing">處理中</div>
                </div>
                <div class="order-body">
                    <div class="order-product">
                        <div class="order-product-img">
                            <?php if ($product_image): ?><img src="<?php echo esc_url($product_image); ?>" alt="">
                            <?php else: ?><svg viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg><?php endif; ?>
                        </div>
                        <div class="order-product-info">
                            <div class="order-product-name">
                                <?php if (count($products) > 1): ?>
                                    <?php echo esc_html($first_product['name']); ?> 等 <?php echo count($products); ?> 件商品
                                <?php else: ?>
                                    <?php echo esc_html($order->product_name); ?>
                                <?php endif; ?>
                            </div>
                            <div class="order-product-meta">
                                <?php if (count($products) > 1): ?>
                                    共 <?php echo array_sum(array_column($products, 'qty')); ?> 件 | 收件人：<?php echo esc_html($order->recipient_name ?: '—'); ?>
                                <?php else: ?>
                                    數量：<?php echo $first_product ? $first_product['qty'] : 1; ?> | 收件人：<?php echo esc_html($order->recipient_name ?: '—'); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="order-product-price"><div class="price">NT$ <?php echo number_format($order->amount, 0); ?></div></div>
                    </div>
                </div>
                <div class="order-footer">
                    <div class="order-total">訂單金額：<span>NT$ <?php echo number_format($order->amount, 0); ?></span></div>
                    <div class="order-actions">
                        <a href="<?php echo home_url('/?oip_page=orders&order=' . urlencode($order->order_number)); ?>" class="btn-primary">查看詳情</a>
                        <a href="<?php echo esc_url($contact_link); ?>" target="_blank" rel="noopener" class="btn-outline"><?php echo $is_line ? 'LINE 客服' : '聯繫客服'; ?></a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
        <?php
        echo $shop->get_footer();
    }
    
    // ========== 訂單詳情 ==========
    private static function render_order_detail($order, $contact_link) {
        $source = isset($order->source) ? $order->source : 'imported';
        $products = self::parse_product_list($order->product_name, $source, $order->amount);
        $is_line = (bool) oip_get_line_id();
        ?>
<div class="detail-container">
    <a href="<?php echo home_url('/?oip_page=orders'); ?>" class="detail-back">← 返回訂單列表</a>
    
    <div class="detail-card">
        <div class="detail-header">
            <h2>訂單詳情</h2>
            <span class="order-status processing">處理中</span>
        </div>
        <div class="detail-grid">
            <div><span class="label">訂單編號</span><strong class="value highlight"><?php echo esc_html($order->order_number); ?></strong></div>
            <div><span class="label">下單時間</span><span class="value"><?php echo date('Y-m-d H:i:s', strtotime($order->created_at)); ?></span></div>
            <div><span class="label">付款方式</span><span class="value">貨到付款</span></div>
            <div><span class="label">訂單金額</span><strong class="value highlight price">NT$ <?php echo number_format($order->amount, 0); ?></strong></div>
        </div>
    </div>

    <div class="detail-card">
        <h3 class="detail-title">商品資訊</h3>
        <?php foreach ($products as $product): ?>
        <div class="product-row" style="<?php echo $product !== end($products) ? 'border-bottom:1px solid #f0f0f0;padding-bottom:15px;margin-bottom:15px;' : ''; ?>">
            <div class="product-img">
                <?php if ($product['image']): ?><img src="<?php echo esc_url($product['image']); ?>">
                <?php else: ?><svg width="50" height="50" fill="#ddd" viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg><?php endif; ?>
            </div>
            <div class="product-info">
                <h4><?php echo esc_html($product['name']); ?></h4>
                <p>數量：<?php echo $product['qty']; ?></p>
            </div>
            <div class="product-price">NT$ <?php echo number_format($product['price'], 0); ?></div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="detail-card">
        <h3 class="detail-title">收件資訊</h3>
        <div class="detail-grid cols-2">
            <div><span class="label">收件人</span><span class="value"><?php echo esc_html($order->recipient_name ?: '—'); ?></span></div>
            <div><span class="label">聯絡電話</span><span class="value"><?php echo esc_html($order->phone ?: '—'); ?></span></div>
            <div class="full-width"><span class="label">收件地址</span><span class="value"><?php echo esc_html($order->recipient_address ?: '—'); ?></span></div>
        </div>
    </div>

    <div class="detail-actions">
        <a href="<?php echo esc_url($contact_link); ?>" target="_blank" rel="noopener" class="btn-primary"><?php echo $is_line ? 'LINE 客服' : '聯繫客服'; ?></a>
        <a href="<?php echo home_url('/?oip_page=orders'); ?>" class="btn-outline">返回訂單</a>
    </div>
</div>
        <?php
    }
    
    // ========== 解析商品列表 ==========
    private static function parse_product_list($product_string, $source = 'imported', $total_amount = 0) {
        global $wpdb;
        
        if (empty($product_string)) {
            return [];
        }
        
        // 分割商品（格式：商品名 x数量, 商品名 x数量）
        $items = array_map('trim', explode(',', $product_string));
        $products = [];
        $total_calculated = 0;
        
        foreach ($items as $item) {
            // 解析商品名和数量
            if (preg_match('/^(.+?)\s*x\s*(\d+)$/u', $item, $matches)) {
                $name = trim($matches[1]);
                $qty = intval($matches[2]);
            } else {
                $name = trim($item);
                $qty = 1;
            }
            
            // 获取商品图片和价格
            $image = '';
            $unit_price = 0;
            
            if ($source === 'online') {
                // 客户下单：从产品表获取
                $product = $wpdb->get_row($wpdb->prepare(
                    "SELECT image, price FROM {$wpdb->prefix}oip_products WHERE name = %s LIMIT 1",
                    $name
                ));
                if ($product) {
                    $image = $product->image;
                    $unit_price = floatval($product->price);
                }
            } else {
                // 后台导入：使用模糊匹配
                $image = OIP_Product_Image::get_image($name);
            }
            
            $products[] = [
                'name' => $name,
                'qty' => $qty,
                'unit_price' => $unit_price,
                'price' => $unit_price * $qty,
                'image' => $image
            ];
            
            $total_calculated += $unit_price * $qty;
        }
        
        // 如果是在线订单且提供了总金额，按比例调整价格
        if ($source === 'online' && $total_amount > 0 && $total_calculated > 0) {
            $ratio = $total_amount / $total_calculated;
            foreach ($products as &$product) {
                $product['price'] = round($product['price'] * $ratio, 2);
            }
        } elseif ($source === 'online' && $total_amount > 0 && count($products) > 0) {
            // 如果无法从产品表获取价格，平均分配总金额
            $avg_price = $total_amount / count($products);
            foreach ($products as &$product) {
                $product['price'] = round($avg_price, 2);
            }
        }
        
        return $products;
    }
    
    // ========== 個人資料頁 ==========
    public static function render_profile($frontend) {
        if (!is_user_logged_in()) {
            wp_redirect(home_url('/?oip_page=login')); exit;
        }
        
        $user = wp_get_current_user();
        $shop = new OIP_Shop_Frontend();
        
        echo $shop->get_header('個人資料');
        echo self::get_orders_styles();
        ?>
<div class="page-container">
    <div class="account-layout">
        <?php echo self::render_sidebar($user, 'profile'); ?>
        
        <div class="account-main">
            <h1 class="page-title">
                <svg viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
                個人資料
            </h1>
            
            <div class="profile-form">
                <div class="form-group">
                    <label>電子郵件</label>
                    <input type="email" value="<?php echo esc_attr($user->user_email); ?>" readonly>
                </div>
                <div class="form-group">
                    <label>顯示名稱</label>
                    <input type="text" value="<?php echo esc_attr($user->display_name); ?>" readonly>
                </div>
            </div>
        </div>
    </div>
</div>
        <?php
        echo $shop->get_footer();
    }
    
    // ========== 側邊欄 ==========
    private static function render_sidebar($user, $active = 'orders') {
        $contact_url = oip_get_contact_url();
        $is_line = (bool) oip_get_line_id();
        $contact_target = $is_line ? ' target="_blank" rel="noopener"' : '';
        $contact_text = $is_line ? 'LINE 客服' : '聯繫客服';
        
        return '<div class="account-sidebar">
            <div class="user-card">
                <div class="user-avatar">' . strtoupper(mb_substr($user->display_name ?: $user->user_email, 0, 1)) . '</div>
                <div class="user-name">' . esc_html($user->display_name ?: '會員') . '</div>
                <div class="user-email">' . esc_html($user->user_email) . '</div>
            </div>
            <div class="sidebar-menu">
                <a href="' . home_url('/?oip_page=orders') . '" class="' . ($active === 'orders' ? 'active' : '') . '">
                    <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>我的訂單</a>
                <a href="' . home_url('/?oip_page=profile') . '" class="' . ($active === 'profile' ? 'active' : '') . '">
                    <svg viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>個人資料</a>
                <a href="' . home_url('/?oip_shop=wishlist') . '">
                    <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>願望清單</a>
                <a href="' . esc_url($contact_url) . '"' . $contact_target . '>
                    <svg viewBox="0 0 24 24">' . ($is_line ? '<path d="M19.365 9.863c.349 0 .63.285.63.631 0 .345-.281.63-.63.63H17.61v1.125h1.755c.349 0 .63.283.63.63 0 .344-.281.629-.63.629h-2.386c-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63h2.386c.346 0 .627.285.627.63 0 .349-.281.63-.63.63H17.61v1.125h1.755zm-3.855 3.016c0 .27-.174.51-.432.596-.064.021-.133.031-.199.031-.211 0-.391-.09-.51-.25l-2.443-3.317v2.94c0 .344-.279.629-.631.629-.346 0-.626-.285-.626-.629V8.108c0-.27.173-.51.43-.595.06-.023.136-.033.194-.033.195 0 .375.104.495.254l2.462 3.33V8.108c0-.345.282-.63.63-.63.345 0 .63.285.63.63v4.771zm-5.741 0c0 .344-.282.629-.631.629-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63.346 0 .628.285.628.63v4.771zm-2.466.629H4.917c-.345 0-.63-.285-.63-.629V8.108c0-.345.285-.63.63-.63.348 0 .63.285.63.63v4.141h1.756c.348 0 .629.283.629.63 0 .344-.282.629-.629.629M24 10.314C24 4.943 18.615.572 12 .572S0 4.943 0 10.314c0 4.811 4.27 8.842 10.035 9.608.391.082.923.258 1.058.59.12.301.079.766.038 1.08l-.164 1.02c-.045.301-.24 1.186 1.049.645 1.291-.539 6.916-4.078 9.436-6.975C23.176 14.393 24 12.458 24 10.314"/>' : '<path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 12h-2v-2h2v2zm0-4h-2V6h2v4z"/>') . '</svg>' . $contact_text . '</a>
                <a href="' . home_url('/?oip_logout=1') . '">
                    <svg viewBox="0 0 24 24"><path d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z"/></svg>登出</a>
            </div>
        </div>';
    }
    
    // ========== 訂單頁樣式 ==========
    private static function get_orders_styles() {
        return '<style>
.page-container{max-width:1200px;margin:0 auto;padding:20px 15px;min-height:60vh}
.account-layout{display:grid;grid-template-columns:260px 1fr;gap:25px;padding:20px 0}
.account-sidebar{background:#fff;border-radius:12px;padding:25px;height:fit-content;box-shadow:0 2px 12px rgba(0,0,0,.06)}
.user-card{text-align:center;padding-bottom:20px;border-bottom:1px solid #f0f0f0;margin-bottom:20px}
.user-avatar{width:80px;height:80px;background:linear-gradient(135deg,#ee4d2d,#ff6633);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 15px;color:#fff;font-size:32px;font-weight:700}
.user-name{font-size:16px;color:#333;font-weight:600;margin-bottom:5px}
.user-email{font-size:13px;color:#999}
.sidebar-menu a{display:flex;align-items:center;gap:12px;padding:14px 16px;color:#555;font-size:14px;border-radius:8px;margin-bottom:4px;transition:all .2s}
.sidebar-menu a:hover{background:#fff5f5;color:#ee4d2d}
.sidebar-menu a.active{background:linear-gradient(135deg,#ee4d2d,#ff6633);color:#fff}
.sidebar-menu a.active svg{fill:#fff}
.sidebar-menu svg{width:20px;height:20px;fill:#888}
.account-main{background:#fff;border-radius:12px;padding:30px;box-shadow:0 2px 12px rgba(0,0,0,.06)}
.page-title{font-size:20px;color:#333;margin-bottom:25px;padding-bottom:15px;border-bottom:2px solid #ee4d2d;display:flex;align-items:center;gap:10px}
.page-title svg{width:24px;height:24px;fill:#ee4d2d}
.order-tabs{display:flex;gap:8px;margin-bottom:25px;padding-bottom:15px;border-bottom:1px solid #f0f0f0}
.order-tab{padding:10px 20px;font-size:14px;color:#666;border-radius:20px;cursor:pointer;transition:all .2s}
.order-tab:hover{color:#ee4d2d;background:#fff5f5}
.order-tab.active{background:linear-gradient(135deg,#ee4d2d,#ff6633);color:#fff}
.order-card{border:1px solid #f0f0f0;border-radius:12px;margin-bottom:16px;overflow:hidden;transition:all .2s}
.order-card:hover{border-color:#ee4d2d;box-shadow:0 4px 16px rgba(238,77,45,.12)}
.order-header{background:#fafafa;padding:16px 20px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #f0f0f0}
.order-number{font-size:14px;color:#333}
.order-number strong{color:#ee4d2d}
.order-date{color:#999;margin-left:15px;font-size:13px}
.order-status{padding:6px 14px;border-radius:20px;font-size:12px;font-weight:500}
.order-status.processing{background:#fff3e0;color:#f57c00}
.order-status.shipped{background:#e3f2fd;color:#1976d2}
.order-status.delivered{background:#e8f5e9;color:#388e3c}
.order-body{padding:20px}
.order-product{display:flex;gap:16px;align-items:center}
.order-product-img{width:80px;height:80px;background:#f8f8f8;border-radius:8px;display:flex;align-items:center;justify-content:center;overflow:hidden}
.order-product-img img{width:100%;height:100%;object-fit:cover}
.order-product-img svg{width:40px;height:40px;fill:#ddd}
.order-product-info{flex:1}
.order-product-name{font-size:15px;color:#333;margin-bottom:6px;font-weight:500}
.order-product-meta{font-size:13px;color:#999}
.order-product-price{text-align:right}
.order-product-price .price{font-size:20px;color:#ee4d2d;font-weight:700}
.order-footer{background:#fafafa;padding:16px 20px;display:flex;justify-content:space-between;align-items:center;border-top:1px solid #f0f0f0}
.order-total{font-size:14px;color:#666}
.order-total span{font-size:20px;color:#ee4d2d;font-weight:700;margin-left:10px}
.order-actions{display:flex;gap:10px}
.order-actions a,.btn-primary,.btn-outline{padding:10px 24px;border-radius:8px;font-size:14px;transition:all .2s;display:inline-block;text-align:center}
.order-actions .btn-primary,.btn-primary{background:linear-gradient(135deg,#ee4d2d,#ff6633);color:#fff}
.order-actions .btn-primary:hover,.btn-primary:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(238,77,45,.3)}
.order-actions .btn-outline,.btn-outline{border:1px solid #ee4d2d;color:#ee4d2d;background:#fff}
.order-actions .btn-outline:hover,.btn-outline:hover{background:#fff5f5}
.empty-state{text-align:center;padding:80px 20px}
.empty-state svg{width:100px;height:100px;fill:#ddd;margin-bottom:20px}
.empty-state h3{font-size:18px;color:#333;margin-bottom:10px}
.empty-state p{color:#999;margin-bottom:25px}
.empty-state a{display:inline-block;padding:14px 40px;background:linear-gradient(135deg,#ee4d2d,#ff6633);color:#fff;border-radius:8px}
.login-prompt{text-align:center;padding:80px 20px}
.login-prompt svg{width:100px;height:100px;fill:#ee4d2d;margin-bottom:20px}
.login-prompt h3{font-size:22px;color:#333;margin-bottom:10px}
.login-prompt p{color:#666;margin-bottom:30px;font-size:15px}
.login-prompt a{display:inline-block;padding:16px 50px;background:linear-gradient(135deg,#ee4d2d,#ff6633);color:#fff;border-radius:8px;font-size:16px;font-weight:500}
.detail-container{max-width:800px;margin:0 auto}
.detail-back{display:inline-block;color:#ee4d2d;font-size:14px;margin-bottom:20px}
.detail-back:hover{text-decoration:underline}
.detail-card{background:#fff;border-radius:12px;padding:25px;margin-bottom:20px;box-shadow:0 2px 12px rgba(0,0,0,.06)}
.detail-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}
.detail-header h2{font-size:18px;color:#333;margin:0}
.detail-title{font-size:16px;color:#333;margin:0 0 20px;padding-bottom:15px;border-bottom:1px solid #f0f0f0}
.detail-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}
.detail-grid.cols-2{grid-template-columns:repeat(2,1fr)}
.detail-grid .full-width{grid-column:span 2}
.detail-grid .label{display:block;font-size:13px;color:#999;margin-bottom:4px}
.detail-grid .value{font-size:14px;color:#333}
.detail-grid .highlight{color:#ee4d2d}
.detail-grid .price{font-size:20px;font-weight:700}
.product-row{display:flex;gap:20px;align-items:center}
.product-img{width:100px;height:100px;background:#f8f8f8;border-radius:8px;overflow:hidden;display:flex;align-items:center;justify-content:center}
.product-img img{width:100%;height:100%;object-fit:cover}
.product-info{flex:1}
.product-info h4{font-size:16px;color:#333;margin:0 0 8px}
.product-info p{font-size:14px;color:#999;margin:0}
.product-price{font-size:22px;color:#ee4d2d;font-weight:700}
.detail-actions{display:flex;gap:15px;justify-content:center;margin-top:30px}
.profile-form{max-width:400px}
.form-group{margin-bottom:20px}
.form-group label{display:block;font-size:14px;color:#666;margin-bottom:8px}
.form-group input{width:100%;padding:14px 16px;border:1px solid #e8e8e8;border-radius:8px;background:#f8f8f8;font-size:14px;color:#333}
@media(max-width:900px){.account-layout{grid-template-columns:1fr}.account-sidebar{display:none}}
@media(max-width:768px){
.account-main{padding:20px}
.page-title{font-size:18px;margin-bottom:20px}
.order-tabs{overflow-x:auto;gap:6px;padding-bottom:12px}
.order-tab{padding:8px 16px;font-size:13px;white-space:nowrap}
.order-header{padding:14px 16px;flex-wrap:wrap;gap:8px}
.order-date{display:block;margin-left:0;margin-top:4px}
.order-body{padding:16px}
.order-product{gap:12px}
.order-product-img{width:70px;height:70px}
.order-product-name{font-size:14px}
.order-product-price .price{font-size:18px}
.order-footer{padding:14px 16px;flex-direction:column;gap:12px;align-items:stretch}
.order-total{text-align:center}
.order-actions{justify-content:center}
.order-actions a{padding:10px 20px;font-size:13px}
.detail-grid{grid-template-columns:1fr}
.detail-grid .full-width{grid-column:span 1}
.product-row{flex-direction:column;text-align:center}
.product-img{margin:0 auto}
.detail-actions{flex-direction:column}
.detail-actions a{width:100%}
}
</style>';
    }
}
