<?php
/**
 * 前台頁面 - 登入/註冊/重置密碼
 * 使用商城統一頭部
 */

if (!defined('ABSPATH')) exit;

class OIP_Frontend_Auth {
    
    // ========== 登入頁面 ==========
    public static function render_login($frontend) {
        if (is_user_logged_in()) { wp_redirect(home_url('/?oip_page=orders')); exit; }
        
        $login_error = $_GET['login_error'] ?? '';
        $reg_error = $_GET['reg_error'] ?? '';
        $forgot_error = $_GET['forgot_error'] ?? '';
        $forgot_success = $_GET['forgot_success'] ?? '';
        $reset_success = $_GET['reset_success'] ?? '';
        $tab = $_GET['tab'] ?? 'login';
        if (!in_array($tab, ['login', 'register', 'forgot'])) $tab = 'login';
        $redirect_to = isset($_GET['redirect_to']) ? esc_url($_GET['redirect_to']) : home_url('/?oip_page=orders');
        
        // 使用商城統一頭部
        $shop = new OIP_Shop_Frontend();
        echo $shop->get_header('會員登入');
        ?>
<style>
.login-page{max-width:1200px;margin:0 auto;padding:40px 15px;min-height:60vh}
.login-container{display:flex;gap:40px}
.login-banner{flex:1;background:linear-gradient(135deg,#ee4d2d,#ff6633);border-radius:8px;padding:60px 40px;color:#fff;display:flex;flex-direction:column;justify-content:center}
.login-banner h2{font-size:32px;margin-bottom:20px}
.login-banner p{font-size:16px;opacity:.9;line-height:1.8;margin-bottom:30px}
.login-banner ul{list-style:none;padding:0;margin:0}
.login-banner li{padding:10px 0;font-size:15px;display:flex;align-items:center;gap:10px}
.login-banner li svg{width:24px;height:24px;fill:#fff}
.login-card{width:420px;flex-shrink:0;background:#fff;border-radius:8px;box-shadow:0 2px 12px rgba(0,0,0,.1);padding:40px}
.login-tabs{display:flex;margin-bottom:30px;border-bottom:2px solid #eee}
.login-tab{flex:1;padding:15px;text-align:center;font-size:16px;color:#999;cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-2px;background:none;border-left:none;border-right:none;border-top:none}
.login-tab:hover{color:#ee4d2d}
.login-tab.active{color:#ee4d2d;border-bottom-color:#ee4d2d;font-weight:500}
.auth-form-group{margin-bottom:20px}
.auth-form-label{display:block;font-size:14px;color:#333;margin-bottom:8px;font-weight:500}
.auth-form-input{width:100%;padding:14px 15px;border:1px solid #ddd;border-radius:4px;font-size:15px;outline:none;box-sizing:border-box}
.auth-form-input:focus{border-color:#ee4d2d}
.auth-error-msg{background:#fff5f5;border:1px solid #ee4d2d;color:#ee4d2d;padding:12px 15px;border-radius:4px;margin-bottom:20px;font-size:14px}
.auth-success-msg{background:#e8f5e9;border:1px solid #4caf50;color:#388e3c;padding:12px 15px;border-radius:4px;margin-bottom:20px;font-size:14px}
.login-btn{width:100%;padding:16px;background:#ee4d2d;color:#fff;border:none;border-radius:4px;font-size:16px;font-weight:500;cursor:pointer}
.login-btn:hover{background:#d73211}
.auth-form-hint{font-size:12px;color:#999;margin-top:5px}
.login-footer{text-align:center;margin-top:25px;font-size:14px;color:#666}
.login-footer a{color:#ee4d2d}
.tab-content{display:none}
.tab-content.active{display:block}
.forgot-link{text-align:right;margin-top:-10px;margin-bottom:20px}
.forgot-link a{color:#ee4d2d;font-size:13px}
@media(max-width:900px){.login-container{flex-direction:column}.login-banner{display:none}.login-card{width:100%;max-width:420px;margin:0 auto}}
</style>

<div class="login-page">
    <div class="login-container">
        <div class="login-banner">
            <h2>歡迎加入！</h2>
            <p>註冊成為會員，享受更多專屬優惠和便捷服務。</p>
            <ul>
                <li><svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>查看訂單狀態和物流追蹤</li>
                <li><svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>享受會員專屬優惠價格</li>
                <li><svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>快速結帳，免重複填寫資料</li>
            </ul>
        </div>
        <div class="login-card">
            <?php if ($tab !== 'forgot'): ?>
            <div class="login-tabs">
                <div class="login-tab <?php echo $tab === 'login' ? 'active' : ''; ?>" onclick="switchTab('login')">會員登入</div>
                <div class="login-tab <?php echo $tab === 'register' ? 'active' : ''; ?>" onclick="switchTab('register')">註冊新帳號</div>
            </div>
            <?php endif; ?>
            
            <!-- 登入表單 -->
            <div id="login-form" class="tab-content <?php echo $tab === 'login' ? 'active' : ''; ?>">
                <?php if ($reset_success === '1'): ?><div class="auth-success-msg">✓ 密碼重置成功，請使用新密碼登入</div><?php endif; ?>
                <?php if ($login_error === 'empty'): ?><div class="auth-error-msg">⚠ 請輸入電子郵件和密碼</div>
                <?php elseif ($login_error === 'notfound'): ?><div class="auth-error-msg">⚠ 此帳號尚未註冊，請先註冊</div>
                <?php elseif ($login_error === 'wrong'): ?><div class="auth-error-msg">⚠ 密碼錯誤，請重新輸入</div><?php endif; ?>
                
                <form method="post">
                    <?php wp_nonce_field('oip_login_action', 'oip_login_nonce'); ?>
                    <input type="hidden" name="redirect_to" value="<?php echo esc_attr($redirect_to); ?>">
                    <div class="auth-form-group">
                        <label class="auth-form-label">電子郵件</label>
                        <input type="email" name="oip_email" class="auth-form-input" placeholder="請輸入您的電子郵件" required>
                    </div>
                    <div class="auth-form-group">
                        <label class="auth-form-label">密碼</label>
                        <input type="password" name="oip_password" class="auth-form-input" placeholder="請輸入密碼" required>
                    </div>
                    <div class="forgot-link"><a href="<?php echo home_url('/?oip_page=login&tab=forgot'); ?>">忘記密碼？</a></div>
                    <button type="submit" name="oip_login_submit" class="login-btn">登入</button>
                </form>
                <div class="login-footer"><p style="margin-top:15px"><a href="<?php echo home_url(); ?>">← 返回首頁</a></p></div>
            </div>
            
            <!-- 註冊表單 -->
            <div id="register-form" class="tab-content <?php echo $tab === 'register' ? 'active' : ''; ?>">
                <?php if ($reg_error === 'empty'): ?><div class="auth-error-msg">⚠ 請填寫所有欄位</div>
                <?php elseif ($reg_error === 'short'): ?><div class="auth-error-msg">⚠ 密碼至少需要6位</div>
                <?php elseif ($reg_error === 'mismatch'): ?><div class="auth-error-msg">⚠ 兩次輸入的密碼不一致</div>
                <?php elseif ($reg_error === 'invalid_email'): ?><div class="auth-error-msg">⚠ 請輸入有效的電子郵件</div>
                <?php elseif ($reg_error === 'exists'): ?><div class="auth-error-msg">⚠ 此電子郵件已被註冊</div>
                <?php elseif ($reg_error === 'failed'): ?><div class="auth-error-msg">⚠ 註冊失敗，請稍後再試</div><?php endif; ?>
                
                <form method="post">
                    <?php wp_nonce_field('oip_register_action', 'oip_register_nonce'); ?>
                    <input type="hidden" name="redirect_to" value="<?php echo esc_attr($redirect_to); ?>">
                    <div class="auth-form-group">
                        <label class="auth-form-label">電子郵件</label>
                        <input type="email" name="reg_email" class="auth-form-input" placeholder="請輸入您的電子郵件" required>
                        <p class="auth-form-hint">此郵件將作為您的登入帳號</p>
                    </div>
                    <div class="auth-form-group">
                        <label class="auth-form-label">密碼</label>
                        <input type="password" name="reg_password" class="auth-form-input" placeholder="請設定密碼（至少6位）" required minlength="6">
                    </div>
                    <div class="auth-form-group">
                        <label class="auth-form-label">確認密碼</label>
                        <input type="password" name="reg_password2" class="auth-form-input" placeholder="請再次輸入密碼" required minlength="6">
                    </div>
                    <button type="submit" name="oip_register_submit" class="login-btn">註冊</button>
                </form>
                <div class="login-footer"><p style="margin-top:15px"><a href="<?php echo home_url(); ?>">← 返回首頁</a></p></div>
            </div>
            
            <!-- 找回密碼表單 -->
            <div id="forgot-form" class="tab-content <?php echo $tab === 'forgot' ? 'active' : ''; ?>">
                <h3 style="font-size:20px;color:#333;margin-bottom:10px;text-align:center;">找回密碼</h3>
                <p style="color:#666;font-size:14px;text-align:center;margin-bottom:25px;">輸入您的電子郵件，我們將發送重置密碼連結</p>
                
                <?php if ($forgot_success === '1'): ?><div class="auth-success-msg">✓ 如果該郵箱已註冊，重置密碼郵件已發送</div><?php endif; ?>
                <?php if ($forgot_error === 'invalid'): ?><div class="auth-error-msg">⚠ 請輸入有效的電子郵件</div>
                <?php elseif ($forgot_error === 'too_fast'): ?><div class="auth-error-msg">⚠ 請求過於頻繁，請稍後再試</div>
                <?php elseif ($forgot_error === 'send_failed'): ?><div class="auth-error-msg">⚠ 郵件發送失敗，請稍後再試</div><?php endif; ?>
                
                <form method="post">
                    <?php wp_nonce_field('oip_forgot_action', 'oip_forgot_nonce'); ?>
                    <div class="auth-form-group">
                        <label class="auth-form-label">電子郵件</label>
                        <input type="email" name="forgot_email" class="auth-form-input" placeholder="請輸入您註冊時的電子郵件" required>
                    </div>
                    <button type="submit" name="oip_forgot_submit" class="login-btn">發送重置郵件</button>
                </form>
                <div class="login-footer"><p style="margin-top:15px"><a href="<?php echo home_url('/?oip_page=login'); ?>">← 返回登入</a></p></div>
            </div>
        </div>
</div>
</div>

<script>
function switchTab(tab) {
    document.querySelectorAll('.login-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    document.querySelector('.login-tab:' + (tab === 'login' ? 'first-child' : 'last-child')).classList.add('active');
    document.getElementById(tab + '-form').classList.add('active');
}
</script>
        <?php
        echo $shop->get_footer();
    }
    
    // ========== 重置密碼頁面 ==========
    public static function render_reset_password($frontend) {
        $key = sanitize_text_field($_GET['key'] ?? '');
        $login = sanitize_text_field($_GET['login'] ?? '');
        $reset_error = $_GET['reset_error'] ?? '';
        
        if (empty($key) || empty($login)) {
            wp_redirect(home_url('/?oip_page=login')); exit;
        }
        
        $user = check_password_reset_key($key, $login);
        if (is_wp_error($user)) {
            wp_redirect(add_query_arg('reset_error', 'invalid_key', home_url('/?oip_page=login'))); exit;
        }
        
        // 使用商城統一頭部
        $shop = new OIP_Shop_Frontend();
        echo $shop->get_header('重置密碼');
        ?>
<style>
.reset-page{max-width:1200px;margin:0 auto;padding:40px 15px;min-height:60vh}
.reset-container{max-width:420px;margin:20px auto;background:#fff;border-radius:8px;box-shadow:0 2px 12px rgba(0,0,0,.1);padding:40px}
.reset-title{font-size:24px;color:#333;text-align:center;margin-bottom:10px}
.reset-desc{color:#666;font-size:14px;text-align:center;margin-bottom:30px}
.auth-form-group{margin-bottom:20px}
.auth-form-label{display:block;font-size:14px;color:#333;margin-bottom:8px;font-weight:500}
.auth-form-input{width:100%;padding:14px 15px;border:1px solid #ddd;border-radius:4px;font-size:15px;outline:none;box-sizing:border-box}
.auth-form-input:focus{border-color:#ee4d2d}
.auth-error-msg{background:#fff5f5;border:1px solid #ee4d2d;color:#ee4d2d;padding:12px 15px;border-radius:4px;margin-bottom:20px;font-size:14px}
.reset-btn{width:100%;padding:16px;background:#ee4d2d;color:#fff;border:none;border-radius:4px;font-size:16px;font-weight:500;cursor:pointer}
.reset-btn:hover{background:#d73211}
</style>

<div class="reset-page">
    <div class="reset-container">
        <h2 class="reset-title">設置新密碼</h2>
        <p class="reset-desc">請輸入您的新密碼</p>
        
        <?php if ($reset_error === 'short'): ?><div class="auth-error-msg">⚠ 密碼至少需要6位</div>
        <?php elseif ($reset_error === 'mismatch'): ?><div class="auth-error-msg">⚠ 兩次輸入的密碼不一致</div><?php endif; ?>
        
        <form method="post">
            <?php wp_nonce_field('oip_reset_action', 'oip_reset_nonce'); ?>
            <input type="hidden" name="reset_key" value="<?php echo esc_attr($key); ?>">
            <input type="hidden" name="reset_login" value="<?php echo esc_attr($login); ?>">
            <div class="auth-form-group">
                <label class="auth-form-label">新密碼</label>
                <input type="password" name="new_password" class="auth-form-input" placeholder="請輸入新密碼（至少6位）" required minlength="6">
            </div>
            <div class="auth-form-group">
                <label class="auth-form-label">確認新密碼</label>
                <input type="password" name="new_password2" class="auth-form-input" placeholder="請再次輸入新密碼" required minlength="6">
            </div>
            <button type="submit" name="oip_reset_submit" class="reset-btn">確認重置</button>
        </form>
    </div>
</div>
        <?php
        echo $shop->get_footer();
    }
}
