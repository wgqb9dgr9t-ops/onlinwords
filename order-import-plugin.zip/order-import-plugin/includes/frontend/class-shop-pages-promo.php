<?php
/**
 * 商城頁面 - 限時特賣、新品上市、熱銷排行
 * 簡潔風格，參考樂天設計
 */

if (!defined('ABSPATH')) {
    exit;
}

class OIP_Shop_Pages_Promo {
    
    // ========== 簡潔樣式 ==========
    private static function get_promo_styles() {
        return '<style>
/* 頁面標題區 */
.page-banner{background:#fff;border-bottom:3px solid #ee4d2d;padding:25px 20px;margin-bottom:20px}
.page-banner .banner-inner{max-width:1200px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:15px}
.page-banner h1{font-size:22px;color:#333;margin:0;display:flex;align-items:center;gap:10px}
.page-banner h1 svg{width:28px;height:28px;fill:#ee4d2d}
.page-banner .banner-info{font-size:14px;color:#666}
.page-banner .banner-info span{margin-left:20px}
.page-banner .banner-info strong{color:#ee4d2d}

/* 倒計時（限時特賣用） */
.countdown-inline{display:flex;align-items:center;gap:8px;background:#fff5f5;padding:8px 15px;border-radius:6px;border:1px solid #ffccc7}
.countdown-inline .label{font-size:13px;color:#666}
.countdown-inline .timer{display:flex;gap:4px}
.countdown-inline .time-unit{background:#ee4d2d;color:#fff;padding:4px 8px;border-radius:4px;font-size:14px;font-weight:600;min-width:32px;text-align:center}
.countdown-inline .sep{color:#ee4d2d;font-weight:600;line-height:28px}

/* 篩選/排序欄 */
.filter-bar{background:#fff;padding:12px 20px;border-radius:8px;margin-bottom:20px;display:flex;align-items:center;gap:15px;flex-wrap:wrap;box-shadow:0 1px 4px rgba(0,0,0,.06)}
.filter-bar .filter-label{font-size:13px;color:#999}
.filter-bar .filter-tabs{display:flex;gap:8px}
.filter-bar .tab{padding:6px 16px;border-radius:4px;font-size:13px;color:#666;background:#f5f5f5;cursor:pointer;transition:all .2s;border:none}
.filter-bar .tab:hover{background:#fff5f5;color:#ee4d2d}
.filter-bar .tab.active{background:#ee4d2d;color:#fff}
.filter-bar .product-count{margin-left:auto;font-size:13px;color:#999}

/* 商品網格 */
.products-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:15px}
.product-item{background:#fff;border-radius:8px;overflow:hidden;transition:all .2s;border:1px solid #f0f0f0}
.product-item:hover{box-shadow:0 4px 15px rgba(0,0,0,.1);border-color:#ee4d2d}
.product-item a{display:block;text-decoration:none;color:inherit}
.product-item .img-wrap{position:relative;aspect-ratio:1;overflow:hidden;background:#f8f8f8}
.product-item .img-wrap img{width:100%;height:100%;object-fit:cover;transition:transform .3s}
.product-item:hover .img-wrap img{transform:scale(1.05)}
.product-item .img-wrap .tag{position:absolute;top:8px;left:8px;padding:3px 8px;border-radius:3px;font-size:11px;font-weight:500}
.product-item .img-wrap .tag.sale{background:#ee4d2d;color:#fff}
.product-item .img-wrap .tag.new{background:#00bfa5;color:#fff}
.product-item .img-wrap .tag.hot{background:#ff6b35;color:#fff}
.product-item .img-wrap .rank{position:absolute;top:0;left:0;width:28px;height:28px;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:#fff}
.product-item .img-wrap .rank.r1{background:linear-gradient(135deg,#ffd700,#ffb700)}
.product-item .img-wrap .rank.r2{background:linear-gradient(135deg,#c0c0c0,#a8a8a8)}
.product-item .img-wrap .rank.r3{background:linear-gradient(135deg,#cd7f32,#b87333)}
.product-item .img-wrap .rank.rn{background:#ee4d2d;border-radius:0 0 6px 0}
.product-item .info{padding:12px}
.product-item .name{font-size:13px;color:#333;line-height:1.4;height:36px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;margin-bottom:8px}
.product-item .price{margin-bottom:6px}
.product-item .price .now{color:#ee4d2d;font-size:16px;font-weight:600}
.product-item .price .now small{font-size:12px;font-weight:400}
.product-item .price .was{color:#999;font-size:12px;text-decoration:line-through;margin-left:6px}
.product-item .meta{display:flex;justify-content:space-between;font-size:11px;color:#999}
.product-item .meta .rating{color:#ffb400}
.product-item .meta .sales{color:#666}

/* 空狀態 */
.empty-box{background:#fff;border-radius:8px;padding:60px 20px;text-align:center}
.empty-box svg{width:80px;height:80px;fill:#ddd;margin-bottom:20px}
.empty-box h3{font-size:18px;color:#333;margin-bottom:8px}
.empty-box p{font-size:14px;color:#999;margin-bottom:20px}
.empty-box .btn{display:inline-block;padding:10px 30px;background:#ee4d2d;color:#fff;border-radius:6px;font-size:14px}

/* 響應式 */
@media(max-width:1024px){
.products-grid{grid-template-columns:repeat(4,1fr);gap:12px}
}
@media(max-width:768px){
.page-banner{padding:18px 15px}
.page-banner h1{font-size:18px}
.page-banner h1 svg{width:24px;height:24px}
.page-banner .banner-info{width:100%;margin-top:5px}
.page-banner .banner-info span{margin-left:15px}
.countdown-inline{padding:6px 12px}
.countdown-inline .time-unit{padding:3px 6px;font-size:13px;min-width:28px}
.filter-bar{padding:10px 15px;gap:10px}
.filter-bar .filter-tabs{flex-wrap:wrap}
.filter-bar .tab{padding:5px 12px;font-size:12px}
.filter-bar .product-count{width:100%;margin-left:0;margin-top:5px}
.products-grid{grid-template-columns:repeat(2,1fr);gap:10px}
.product-item .info{padding:10px}
.product-item .name{font-size:12px;height:34px}
.product-item .price .now{font-size:15px}
}
</style>';
    }

    // ========== 限時特賣 ==========
    public static function render_flash_sale($shop) {
        $all_products = OIP_Product_Manager::get_products(['status' => 'publish']);
        $products = array_filter($all_products, function($p) {
            return $p->original_price && $p->original_price > $p->price;
        });
        usort($products, function($a, $b) {
            $da = ($a->original_price - $a->price) / $a->original_price;
            $db = ($b->original_price - $b->price) / $b->original_price;
            return $db <=> $da;
        });
        $products = array_values($products);
        
        $max_discount = 0;
        foreach ($products as $p) {
            $discount = round((1 - $p->price / $p->original_price) * 100);
            if ($discount > $max_discount) $max_discount = $discount;
        }
        
        echo $shop->get_header('限時特賣');
        echo self::get_promo_styles();
        ?>
<div class="page-banner">
    <div class="banner-inner">
        <h1>
            <svg viewBox="0 0 24 24"><path d="M7 2v11h3v9l7-12h-4l4-8z"/></svg>
            限時特賣
        </h1>
        <div class="banner-info">
            <span>共 <strong><?php echo count($products); ?></strong> 件特賣商品</span>
            <span>最高折扣 <strong><?php echo $max_discount; ?>%</strong></span>
        </div>
        <div class="countdown-inline">
            <span class="label">倒數</span>
            <div class="timer">
                <span class="time-unit" id="hours">08</span>
                <span class="sep">:</span>
                <span class="time-unit" id="mins">45</span>
                <span class="sep">:</span>
                <span class="time-unit" id="secs">30</span>
            </div>
        </div>
    </div>
</div>

<script>
(function(){
    var h=8,m=45,s=30;
    setInterval(function(){
        if(--s<0){s=59;if(--m<0){m=59;if(--h<0)h=23;}}
        document.getElementById('hours').textContent=h.toString().padStart(2,'0');
        document.getElementById('mins').textContent=m.toString().padStart(2,'0');
        document.getElementById('secs').textContent=s.toString().padStart(2,'0');
    },1000);
})();
</script>

<main class="shop-main">
    <?php if (empty($products)): ?>
    <div class="empty-box">
        <svg viewBox="0 0 24 24"><path d="M7 2v11h3v9l7-12h-4l4-8z"/></svg>
        <h3>目前沒有特賣商品</h3>
        <p>敬請期待下一波限時特賣活動</p>
        <a href="<?php echo home_url(); ?>" class="btn">返回首頁</a>
    </div>
    <?php else: ?>
    
    <div class="filter-bar">
        <span class="filter-label">排序：</span>
        <div class="filter-tabs">
            <button class="tab active">折扣最高</button>
            <button class="tab">價格低到高</button>
            <button class="tab">最新上架</button>
        </div>
        <span class="product-count"><?php echo count($products); ?> 件商品</span>
    </div>
    
    <div class="products-grid">
    <?php foreach ($products as $p): 
        $discount = round((1 - $p->price / $p->original_price) * 100);
    ?>
        <div class="product-item">
            <a href="<?php echo home_url('/?oip_shop=product&id=' . $p->id); ?>">
                <div class="img-wrap">
                    <?php if ($p->image): ?>
                    <img src="<?php echo esc_url($p->image); ?>" alt="<?php echo esc_attr($p->name); ?>">
                    <?php else: ?>
                    <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;">
                        <svg width="50" height="50" fill="#ddd" viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg>
                    </div>
                    <?php endif; ?>
                    <span class="tag sale">-<?php echo $discount; ?>%</span>
                </div>
                <div class="info">
                    <div class="name"><?php echo esc_html($p->name); ?></div>
                    <div class="price">
                        <span class="now"><small>$</small><?php echo number_format($p->price); ?></span>
                        <span class="was">$<?php echo number_format($p->original_price); ?></span>
                    </div>
                    <div class="meta">
                        <span class="rating">★ <?php echo number_format($p->rating, 1); ?></span>
                        <span class="sales">已售 <?php echo $p->sales >= 1000 ? number_format($p->sales / 1000, 1) . 'k' : $p->sales; ?></span>
                    </div>
                </div>
            </a>
        </div>
    <?php endforeach; ?>
    </div>
    
    <?php endif; ?>
</main>
        <?php
        echo $shop->get_footer();
    }

    // ========== 新品上市 ==========
    public static function render_new_arrivals($shop) {
        $products = OIP_Product_Manager::get_products(['status' => 'publish']);
        usort($products, function($a, $b) {
            return strtotime($b->created_at) - strtotime($a->created_at);
        });
        $products = array_slice($products, 0, 30);
        $categories = OIP_Product_Manager::get_categories();
        
        echo $shop->get_header('新品上市');
        echo self::get_promo_styles();
        ?>
<div class="page-banner">
    <div class="banner-inner">
        <h1>
            <svg viewBox="0 0 24 24"><path d="M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-5-2c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm11 15H4v-2h16v2zm0-5H4V8h5.08L7 10.83 8.62 12 11 8.76l1-1.36 1 1.36L15.38 12 17 10.83 14.92 8H20v6z"/></svg>
            新品上市
        </h1>
        <div class="banner-info">
            <span>共 <strong><?php echo count($products); ?></strong> 件新品</span>
            <span><strong><?php echo count($categories); ?></strong> 個分類</span>
        </div>
    </div>
</div>

<main class="shop-main">
    <?php if (empty($products)): ?>
    <div class="empty-box">
        <svg viewBox="0 0 24 24"><path d="M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2z"/></svg>
        <h3>目前沒有新品</h3>
        <p>敬請期待更多新品上架</p>
        <a href="<?php echo home_url(); ?>" class="btn">返回首頁</a>
    </div>
    <?php else: ?>
    
    <div class="filter-bar">
        <span class="filter-label">分類：</span>
        <div class="filter-tabs">
            <button class="tab active" onclick="filterCat('all')">全部</button>
            <?php foreach (array_slice($categories, 0, 6) as $cat): ?>
            <button class="tab" onclick="filterCat(<?php echo $cat->id; ?>)"><?php echo esc_html($cat->name); ?></button>
            <?php endforeach; ?>
        </div>
        <span class="product-count"><?php echo count($products); ?> 件商品</span>
    </div>
    
    <div class="products-grid">
    <?php foreach ($products as $idx => $p): ?>
        <div class="product-item" data-cat="<?php echo $p->category_id; ?>">
            <a href="<?php echo home_url('/?oip_shop=product&id=' . $p->id); ?>">
                <div class="img-wrap">
                    <?php if ($p->image): ?>
                    <img src="<?php echo esc_url($p->image); ?>" alt="<?php echo esc_attr($p->name); ?>">
                    <?php else: ?>
                    <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;">
                        <svg width="50" height="50" fill="#ddd" viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg>
                    </div>
                    <?php endif; ?>
                    <?php if ($idx < 5): ?><span class="tag new">NEW</span><?php endif; ?>
                </div>
                <div class="info">
                    <div class="name"><?php echo esc_html($p->name); ?></div>
                    <div class="price">
                        <span class="now"><small>$</small><?php echo number_format($p->price); ?></span>
                        <?php if ($p->original_price && $p->original_price > $p->price): ?>
                        <span class="was">$<?php echo number_format($p->original_price); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="meta">
                        <span class="rating">★ <?php echo number_format($p->rating, 1); ?></span>
                        <span class="sales">已售 <?php echo $p->sales >= 1000 ? number_format($p->sales / 1000, 1) . 'k' : $p->sales; ?></span>
                    </div>
                </div>
            </a>
        </div>
    <?php endforeach; ?>
    </div>
    
    <script>
    function filterCat(id) {
        document.querySelectorAll('.filter-tabs .tab').forEach(t => t.classList.remove('active'));
        event.target.classList.add('active');
        document.querySelectorAll('.product-item').forEach(item => {
            item.style.display = (id === 'all' || item.dataset.cat == id) ? '' : 'none';
        });
    }
    </script>
    
    <?php endif; ?>
</main>
        <?php
        echo $shop->get_footer();
    }

    // ========== 熱銷排行 ==========
    public static function render_best_sellers($shop) {
        $products = OIP_Product_Manager::get_products(['status' => 'publish']);
        usort($products, function($a, $b) {
            return $b->sales - $a->sales;
        });
        $products = array_slice($products, 0, 30);
        
        $total_sales = array_sum(array_column($products, 'sales'));
        
        echo $shop->get_header('熱銷排行');
        echo self::get_promo_styles();
        ?>
<div class="page-banner">
    <div class="banner-inner">
        <h1>
            <svg viewBox="0 0 24 24"><path d="M13.5.67s.74 2.65.74 4.8c0 2.06-1.35 3.73-3.41 3.73-2.07 0-3.63-1.67-3.63-3.73l.03-.36C5.21 7.51 4 10.62 4 14c0 4.42 3.58 8 8 8s8-3.58 8-8C20 8.61 17.41 3.8 13.5.67zM11.71 19c-1.78 0-3.22-1.4-3.22-3.14 0-1.62 1.05-2.76 2.81-3.12 1.77-.36 3.6-1.21 4.62-2.58.39 1.29.59 2.65.59 4.04 0 2.65-2.15 4.8-4.8 4.8z"/></svg>
            熱銷排行
        </h1>
        <div class="banner-info">
            <span>共 <strong><?php echo count($products); ?></strong> 件熱銷商品</span>
            <span>累計銷量 <strong><?php echo number_format($total_sales); ?>+</strong></span>
        </div>
    </div>
</div>

<main class="shop-main">
    <?php if (empty($products)): ?>
    <div class="empty-box">
        <svg viewBox="0 0 24 24"><path d="M13.5.67s.74 2.65.74 4.8c0 2.06-1.35 3.73-3.41 3.73-2.07 0-3.63-1.67-3.63-3.73l.03-.36C5.21 7.51 4 10.62 4 14c0 4.42 3.58 8 8 8s8-3.58 8-8C20 8.61 17.41 3.8 13.5.67z"/></svg>
        <h3>目前沒有商品</h3>
        <p>敬請期待更多熱銷商品</p>
        <a href="<?php echo home_url(); ?>" class="btn">返回首頁</a>
    </div>
    <?php else: ?>
    
    <div class="filter-bar">
        <span class="filter-label">排序：</span>
        <div class="filter-tabs">
            <button class="tab active">銷量最高</button>
            <button class="tab">評價最好</button>
            <button class="tab">價格低到高</button>
        </div>
        <span class="product-count"><?php echo count($products); ?> 件商品</span>
    </div>
    
    <div class="products-grid">
    <?php foreach ($products as $idx => $p): 
        $rank = $idx + 1;
        $rankClass = $rank === 1 ? 'r1' : ($rank === 2 ? 'r2' : ($rank === 3 ? 'r3' : 'rn'));
    ?>
        <div class="product-item">
            <a href="<?php echo home_url('/?oip_shop=product&id=' . $p->id); ?>">
                <div class="img-wrap">
                    <?php if ($p->image): ?>
                    <img src="<?php echo esc_url($p->image); ?>" alt="<?php echo esc_attr($p->name); ?>">
                    <?php else: ?>
                    <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;">
                        <svg width="50" height="50" fill="#ddd" viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg>
                    </div>
                    <?php endif; ?>
                    <span class="rank <?php echo $rankClass; ?>"><?php echo $rank; ?></span>
                </div>
                <div class="info">
                    <div class="name"><?php echo esc_html($p->name); ?></div>
                    <div class="price">
                        <span class="now"><small>$</small><?php echo number_format($p->price); ?></span>
                        <?php if ($p->original_price && $p->original_price > $p->price): ?>
                        <span class="was">$<?php echo number_format($p->original_price); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="meta">
                        <span class="rating">★ <?php echo number_format($p->rating, 1); ?></span>
                        <span class="sales">已售 <?php echo $p->sales >= 1000 ? number_format($p->sales / 1000, 1) . 'k' : $p->sales; ?></span>
                    </div>
                </div>
            </a>
        </div>
    <?php endforeach; ?>
    </div>
    
    <?php endif; ?>
</main>
        <?php
        echo $shop->get_footer();
    }
}
