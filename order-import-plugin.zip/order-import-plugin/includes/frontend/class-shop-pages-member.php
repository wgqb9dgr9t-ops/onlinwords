<?php
/**
 * 商城頁面 - 會員中心、願望清單
 */

if (!defined('ABSPATH')) {
    exit;
}

class OIP_Shop_Pages_Member {
    
    public static function render_member($shop) {
        $is_logged_in = is_user_logged_in();
        echo $shop->get_header('會員中心');
        ?>
<main class="shop-main">
    <?php if (!$is_logged_in): ?>
    <div class="bg-white rounded p-5 text-center">
        <svg width="80" height="80" fill="#ddd" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
        <h3 class="h5 mt-3 mb-2">請先登入</h3>
        <p class="text-muted mb-3">登入後即可查看會員專區</p>
        <a href="<?php echo home_url('/?oip_page=login'); ?>" class="btn btn-danger">立即登入</a>
    </div>
    <?php else: 
        $user = wp_get_current_user();
        global $wpdb;
        $order_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}custom_orders WHERE email = %s", $user->user_email)) ?: 0;
    ?>
    <div class="row g-4">
        <div class="col-12 col-lg-4">
            <div class="bg-white rounded p-4 text-center mb-4">
                <div class="rounded-circle bg-danger text-white d-inline-flex align-items-center justify-content-center mb-3" style="width:80px;height:80px;font-size:32px;"><?php echo strtoupper(substr($user->display_name, 0, 1)); ?></div>
                <h5 class="mb-1"><?php echo esc_html($user->display_name); ?></h5>
                <p class="text-muted mb-2" style="font-size:14px;"><?php echo esc_html($user->user_email); ?></p>
                <span class="badge" style="background:#fff5f5;color:#ee4d2d;">一般會員</span>
                <hr class="my-3">
                <div class="row text-center">
                    <div class="col-6"><div style="font-size:20px;font-weight:700;color:#ee4d2d;"><?php echo $order_count; ?></div><div style="font-size:12px;color:#999;">訂單</div></div>
                    <div class="col-6"><div style="font-size:20px;font-weight:700;color:#ee4d2d;">0</div><div style="font-size:12px;color:#999;">收藏</div></div>
                </div>
                <hr class="my-3">
                <a href="<?php echo home_url('/?oip_logout=1'); ?>" class="btn btn-outline-danger btn-sm w-100">登出帳戶</a>
            </div>
        </div>
        <div class="col-12 col-lg-8">
            <div class="bg-white rounded p-4 mb-4">
                <h5 class="mb-3">快速功能</h5>
                <div class="row g-3">
                    <div class="col-6 col-md-4">
                        <a href="<?php echo home_url('/?oip_page=orders'); ?>" class="d-block text-center p-3 border rounded text-decoration-none h-100" style="color:#333;">
                            <svg width="32" height="32" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
                            <p class="mb-0 mt-2" style="font-size:14px;">我的訂單</p>
                            <small class="text-muted"><?php echo $order_count; ?> 筆</small>
                        </a>
                    </div>
                    <div class="col-6 col-md-4">
                        <a href="<?php echo home_url('/?oip_shop=wishlist'); ?>" class="d-block text-center p-3 border rounded text-decoration-none h-100" style="color:#333;">
                            <svg width="32" height="32" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                            <p class="mb-0 mt-2" style="font-size:14px;">願望清單</p>
                            <small class="text-muted">收藏商品</small>
                        </a>
                    </div>
                    <div class="col-6 col-md-4">
                        <a href="<?php echo home_url('/?oip_shop=cart'); ?>" class="d-block text-center p-3 border rounded text-decoration-none h-100" style="color:#333;">
                            <svg width="32" height="32" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/></svg>
                            <p class="mb-0 mt-2" style="font-size:14px;">購物車</p>
                            <small class="text-muted">查看商品</small>
                        </a>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded p-4">
                <h5 class="mb-3">常用連結</h5>
                <div class="row g-2">
                    <div class="col-6"><a href="<?php echo home_url('/?oip_shop=faq'); ?>" class="d-flex align-items-center gap-2 p-2 rounded text-decoration-none" style="color:#333;"><svg width="20" height="20" fill="#999" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"/></svg><span style="font-size:14px;">常見問題</span></a></div>
                    <div class="col-6"><a href="<?php echo home_url('/?oip_shop=shipping'); ?>" class="d-flex align-items-center gap-2 p-2 rounded text-decoration-none" style="color:#333;"><svg width="20" height="20" fill="#999" viewBox="0 0 24 24"><path d="M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4z"/></svg><span style="font-size:14px;">配送說明</span></a></div>
                    <div class="col-6"><a href="<?php echo home_url('/?oip_shop=returns'); ?>" class="d-flex align-items-center gap-2 p-2 rounded text-decoration-none" style="color:#333;"><svg width="20" height="20" fill="#999" viewBox="0 0 24 24"><path d="M19 8l-4 4h3c0 3.31-2.69 6-6 6-1.01 0-1.97-.25-2.8-.7l-1.46 1.46C8.97 19.54 10.43 20 12 20c4.42 0 8-3.58 8-8h3l-4-4zM6 12c0-3.31 2.69-6 6-6 1.01 0 1.97.25 2.8.7l1.46-1.46C15.03 4.46 13.57 4 12 4c-4.42 0-8 3.58-8 8H1l4 4 4-4H6z"/></svg><span style="font-size:14px;">退換貨政策</span></a></div>
                    <div class="col-6"><a href="<?php echo esc_url(oip_get_contact_url()); ?>"<?php echo oip_get_line_id() ? ' target="_blank" rel="noopener"' : ''; ?> class="d-flex align-items-center gap-2 p-2 rounded text-decoration-none" style="color:#333;"><svg width="20" height="20" fill="<?php echo oip_get_line_id() ? '#00B900' : '#999'; ?>" viewBox="0 0 24 24"><?php if (oip_get_line_id()): ?><path d="M19.365 9.863c.349 0 .63.285.63.631 0 .345-.281.63-.63.63H17.61v1.125h1.755c.349 0 .63.283.63.63 0 .344-.281.629-.63.629h-2.386c-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63h2.386c.346 0 .627.285.627.63 0 .349-.281.63-.63.63H17.61v1.125h1.755zm-3.855 3.016c0 .27-.174.51-.432.596-.064.021-.133.031-.199.031-.211 0-.391-.09-.51-.25l-2.443-3.317v2.94c0 .344-.279.629-.631.629-.346 0-.626-.285-.626-.629V8.108c0-.27.173-.51.43-.595.06-.023.136-.033.194-.033.195 0 .375.104.495.254l2.462 3.33V8.108c0-.345.282-.63.63-.63.345 0 .63.285.63.63v4.771zm-5.741 0c0 .344-.282.629-.631.629-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63.346 0 .628.285.628.63v4.771zm-2.466.629H4.917c-.345 0-.63-.285-.63-.629V8.108c0-.345.285-.63.63-.63.348 0 .63.285.63.63v4.141h1.756c.348 0 .629.283.629.63 0 .344-.282.629-.629.629M24 10.314C24 4.943 18.615.572 12 .572S0 4.943 0 10.314c0 4.811 4.27 8.842 10.035 9.608.391.082.923.258 1.058.59.12.301.079.766.038 1.08l-.164 1.02c-.045.301-.24 1.186 1.049.645 1.291-.539 6.916-4.078 9.436-6.975C23.176 14.393 24 12.458 24 10.314"/><?php else: ?><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/><?php endif; ?></svg><span style="font-size:14px;"><?php echo oip_get_line_id() ? 'LINE 客服' : '聯繫客服'; ?></span></a></div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</main>
        <?php
        echo $shop->get_footer();
    }
    
    public static function render_wishlist($shop) {
        echo $shop->get_header('願望清單');
        ?>
<main class="shop-main">
    <div class="bg-white rounded p-4 mb-4"><h1 class="h4 mb-0">願望清單</h1></div>
    <div id="wishlist-content"><div class="text-center py-5"><div class="spinner-border text-danger"></div><p class="mt-2">載入中...</p></div></div>
</main>
<script>
var products = <?php echo json_encode(OIP_Product_Manager::get_products(['status' => 'publish'])); ?>;
var productMap = {};
products.forEach(function(p) { productMap[p.id] = p; });

function renderWishlist() {
    var wishlist = JSON.parse(localStorage.getItem('oip_wishlist') || '[]');
    var container = document.getElementById('wishlist-content');
    
    if (wishlist.length === 0) {
        container.innerHTML = '<div class="bg-white rounded p-5 text-center"><svg width="80" height="80" fill="#ddd" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg><h3 class="h5 mt-3 mb-2">願望清單是空的</h3><p class="text-muted mb-3">快去收藏喜歡的商品吧！</p><a href="<?php echo home_url(); ?>" class="btn btn-danger">去逛逛</a></div>';
        return;
    }
    
    var html = '<div class="row g-2 g-md-3">';
    wishlist.forEach(function(id, idx) {
        var p = productMap[id];
        if (!p) return;
        html += '<div class="col-6 col-md-4 col-lg-3 mb-3"><div class="product-card h-100" style="position:relative;">';
        html += '<button onclick="removeFromWishlist(' + idx + ')" style="position:absolute;top:10px;right:10px;z-index:10;background:#fff;border:none;width:30px;height:30px;border-radius:50%;box-shadow:0 2px 5px rgba(0,0,0,.1);cursor:pointer;">✕</button>';
        html += '<a href="<?php echo home_url('/?oip_shop=product&id='); ?>' + p.id + '" class="d-block">';
        if (p.image) {
            html += '<img src="' + p.image + '" class="product-img">';
        } else {
            html += '<div class="product-img d-flex align-items-center justify-content-center" style="background:#f5f5f5;"><svg width="50" height="50" fill="#ddd" viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg></div>';
        }
        html += '<div class="product-info"><div class="product-name">' + p.name + '</div><div class="product-price"><span class="current"><small>NT$</small>' + p.price.toLocaleString() + '</span></div></div></a>';
        html += '<div class="p-2 pt-0"><button onclick="addToCartFromWishlist(' + p.id + ')" class="btn btn-danger btn-sm w-100">加入購物車</button></div></div></div>';
    });
    html += '</div>';
    container.innerHTML = html;
}

function removeFromWishlist(idx) {
    var wishlist = JSON.parse(localStorage.getItem('oip_wishlist') || '[]');
    wishlist.splice(idx, 1);
    localStorage.setItem('oip_wishlist', JSON.stringify(wishlist));
    renderWishlist();
}

function addToCartFromWishlist(id) {
    var cart = JSON.parse(localStorage.getItem('oip_cart') || '[]');
    var found = false;
    for (var i = 0; i < cart.length; i++) { if (cart[i].id == id) { cart[i].qty += 1; found = true; break; } }
    if (!found) cart.push({id: id, qty: 1});
    localStorage.setItem('oip_cart', JSON.stringify(cart));
    document.cookie = 'oip_cart=' + JSON.stringify(cart) + ';path=/';
    alert('已加入購物車！');
}

renderWishlist();
</script>
        <?php
        echo $shop->get_footer();
    }
    
    public static function render_coupons($shop) {
        // 重定向到會員中心，因為優惠券功能未完整實現
        wp_redirect(home_url('/?oip_shop=member'));
        exit;
    }
}
