<?php
/**
 * 商城頁面 - 購物車、結帳
 */

if (!defined('ABSPATH')) {
    exit;
}

class OIP_Shop_Pages_Cart {
    
    public static function render_cart($shop) {
        echo $shop->get_header('購物車');
        ?>
<main class="shop-main">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb bg-white rounded p-3 mb-0">
            <li class="breadcrumb-item"><a href="<?php echo home_url(); ?>" style="color:#ee4d2d;">首頁</a></li>
            <li class="breadcrumb-item active">購物車</li>
        </ol>
    </nav>
    <div id="cart-content"><div class="text-center py-5"><div class="spinner-border text-danger"></div><p class="mt-2">載入中...</p></div></div>
    <div class="row g-3 mt-4">
        <div class="col-6 col-md-3"><div class="bg-white rounded p-3 text-center h-100"><svg width="32" height="32" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg><h6 class="mt-2 mb-1" style="font-size:14px;">正品保證</h6><p class="text-muted mb-0" style="font-size:12px;">100%正品</p></div></div>
        <div class="col-6 col-md-3"><div class="bg-white rounded p-3 text-center h-100"><svg width="32" height="32" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4z"/></svg><h6 class="mt-2 mb-1" style="font-size:14px;">免運配送</h6><p class="text-muted mb-0" style="font-size:12px;">全館免運費</p></div></div>
        <div class="col-6 col-md-3"><div class="bg-white rounded p-3 text-center h-100"><svg width="32" height="32" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M12.5 6.9c1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-.53.12-1.03.3-1.48.54l1.47 1.47c.41-.17.91-.27 1.51-.27z"/></svg><h6 class="mt-2 mb-1" style="font-size:14px;">7天退換</h6><p class="text-muted mb-0" style="font-size:12px;">無理由退換</p></div></div>
        <div class="col-6 col-md-3"><div class="bg-white rounded p-3 text-center h-100"><svg width="32" height="32" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/></svg><h6 class="mt-2 mb-1" style="font-size:14px;">貨到付款</h6><p class="text-muted mb-0" style="font-size:12px;">安心購物</p></div></div>
    </div>
</main>
<script>
var products = <?php echo json_encode(OIP_Product_Manager::get_products(['status' => 'publish'])); ?>;
var productMap = {};
products.forEach(function(p) { productMap[p.id] = p; });

function renderCart() {
    var cart = JSON.parse(localStorage.getItem('oip_cart') || '[]');
    var container = document.getElementById('cart-content');
    
    if (cart.length === 0) {
        container.innerHTML = '<div class="bg-white rounded p-5 text-center"><svg width="80" height="80" fill="#ddd" viewBox="0 0 24 24"><path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/></svg><h3 class="h5 mt-3 mb-2">購物車是空的</h3><p class="text-muted mb-3">快去挑選喜歡的商品吧！</p><a href="<?php echo home_url(); ?>" class="btn btn-danger">去購物</a></div>';
        return;
    }
    
    var total = 0;
    var html = '<div class="row"><div class="col-12 col-lg-8">';
    html += '<div class="bg-white rounded p-3 mb-3"><h4 class="h5 mb-0">購物車 (' + cart.length + ' 件商品)</h4></div>';
    
    cart.forEach(function(item, idx) {
        var p = productMap[item.id];
        if (!p) return;
        var subtotal = p.price * item.qty;
        total += subtotal;
        
        html += '<div class="bg-white rounded p-3 mb-2"><div class="row align-items-center">';
        html += '<div class="col-3 col-md-2">';
        if (p.image) {
            html += '<img src="' + p.image + '" class="w-100 rounded" style="aspect-ratio:1;object-fit:cover;">';
        } else {
            html += '<div class="w-100 rounded d-flex align-items-center justify-content-center" style="aspect-ratio:1;background:#f5f5f5;"><svg width="40" height="40" fill="#ddd" viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg></div>';
        }
        html += '</div>';
        html += '<div class="col-9 col-md-4"><h6 class="mb-1" style="font-size:14px;">' + p.name + '</h6><p class="text-danger mb-0">NT$' + p.price.toLocaleString() + '</p></div>';
        html += '<div class="col-6 col-md-3 mt-2 mt-md-0"><div class="d-flex align-items-center"><button class="btn btn-sm btn-outline-secondary" onclick="updateQty(' + idx + ',-1)">-</button><input type="text" value="' + item.qty + '" class="form-control form-control-sm text-center mx-1" style="width:50px;" readonly><button class="btn btn-sm btn-outline-secondary" onclick="updateQty(' + idx + ',1)">+</button></div></div>';
        html += '<div class="col-4 col-md-2 mt-2 mt-md-0 text-end"><span class="text-danger fw-bold">NT$' + subtotal.toLocaleString() + '</span></div>';
        html += '<div class="col-2 col-md-1 mt-2 mt-md-0 text-end"><button class="btn btn-sm btn-outline-danger" onclick="removeItem(' + idx + ')">✕</button></div>';
        html += '</div></div>';
    });
    
    html += '</div><div class="col-12 col-lg-4">';
    html += '<div class="bg-white rounded p-3 sticky-top" style="top:70px;">';
    html += '<h5 class="border-bottom pb-2 mb-3">訂單摘要</h5>';
    html += '<div class="d-flex justify-content-between mb-2"><span>商品小計</span><span>NT$' + total.toLocaleString() + '</span></div>';
    html += '<div class="d-flex justify-content-between mb-2"><span>運費</span><span class="text-success">免運費</span></div>';
    html += '<hr><div class="d-flex justify-content-between mb-3"><span class="fw-bold">總計</span><span class="text-danger fw-bold fs-5">NT$' + total.toLocaleString() + '</span></div>';
    html += '<a href="<?php echo home_url('/?oip_shop=checkout'); ?>" class="btn btn-danger w-100 btn-lg">前往結帳</a>';
    html += '<a href="<?php echo home_url(); ?>" class="btn btn-outline-secondary w-100 mt-2">繼續購物</a></div>';
    html += '<div class="bg-white rounded p-3 mt-3"><h6 class="mb-3" style="font-size:14px;">購物保障</h6>';
    html += '<div class="d-flex align-items-center gap-2 mb-2"><svg width="16" height="16" fill="#00bfa5" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg><span style="font-size:13px;">正品保證，假一賠十</span></div>';
    html += '<div class="d-flex align-items-center gap-2 mb-2"><svg width="16" height="16" fill="#00bfa5" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg><span style="font-size:13px;">7天無理由退換貨</span></div>';
    html += '<div class="d-flex align-items-center gap-2 mb-2"><svg width="16" height="16" fill="#00bfa5" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg><span style="font-size:13px;">貨到付款，安心購物</span></div>';
    html += '<div class="d-flex align-items-center gap-2"><svg width="16" height="16" fill="#00bfa5" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg><span style="font-size:13px;">全台免運，快速配送</span></div></div>';
    html += '</div></div>';
    container.innerHTML = html;
}

function updateQty(idx, d) {
    var cart = JSON.parse(localStorage.getItem('oip_cart') || '[]');
    cart[idx].qty += d;
    if (cart[idx].qty < 1) cart[idx].qty = 1;
    localStorage.setItem('oip_cart', JSON.stringify(cart));
    document.cookie = 'oip_cart=' + JSON.stringify(cart) + ';path=/';
    renderCart();
}

function removeItem(idx) {
    var cart = JSON.parse(localStorage.getItem('oip_cart') || '[]');
    cart.splice(idx, 1);
    localStorage.setItem('oip_cart', JSON.stringify(cart));
    document.cookie = 'oip_cart=' + JSON.stringify(cart) + ';path=/';
    renderCart();
}

renderCart();
</script>
        <?php
        echo $shop->get_footer();
    }

    public static function render_checkout($shop) {
        if (!is_user_logged_in()) {
            wp_redirect(home_url('/?oip_page=login&redirect_to=' . urlencode(home_url('/?oip_shop=checkout'))));
            exit;
        }
        $user = wp_get_current_user();
        echo $shop->get_header('結帳');
        ?>
<main class="shop-main">
    <div class="bg-white rounded p-3 mb-4">
        <div class="d-flex justify-content-center align-items-center gap-2 gap-md-4">
            <div class="text-center"><div class="rounded-circle d-inline-flex align-items-center justify-content-center" style="width:32px;height:32px;background:#ccc;color:#fff;">✓</div><div style="font-size:12px;color:#999;margin-top:4px;">購物車</div></div>
            <div style="width:50px;height:2px;background:#ee4d2d;"></div>
            <div class="text-center"><div class="rounded-circle d-inline-flex align-items-center justify-content-center" style="width:32px;height:32px;background:#ee4d2d;color:#fff;">2</div><div style="font-size:12px;color:#ee4d2d;margin-top:4px;font-weight:500;">填寫資料</div></div>
            <div style="width:50px;height:2px;background:#ddd;"></div>
            <div class="text-center"><div class="rounded-circle d-inline-flex align-items-center justify-content-center" style="width:32px;height:32px;background:#ddd;color:#fff;">3</div><div style="font-size:12px;color:#999;margin-top:4px;">完成訂單</div></div>
        </div>
    </div>
    <form id="checkout-form" method="post">
        <div class="row">
            <div class="col-12 col-lg-8">
                <div class="bg-white rounded p-3 p-md-4 mb-3">
                    <h5 class="border-bottom pb-2 mb-3"><svg width="20" height="20" fill="#ee4d2d" viewBox="0 0 24 24" class="me-2"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>收件資訊</h5>
                    <div class="row g-3">
                        <div class="col-12 col-md-6"><label class="form-label">收件人姓名 <span class="text-danger">*</span></label><input type="text" name="name" class="form-control" required value="<?php echo esc_attr($user->display_name); ?>"></div>
                        <div class="col-12 col-md-6"><label class="form-label">聯絡電話 <span class="text-danger">*</span></label><input type="tel" name="phone" id="phone" class="form-control" required placeholder="0912345678"><div id="phone-error" class="text-danger" style="font-size:12px;margin-top:4px;display:none;"></div></div>
                        <div class="col-12"><label class="form-label">電子郵件</label><input type="email" name="email" class="form-control" value="<?php echo esc_attr($user->user_email); ?>" readonly style="background:#f9f9f9;"></div>
                        <div class="col-12"><label class="form-label">收件地址 <span class="text-danger">*</span></label><input type="text" name="address" class="form-control" required placeholder="請輸入完整地址"></div>
                        <div class="col-12"><label class="form-label">訂單備註</label><textarea name="notes" class="form-control" rows="2" placeholder="如有特殊需求請填寫"></textarea></div>
                    </div>
                </div>
                <div class="bg-white rounded p-3 p-md-4 mb-3">
                    <h5 class="border-bottom pb-2 mb-3"><svg width="20" height="20" fill="#ee4d2d" viewBox="0 0 24 24" class="me-2"><path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/></svg>付款方式</h5>
                    <div class="form-check p-3 border rounded" style="background:#fff5f5;border-color:#ee4d2d !important;"><input class="form-check-input" type="radio" name="payment" value="cod" id="pay-cod" checked><label class="form-check-label" for="pay-cod"><strong style="color:#ee4d2d;">貨到付款</strong><small class="d-block text-muted">商品送達時以現金支付</small></label></div>
                </div>
                <div class="bg-white rounded p-3 p-md-4 mb-3">
                    <h5 class="border-bottom pb-2 mb-3"><svg width="20" height="20" fill="#ee4d2d" viewBox="0 0 24 24" class="me-2"><path d="M18 6h-2c0-2.21-1.79-4-4-4S8 3.79 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2z"/></svg>訂購商品</h5>
                    <div id="checkout-items"></div>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="bg-white rounded p-3 p-md-4 sticky-top" style="top:70px;">
                    <h5 class="border-bottom pb-2 mb-3">訂單摘要</h5>
                    <div id="checkout-summary"></div>
                    <button type="submit" class="btn btn-danger w-100 btn-lg mt-3" id="submit-btn">確認下單</button>
                    <p class="text-muted text-center mt-2 mb-0" style="font-size:12px;">點擊下單即表示同意服務條款</p>
                    <hr class="my-3">
                    <div style="font-size:13px;">
                        <div class="d-flex align-items-center gap-2 mb-2"><svg width="16" height="16" fill="#00bfa5" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg><span>正品保證</span></div>
                        <div class="d-flex align-items-center gap-2 mb-2"><svg width="16" height="16" fill="#00bfa5" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg><span>7天退換貨</span></div>
                        <div class="d-flex align-items-center gap-2"><svg width="16" height="16" fill="#00bfa5" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg><span>3-5天送達</span></div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</main>
<script>
var products = <?php echo json_encode(OIP_Product_Manager::get_products(['status' => 'publish'])); ?>;
var productMap = {};
products.forEach(function(p) { productMap[p.id] = p; });

function renderCheckout() {
    var cart = JSON.parse(localStorage.getItem('oip_cart') || '[]');
    if (cart.length === 0) { location.href = '<?php echo home_url('/?oip_shop=cart'); ?>'; return; }
    
    var total = 0, itemsHtml = '';
    cart.forEach(function(item) {
        var p = productMap[item.id];
        if (!p) return;
        var subtotal = p.price * item.qty;
        total += subtotal;
        
        itemsHtml += '<div class="d-flex gap-3 mb-3 pb-3 border-bottom">';
        if (p.image) {
            itemsHtml += '<img src="' + p.image + '" class="rounded" style="width:80px;height:80px;object-fit:cover;flex-shrink:0;">';
        } else {
            itemsHtml += '<div class="rounded d-flex align-items-center justify-content-center" style="width:80px;height:80px;background:#f5f5f5;flex-shrink:0;"><svg width="30" height="30" fill="#ddd" viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg></div>';
        }
        itemsHtml += '<div class="flex-grow-1"><h6 class="mb-1" style="font-size:14px;">' + p.name + '</h6><p class="text-muted mb-0" style="font-size:13px;">數量: ' + item.qty + '</p></div>';
        itemsHtml += '<div class="text-end"><span class="text-danger fw-bold">NT$' + subtotal.toLocaleString() + '</span></div></div>';
    });
    document.getElementById('checkout-items').innerHTML = itemsHtml;
    
    var summaryHtml = '<div class="d-flex justify-content-between mb-2"><span>商品小計</span><span>NT$' + total.toLocaleString() + '</span></div>';
    summaryHtml += '<div class="d-flex justify-content-between mb-2"><span>運費</span><span class="text-success">免運費</span></div><hr>';
    summaryHtml += '<div class="d-flex justify-content-between"><span class="fw-bold">應付總額</span><span class="text-danger fw-bold fs-5">NT$' + total.toLocaleString() + '</span></div>';
    document.getElementById('checkout-summary').innerHTML = summaryHtml;
}

// 顯示字段錯誤提示
function showFieldError(fieldName, message) {
    var field = document.querySelector('input[name="' + fieldName + '"]') || document.getElementById(fieldName);
    if (!field) return;
    
    field.classList.add('is-invalid');
    field.style.borderColor = '#dc3545';
    
    // 查找或創建錯誤提示元素
    var errorId = fieldName + '-error';
    var errorDiv = document.getElementById(errorId);
    
    if (!errorDiv) {
        errorDiv = document.createElement('div');
        errorDiv.id = errorId;
        errorDiv.className = 'invalid-feedback';
        errorDiv.style.display = 'block';
        errorDiv.style.fontSize = '13px';
        errorDiv.style.marginTop = '4px';
        errorDiv.style.color = '#dc3545';
        field.parentNode.appendChild(errorDiv);
    }
    
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
}

// 清除字段錯誤
function clearFieldError(field) {
    field.classList.remove('is-invalid');
    field.style.borderColor = '';
    
    var fieldName = field.name || field.id;
    var errorDiv = document.getElementById(fieldName + '-error');
    if (errorDiv) {
        errorDiv.style.display = 'none';
    }
}

// 清除所有錯誤
function clearAllErrors() {
    document.querySelectorAll('.is-invalid').forEach(function(field) {
        clearFieldError(field);
    });
    
    var topError = document.getElementById('top-error');
    if (topError) {
        topError.remove();
    }
}

// 顯示頂部錯誤提示
function showTopError(message) {
    var topError = document.getElementById('top-error');
    if (!topError) {
        topError = document.createElement('div');
        topError.id = 'top-error';
        topError.style.cssText = 'background:#fff3cd;border:1px solid #ffc107;color:#856404;padding:12px 16px;border-radius:8px;margin-bottom:20px;display:flex;align-items:center;gap:10px;animation:slideDown .3s;';
        
        var icon = '<svg width="20" height="20" fill="#ffc107" viewBox="0 0 24 24"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>';
        topError.innerHTML = icon + '<span>' + message + '</span>';
        
        var form = document.getElementById('checkout-form');
        form.parentNode.insertBefore(topError, form);
        
        var style = document.createElement('style');
        style.textContent = '@keyframes slideDown{from{opacity:0;transform:translateY(-10px)}}';
        document.head.appendChild(style);
    } else {
        topError.querySelector('span').textContent = message;
    }
    
    topError.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// 電話驗證（只要不少於6位）
function validateTaiwanPhone(phone) {
    phone = phone.replace(/[\s\-\(\)]/g, '');
    // 只要是數字，長度不少於6位即可
    if (!/^\d{6,}$/.test(phone)) return false;
    return true;
}

document.getElementById('phone').addEventListener('blur', function() {
    var phone = this.value.trim();
    if (phone && !validateTaiwanPhone(phone)) {
        showFieldError('phone', '請輸入有效的電話號碼（至少6位數字）');
    } else if (phone) {
        clearFieldError(this);
    }
});

// 為所有必填字段添加實時驗證
document.querySelectorAll('input[required]').forEach(function(field) {
    field.addEventListener('blur', function() {
        if (!this.value.trim() && this.name !== 'email') {
            var label = this.parentNode.querySelector('label');
            var fieldLabel = label ? label.textContent.replace(' *', '') : '此欄位';
            showFieldError(this.name || this.id, '請輸入' + fieldLabel);
        }
    });
    
    field.addEventListener('input', function() {
        if (this.value.trim()) {
            clearFieldError(this);
        }
    });
});

document.getElementById('checkout-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // 清除所有錯誤提示
    clearAllErrors();
    
    var cart = JSON.parse(localStorage.getItem('oip_cart') || '[]');
    if (cart.length === 0) { 
        showTopError('購物車是空的，請先添加商品');
        return; 
    }
    
    // 驗證必填字段
    var name = document.querySelector('input[name="name"]').value.trim();
    var phone = document.getElementById('phone').value.trim();
    var address = document.querySelector('input[name="address"]').value.trim();
    
    var hasError = false;
    
    if (!name) {
        showFieldError('name', '請輸入收件人姓名');
        hasError = true;
    }
    
    if (!phone) {
        showFieldError('phone', '請輸入聯絡電話');
        hasError = true;
    } else if (!validateTaiwanPhone(phone)) {
        showFieldError('phone', '請輸入有效的電話號碼（至少6位數字）');
        hasError = true;
    }
    
    if (!address) {
        showFieldError('address', '請輸入收件地址');
        hasError = true;
    }
    
    if (hasError) {
        // 滾動到第一個錯誤字段
        var firstError = document.querySelector('.is-invalid');
        if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
            firstError.focus();
        }
        return;
    }
    
    var btn = document.getElementById('submit-btn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>處理中...';
    
    var formData = new FormData(this);
    formData.append('action', 'oip_create_order');
    formData.append('cart', JSON.stringify(cart));
    
    fetch('<?php echo admin_url('admin-ajax.php'); ?>', { method: 'POST', body: formData })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        if (data.success) {
            localStorage.removeItem('oip_cart');
            document.cookie = 'oip_cart=[];path=/';
            showOrderSuccess(data.data.order_id);
        } else {
            showOrderError(data.data || '訂單建立失敗');
            btn.disabled = false;
            btn.innerHTML = '確認下單';
        }
    }).catch(function() {
        showOrderError('網路錯誤，請重試');
        btn.disabled = false;
        btn.innerHTML = '確認下單';
    });
});

function showOrderSuccess(orderId) {
    var modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);z-index:99999;display:flex;align-items:center;justify-content:center;animation:fadeIn .3s;';
    
    var box = document.createElement('div');
    box.style.cssText = 'background:#fff;border-radius:16px;padding:40px;max-width:400px;width:90%;text-align:center;animation:slideUp .3s;box-shadow:0 20px 60px rgba(0,0,0,.3);';
    
    box.innerHTML = '<svg width="80" height="80" fill="#00d4aa" viewBox="0 0 24 24" style="margin-bottom:20px;"><circle cx="12" cy="12" r="10" fill="#e8f5e9"/><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>' +
        '<h3 style="font-size:24px;font-weight:700;color:#333;margin-bottom:12px;">訂單建立成功！</h3>' +
        '<p style="color:#666;margin-bottom:8px;font-size:15px;">訂單編號</p>' +
        '<p style="color:#ee4d2d;font-size:20px;font-weight:600;margin-bottom:24px;">' + orderId + '</p>' +
        '<p style="color:#999;font-size:14px;margin-bottom:24px;">我們已收到您的訂單，將盡快為您安排配送</p>' +
        '<button onclick="location.href=\'<?php echo home_url('/?oip_page=orders'); ?>\'" style="background:linear-gradient(135deg,#ee4d2d,#ff6633);color:#fff;border:none;padding:14px 40px;border-radius:8px;font-size:16px;font-weight:600;cursor:pointer;width:100%;transition:transform .2s;" onmouseover="this.style.transform=\'translateY(-2px)\'" onmouseout="this.style.transform=\'translateY(0)\'">查看訂單</button>';
    
    modal.appendChild(box);
    document.body.appendChild(modal);
    
    var style = document.createElement('style');
    style.textContent = '@keyframes fadeIn{from{opacity:0}}@keyframes slideUp{from{opacity:0;transform:translateY(20px)}}';
    document.head.appendChild(style);
}

function showOrderError(msg) {
    var modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);z-index:99999;display:flex;align-items:center;justify-content:center;animation:fadeIn .3s;';
    
    var box = document.createElement('div');
    box.style.cssText = 'background:#fff;border-radius:16px;padding:40px;max-width:400px;width:90%;text-align:center;animation:slideUp .3s;box-shadow:0 20px 60px rgba(0,0,0,.3);';
    
    box.innerHTML = '<svg width="80" height="80" fill="#f44336" viewBox="0 0 24 24" style="margin-bottom:20px;"><circle cx="12" cy="12" r="10" fill="#ffebee"/><path d="M15.41 7.41L14 6l-2 2-2-2-1.41 1.41L10.59 9.5 8.59 11.5 10 12.91l2-2 2 2 1.41-1.41-2-2 2-2z"/></svg>' +
        '<h3 style="font-size:24px;font-weight:700;color:#333;margin-bottom:12px;">訂單建立失敗</h3>' +
        '<p style="color:#666;margin-bottom:24px;font-size:15px;">' + msg + '</p>' +
        '<button onclick="this.parentElement.parentElement.remove()" style="background:#f44336;color:#fff;border:none;padding:14px 40px;border-radius:8px;font-size:16px;font-weight:600;cursor:pointer;width:100%;">確定</button>';
    
    modal.appendChild(box);
    document.body.appendChild(modal);
    
    var style = document.createElement('style');
    style.textContent = '@keyframes fadeIn{from{opacity:0}}@keyframes slideUp{from{opacity:0;transform:translateY(20px)}}';
    document.head.appendChild(style);
}

renderCheckout();
</script>
        <?php
        echo $shop->get_footer();
    }
}
