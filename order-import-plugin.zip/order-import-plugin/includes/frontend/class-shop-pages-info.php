<?php
/**
 * 商城頁面 - 關於、聯繫、FAQ、配送、退換、隱私、條款
 */

if (!defined('ABSPATH')) {
    exit;
}

class OIP_Shop_Pages_Info {
    
    // ========== 關於我們 ==========
    public static function render_about($shop) {
        $site_name = get_bloginfo('name');
        echo $shop->get_header('關於我們');
        ?>
<main class="shop-main">
    <!-- 品牌介紹 -->
    <div class="bg-white rounded p-4 p-md-5 mb-4">
        <h1 class="h3 text-center mb-4">關於 <?php echo esc_html($site_name); ?></h1>
        <p class="text-center text-muted mb-4" style="max-width:700px;margin:0 auto;line-height:1.8;">
            我們致力於為顧客提供最優質的購物體驗，精選各類優質商品，以最實惠的價格送到您手中。
            自創立以來，我們始終堅持「品質第一、服務至上」的經營理念，贏得了廣大顧客的信賴與支持。
        </p>
        
        <div class="row g-4 mb-5">
            <div class="col-6 col-lg-3">
                <div class="text-center p-3">
                    <svg width="50" height="50" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M18 6h-2c0-2.21-1.79-4-4-4S8 3.79 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6-2c1.1 0 2 .9 2 2h-4c0-1.1.9-2 2-2zm6 16H6V8h2v2c0 .55.45 1 1 1s1-.45 1-1V8h4v2c0 .55.45 1 1 1s1-.45 1-1V8h2v12z"/></svg>
                    <h5 class="mt-3 mb-2">正品保證</h5>
                    <p class="text-muted mb-0" style="font-size:14px;">100%正品，假一賠十</p>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="text-center p-3">
                    <svg width="50" height="50" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4z"/></svg>
                    <h5 class="mt-3 mb-2">快速配送</h5>
                    <p class="text-muted mb-0" style="font-size:14px;">全台宅配，3-5天到貨</p>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="text-center p-3">
                    <svg width="50" height="50" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg>
                    <h5 class="mt-3 mb-2">安全付款</h5>
                    <p class="text-muted mb-0" style="font-size:14px;">貨到付款，安心購物</p>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="text-center p-3">
                    <svg width="50" height="50" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"/></svg>
                    <h5 class="mt-3 mb-2">客服支援</h5>
                    <p class="text-muted mb-0" style="font-size:14px;">專業客服團隊</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 數據展示 -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="bg-white rounded p-4 text-center h-100">
                <div style="font-size:36px;font-weight:700;color:#ee4d2d;">10萬+</div>
                <div class="text-muted">滿意顧客</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="bg-white rounded p-4 text-center h-100">
                <div style="font-size:36px;font-weight:700;color:#ee4d2d;">5000+</div>
                <div class="text-muted">精選商品</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="bg-white rounded p-4 text-center h-100">
                <div style="font-size:36px;font-weight:700;color:#ee4d2d;">99%</div>
                <div class="text-muted">好評率</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="bg-white rounded p-4 text-center h-100">
                <div style="font-size:36px;font-weight:700;color:#ee4d2d;">24h</div>
                <div class="text-muted">快速出貨</div>
            </div>
        </div>
    </div>
    
    <!-- 我們的承諾 -->
    <div class="bg-white rounded p-4 mb-4">
        <h4 class="mb-4 text-center">我們的承諾</h4>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="text-center">
                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:80px;height:80px;background:#fff5f5;">
                        <svg width="40" height="40" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z"/></svg>
                    </div>
                    <h5>品質保證</h5>
                    <p class="text-muted" style="font-size:14px;">所有商品均經過嚴格品質檢測，確保每一件商品都符合標準。</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center">
                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:80px;height:80px;background:#fff5f5;">
                        <svg width="40" height="40" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/></svg>
                    </div>
                    <h5>價格實惠</h5>
                    <p class="text-muted" style="font-size:14px;">直接與供應商合作，省去中間環節，為您提供最優惠的價格。</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center">
                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:80px;height:80px;background:#fff5f5;">
                        <svg width="40" height="40" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
                    </div>
                    <h5>售後無憂</h5>
                    <p class="text-muted" style="font-size:14px;">7天無理由退換貨，專業客服團隊隨時為您解決問題。</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 聯繫我們 -->
    <div class="bg-white rounded p-4 text-center">
        <h5 class="mb-3">有任何問題？歡迎聯繫我們</h5>
        <p class="text-muted mb-3">我們的客服團隊將竭誠為您服務</p>
        <a href="<?php echo esc_url(oip_get_contact_url()); ?>"<?php echo oip_get_line_id() ? ' target="_blank" rel="noopener"' : ''; ?> class="btn btn-outline-danger me-2"><?php echo oip_get_line_id() ? 'LINE 客服' : '聯繫客服'; ?></a>
        <a href="<?php echo home_url(); ?>" class="btn btn-danger">開始購物</a>
    </div>
</main>
        <?php
        echo $shop->get_footer();
    }
    
    // ========== 聯繫客服 ==========
    public static function render_contact($shop) {
        // 獲取後台配置的聯繫方式
        $email_settings = OIP_Email_Template::get_settings();
        $line_id = !empty($email_settings['line_id']) ? $email_settings['line_id'] : '';
        $phone = !empty($email_settings['customer_service_phone']) ? $email_settings['customer_service_phone'] : '';
        $admin_email = get_option('admin_email');
        
        // LINE 連結
        $line_url = '';
        if ($line_id) {
            // 移除 @ 符號（如果有的話）用於生成連結
            $line_id_clean = ltrim($line_id, '@');
            $line_url = 'https://line.me/R/ti/p/@' . urlencode($line_id_clean);
        }
        
        echo $shop->get_header('聯繫客服');
        ?>
<main class="shop-main">
    <?php if ($line_id): ?>
    <!-- LINE 快速聯繫（主要方式） -->
    <div class="bg-white rounded p-4 mb-4 text-center">
        <div style="background:linear-gradient(135deg,#00B900,#00C300);border-radius:16px;padding:30px 20px;max-width:500px;margin:0 auto;">
            <svg width="60" height="60" fill="#fff" viewBox="0 0 24 24" style="margin-bottom:15px;">
                <path d="M19.365 9.863c.349 0 .63.285.63.631 0 .345-.281.63-.63.63H17.61v1.125h1.755c.349 0 .63.283.63.63 0 .344-.281.629-.63.629h-2.386c-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63h2.386c.346 0 .627.285.627.63 0 .349-.281.63-.63.63H17.61v1.125h1.755zm-3.855 3.016c0 .27-.174.51-.432.596-.064.021-.133.031-.199.031-.211 0-.391-.09-.51-.25l-2.443-3.317v2.94c0 .344-.279.629-.631.629-.346 0-.626-.285-.626-.629V8.108c0-.27.173-.51.43-.595.06-.023.136-.033.194-.033.195 0 .375.104.495.254l2.462 3.33V8.108c0-.345.282-.63.63-.63.345 0 .63.285.63.63v4.771zm-5.741 0c0 .344-.282.629-.631.629-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63.346 0 .628.285.628.63v4.771zm-2.466.629H4.917c-.345 0-.63-.285-.63-.629V8.108c0-.345.285-.63.63-.63.348 0 .63.285.63.63v4.141h1.756c.348 0 .629.283.629.63 0 .344-.282.629-.629.629M24 10.314C24 4.943 18.615.572 12 .572S0 4.943 0 10.314c0 4.811 4.27 8.842 10.035 9.608.391.082.923.258 1.058.59.12.301.079.766.038 1.08l-.164 1.02c-.045.301-.24 1.186 1.049.645 1.291-.539 6.916-4.078 9.436-6.975C23.176 14.393 24 12.458 24 10.314"/>
            </svg>
            <h2 style="color:#fff;font-size:24px;margin-bottom:10px;">LINE 即時客服</h2>
            <p style="color:rgba(255,255,255,.9);font-size:14px;margin-bottom:20px;">點擊下方按鈕，立即與客服人員對話</p>
            <a href="<?php echo esc_url($line_url); ?>" target="_blank" rel="noopener" 
               style="display:inline-block;background:#fff;color:#00B900;padding:15px 40px;border-radius:30px;font-size:18px;font-weight:700;text-decoration:none;box-shadow:0 4px 15px rgba(0,0,0,.2);transition:transform .2s;">
                <svg width="24" height="24" fill="#00B900" viewBox="0 0 24 24" style="vertical-align:middle;margin-right:8px;">
                    <path d="M19.365 9.863c.349 0 .63.285.63.631 0 .345-.281.63-.63.63H17.61v1.125h1.755c.349 0 .63.283.63.63 0 .344-.281.629-.63.629h-2.386c-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63h2.386c.346 0 .627.285.627.63 0 .349-.281.63-.63.63H17.61v1.125h1.755zm-3.855 3.016c0 .27-.174.51-.432.596-.064.021-.133.031-.199.031-.211 0-.391-.09-.51-.25l-2.443-3.317v2.94c0 .344-.279.629-.631.629-.346 0-.626-.285-.626-.629V8.108c0-.27.173-.51.43-.595.06-.023.136-.033.194-.033.195 0 .375.104.495.254l2.462 3.33V8.108c0-.345.282-.63.63-.63.345 0 .63.285.63.63v4.771zm-5.741 0c0 .344-.282.629-.631.629-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63.346 0 .628.285.628.63v4.771zm-2.466.629H4.917c-.345 0-.63-.285-.63-.629V8.108c0-.345.285-.63.63-.63.348 0 .63.285.63.63v4.141h1.756c.348 0 .629.283.629.63 0 .344-.282.629-.629.629M24 10.314C24 4.943 18.615.572 12 .572S0 4.943 0 10.314c0 4.811 4.27 8.842 10.035 9.608.391.082.923.258 1.058.59.12.301.079.766.038 1.08l-.164 1.02c-.045.301-.24 1.186 1.049.645 1.291-.539 6.916-4.078 9.436-6.975C23.176 14.393 24 12.458 24 10.314"/>
                </svg>
                加入好友
            </a>
            <p style="color:rgba(255,255,255,.8);font-size:13px;margin-top:15px;">LINE ID: <?php echo esc_html($line_id); ?></p>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- 其他聯繫方式 -->
    <div class="row g-3 mb-4">
        <?php if ($phone): ?>
        <div class="col-6 col-md-3">
            <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9]/', '', $phone)); ?>" class="bg-white rounded p-3 text-center h-100 d-block text-decoration-none" style="color:#333;">
                <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-2" style="width:50px;height:50px;background:#fff5f5;">
                    <svg width="24" height="24" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                </div>
                <h6 class="mb-1">客服專線</h6>
                <p class="text-muted mb-0" style="font-size:13px;"><?php echo esc_html($phone); ?></p>
                <small class="text-danger">點擊撥打</small>
            </a>
        </div>
        <?php endif; ?>
        <div class="col-6 col-md-3">
            <a href="mailto:<?php echo esc_attr($admin_email); ?>" class="bg-white rounded p-3 text-center h-100 d-block text-decoration-none" style="color:#333;">
                <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-2" style="width:50px;height:50px;background:#fff5f5;">
                    <svg width="24" height="24" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
                </div>
                <h6 class="mb-1">電子郵件</h6>
                <p class="text-muted mb-0" style="font-size:13px;"><?php echo esc_html($admin_email); ?></p>
                <small class="text-danger">點擊發送</small>
            </a>
        </div>
        <?php if ($line_id): ?>
        <div class="col-6 col-md-3">
            <a href="<?php echo esc_url($line_url); ?>" target="_blank" rel="noopener" class="bg-white rounded p-3 text-center h-100 d-block text-decoration-none" style="color:#333;">
                <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-2" style="width:50px;height:50px;background:#e8f5e9;">
                    <svg width="24" height="24" fill="#00B900" viewBox="0 0 24 24"><path d="M19.365 9.863c.349 0 .63.285.63.631 0 .345-.281.63-.63.63H17.61v1.125h1.755c.349 0 .63.283.63.63 0 .344-.281.629-.63.629h-2.386c-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63h2.386c.346 0 .627.285.627.63 0 .349-.281.63-.63.63H17.61v1.125h1.755zm-3.855 3.016c0 .27-.174.51-.432.596-.064.021-.133.031-.199.031-.211 0-.391-.09-.51-.25l-2.443-3.317v2.94c0 .344-.279.629-.631.629-.346 0-.626-.285-.626-.629V8.108c0-.27.173-.51.43-.595.06-.023.136-.033.194-.033.195 0 .375.104.495.254l2.462 3.33V8.108c0-.345.282-.63.63-.63.345 0 .63.285.63.63v4.771zm-5.741 0c0 .344-.282.629-.631.629-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63.346 0 .628.285.628.63v4.771zm-2.466.629H4.917c-.345 0-.63-.285-.63-.629V8.108c0-.345.285-.63.63-.63.348 0 .63.285.63.63v4.141h1.756c.348 0 .629.283.629.63 0 .344-.282.629-.629.629M24 10.314C24 4.943 18.615.572 12 .572S0 4.943 0 10.314c0 4.811 4.27 8.842 10.035 9.608.391.082.923.258 1.058.59.12.301.079.766.038 1.08l-.164 1.02c-.045.301-.24 1.186 1.049.645 1.291-.539 6.916-4.078 9.436-6.975C23.176 14.393 24 12.458 24 10.314"/></svg>
                </div>
                <h6 class="mb-1">LINE 客服</h6>
                <p class="text-muted mb-0" style="font-size:13px;"><?php echo esc_html($line_id); ?></p>
                <small style="color:#00B900;">點擊加入</small>
            </a>
        </div>
        <?php endif; ?>
        <div class="col-6 col-md-3">
            <div class="bg-white rounded p-3 text-center h-100">
                <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-2" style="width:50px;height:50px;background:#fff5f5;">
                    <svg width="24" height="24" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg>
                </div>
                <h6 class="mb-1">服務時間</h6>
                <p class="text-muted mb-0" style="font-size:13px;">週一至週五</p>
                <small class="text-muted">9:00 - 18:00</small>
            </div>
        </div>
    </div>
    
    <div class="row g-4">
        <div class="col-12 col-lg-7">
            <div class="bg-white rounded p-4 h-100">
                <h2 class="h4 mb-4">線上留言</h2>
                <form>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">您的姓名 <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" required placeholder="請輸入姓名">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">聯絡電話</label>
                            <input type="tel" class="form-control" placeholder="請輸入電話">
                        </div>
                        <div class="col-12">
                            <label class="form-label">電子郵件 <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" required placeholder="請輸入Email">
                        </div>
                        <div class="col-12">
                            <label class="form-label">問題類型</label>
                            <select class="form-select">
                                <option>請選擇問題類型</option>
                                <option>商品諮詢</option>
                                <option>訂單查詢</option>
                                <option>物流配送</option>
                                <option>退換貨申請</option>
                                <option>帳戶問題</option>
                                <option>投訴建議</option>
                                <option>其他問題</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">訊息內容 <span class="text-danger">*</span></label>
                            <textarea class="form-control" rows="5" required placeholder="請詳細描述您的問題，我們會盡快回覆您"></textarea>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-danger px-4">送出訊息</button>
                            <?php if ($line_id): ?>
                            <span class="text-muted ms-3" style="font-size:13px;">或直接 <a href="<?php echo esc_url($line_url); ?>" target="_blank" style="color:#00B900;">LINE 聯繫我們</a></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-12 col-lg-5">
            <div class="bg-white rounded p-4 mb-4">
                <h2 class="h5 mb-4">常見問題</h2>
                <div class="accordion" id="contactFaq">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#cfaq1" style="font-size:14px;">
                                如何查詢訂單狀態？
                            </button>
                        </h2>
                        <div id="cfaq1" class="accordion-collapse collapse" data-bs-parent="#contactFaq">
                            <div class="accordion-body text-muted" style="font-size:14px;">登入會員後，在「我的訂單」頁面可以查看所有訂單的即時狀態。</div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#cfaq2" style="font-size:14px;">
                                商品可以退換嗎？
                            </button>
                        </h2>
                        <div id="cfaq2" class="accordion-collapse collapse" data-bs-parent="#contactFaq">
                            <div class="accordion-body text-muted" style="font-size:14px;">收到商品7天內，如有品質問題可申請退換貨，請保持商品完整。</div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#cfaq3" style="font-size:14px;">
                                配送需要多久？
                            </button>
                        </h2>
                        <div id="cfaq3" class="accordion-collapse collapse" data-bs-parent="#contactFaq">
                            <div class="accordion-body text-muted" style="font-size:14px;">一般地區3-5個工作天，偏遠地區可能需要額外1-2天。</div>
                        </div>
                    </div>
                </div>
                <div class="mt-3 text-center">
                    <a href="<?php echo home_url('/?oip_shop=faq'); ?>" class="text-decoration-none" style="color:#ee4d2d;font-size:14px;">查看更多常見問題 →</a>
                </div>
            </div>
            
            <div class="bg-white rounded p-4">
                <h2 class="h5 mb-3">服務承諾</h2>
                <ul class="list-unstyled mb-0">
                    <li class="d-flex align-items-start gap-2 mb-3">
                        <svg width="20" height="20" fill="#ee4d2d" viewBox="0 0 24 24" class="flex-shrink-0 mt-1"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                        <div>
                            <strong style="font-size:14px;">快速回覆</strong>
                            <p class="text-muted mb-0" style="font-size:13px;">工作時間內2小時內回覆</p>
                        </div>
                    </li>
                    <li class="d-flex align-items-start gap-2 mb-3">
                        <svg width="20" height="20" fill="#ee4d2d" viewBox="0 0 24 24" class="flex-shrink-0 mt-1"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                        <div>
                            <strong style="font-size:14px;">專業服務</strong>
                            <p class="text-muted mb-0" style="font-size:13px;">專業客服團隊為您解答</p>
                        </div>
                    </li>
                    <li class="d-flex align-items-start gap-2">
                        <svg width="20" height="20" fill="#ee4d2d" viewBox="0 0 24 24" class="flex-shrink-0 mt-1"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                        <div>
                            <strong style="font-size:14px;">滿意保證</strong>
                            <p class="text-muted mb-0" style="font-size:13px;">不滿意可申請退換貨</p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</main>
        <?php
        echo $shop->get_footer();
    }
    
    // ========== 常見問題 ==========
    public static function render_faq($shop) {
        echo $shop->get_header('常見問題');
        $faqs = [
            ['q' => '如何下單購買？', 'a' => '選擇商品後加入購物車，確認購物車內容後點擊結帳，填寫收件資訊即可完成訂購。'],
            ['q' => '付款方式有哪些？', 'a' => '目前支援貨到付款，商品送達時以現金支付給配送人員即可。'],
            ['q' => '商品多久會送達？', 'a' => '一般商品約3-5個工作天送達，偏遠地區可能需要額外1-2天。'],
            ['q' => '可以更改訂單嗎？', 'a' => '訂單成立後如需更改，請盡快聯繫客服，出貨後將無法更改。'],
            ['q' => '如何退換貨？', 'a' => '收到商品7天內如有問題可申請退換貨，請保持商品完整並聯繫客服。'],
            ['q' => '運費如何計算？', 'a' => '目前全館免運費，直接宅配到府。'],
        ];
        ?>
<main class="shop-main">
    <div class="bg-white rounded p-4 mb-4">
        <h1 class="h3 mb-4">常見問題</h1>
        <div class="accordion" id="faqAccordion">
            <?php foreach ($faqs as $i => $faq): ?>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button <?php echo $i > 0 ? 'collapsed' : ''; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#faq<?php echo $i; ?>">
                        <?php echo esc_html($faq['q']); ?>
                    </button>
                </h2>
                <div id="faq<?php echo $i; ?>" class="accordion-collapse collapse <?php echo $i === 0 ? 'show' : ''; ?>" data-bs-parent="#faqAccordion">
                    <div class="accordion-body text-muted"><?php echo esc_html($faq['a']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <div class="bg-white rounded p-4 text-center">
        <h5 class="mb-3">還有其他問題？</h5>
        <a href="<?php echo esc_url(oip_get_contact_url()); ?>"<?php echo oip_get_line_id() ? ' target="_blank" rel="noopener"' : ''; ?> class="btn btn-danger"><?php echo oip_get_line_id() ? 'LINE 客服' : '聯繫客服'; ?></a>
    </div>
</main>
        <?php
        echo $shop->get_footer();
    }
    
    // ========== 配送說明 ==========
    public static function render_shipping($shop) {
        echo $shop->get_header('配送說明');
        ?>
<main class="shop-main">
    <div class="bg-white rounded p-4">
        <h1 class="h3 mb-4">配送說明</h1>
        
        <h5 class="mt-4 mb-3">配送方式</h5>
        <ul class="text-muted">
            <li class="mb-2">宅配到府：由專業物流配送至您指定地址</li>
            <li class="mb-2">配送時間：週一至週六，09:00-18:00</li>
        </ul>
        
        <h5 class="mt-4 mb-3">配送時效</h5>
        <ul class="text-muted">
            <li class="mb-2">一般地區：3-5 個工作天</li>
            <li class="mb-2">偏遠地區：5-7 個工作天</li>
            <li class="mb-2">離島地區：7-10 個工作天</li>
        </ul>
        
        <h5 class="mt-4 mb-3">運費說明</h5>
        <p class="text-muted">目前全館免運費！</p>
        
        <h5 class="mt-4 mb-3">注意事項</h5>
        <ul class="text-muted">
            <li class="mb-2">請確保收件地址正確，以免延誤配送</li>
            <li class="mb-2">配送時請保持電話暢通</li>
            <li class="mb-2">如無人簽收，物流將改期配送</li>
        </ul>
    </div>
</main>
        <?php
        echo $shop->get_footer();
    }
    
    // ========== 退換貨政策 ==========
    public static function render_returns($shop) {
        echo $shop->get_header('退換貨政策');
        ?>
<main class="shop-main">
    <div class="bg-white rounded p-4 mb-4">
        <h1 class="h3 mb-4">退換貨政策</h1>
        
        <h5 class="mt-4 mb-3">退換貨條件</h5>
        <ul class="text-muted">
            <li class="mb-2">收到商品 7 天內可申請退換貨</li>
            <li class="mb-2">商品須保持全新狀態，包裝完整</li>
            <li class="mb-2">附上原始發票或購買證明</li>
        </ul>
        
        <h5 class="mt-4 mb-3">不接受退換貨情況</h5>
        <ul class="text-muted">
            <li class="mb-2">已拆封使用的商品</li>
            <li class="mb-2">人為損壞的商品</li>
            <li class="mb-2">超過退換貨期限</li>
            <li class="mb-2">特價或清倉商品</li>
        </ul>
        
        <h5 class="mt-4 mb-3">退換貨流程</h5>
        <div class="row g-3">
            <div class="col-6 col-md-3">
                <div class="text-center p-3 border rounded">
                    <div class="rounded-circle bg-danger text-white d-inline-flex align-items-center justify-content-center mb-2" style="width:40px;height:40px;">1</div>
                    <p class="mb-0" style="font-size:14px;">聯繫客服</p>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="text-center p-3 border rounded">
                    <div class="rounded-circle bg-danger text-white d-inline-flex align-items-center justify-content-center mb-2" style="width:40px;height:40px;">2</div>
                    <p class="mb-0" style="font-size:14px;">審核通過</p>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="text-center p-3 border rounded">
                    <div class="rounded-circle bg-danger text-white d-inline-flex align-items-center justify-content-center mb-2" style="width:40px;height:40px;">3</div>
                    <p class="mb-0" style="font-size:14px;">寄回商品</p>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="text-center p-3 border rounded">
                    <div class="rounded-circle bg-danger text-white d-inline-flex align-items-center justify-content-center mb-2" style="width:40px;height:40px;">4</div>
                    <p class="mb-0" style="font-size:14px;">退款/換貨</p>
                </div>
            </div>
        </div>
    </div>
</main>
        <?php
        echo $shop->get_footer();
    }
    
    // ========== 隱私政策 ==========
    public static function render_privacy($shop) {
        $site_name = get_bloginfo('name');
        echo $shop->get_header('隱私政策');
        ?>
<main class="shop-main">
    <div class="bg-white rounded p-4">
        <h1 class="h3 mb-4">隱私政策</h1>
        
        <p class="text-muted">本隱私政策說明 <?php echo esc_html($site_name); ?> 如何收集、使用和保護您的個人資料。</p>
        
        <h5 class="mt-4 mb-3">資料收集</h5>
        <p class="text-muted">我們可能收集以下資料：姓名、聯絡方式、配送地址、付款資訊等。</p>
        
        <h5 class="mt-4 mb-3">資料使用</h5>
        <p class="text-muted">您的資料僅用於：處理訂單、配送商品、客戶服務、改善服務品質。</p>
        
        <h5 class="mt-4 mb-3">資料保護</h5>
        <p class="text-muted">我們採用適當的安全措施保護您的個人資料，防止未經授權的存取。</p>
        
        <h5 class="mt-4 mb-3">Cookie 使用</h5>
        <p class="text-muted">本網站使用 Cookie 來改善您的瀏覽體驗和提供個人化服務。</p>
        
        <h5 class="mt-4 mb-3">聯繫我們</h5>
        <p class="text-muted">如有任何隱私相關問題，請<a href="<?php echo esc_url(oip_get_contact_url()); ?>"<?php echo oip_get_line_id() ? ' target="_blank" rel="noopener"' : ''; ?> style="color:<?php echo oip_get_line_id() ? '#00B900' : '#ee4d2d'; ?>;"><?php echo oip_get_line_id() ? 'LINE 聯繫客服' : '聯繫客服'; ?></a>。</p>
    </div>
</main>
        <?php
        echo $shop->get_footer();
    }
    
    // ========== 服務條款 ==========
    public static function render_terms($shop) {
        $site_name = get_bloginfo('name');
        echo $shop->get_header('服務條款');
        ?>
<main class="shop-main">
    <div class="bg-white rounded p-4">
        <h1 class="h3 mb-4">服務條款</h1>
        
        <p class="text-muted">歡迎使用 <?php echo esc_html($site_name); ?>。使用本網站即表示您同意以下條款。</p>
        
        <h5 class="mt-4 mb-3">帳戶責任</h5>
        <p class="text-muted">您有責任保管好您的帳戶資訊，並對帳戶下的所有活動負責。</p>
        
        <h5 class="mt-4 mb-3">商品資訊</h5>
        <p class="text-muted">我們盡力確保商品資訊準確，但不保證完全無誤。實際商品以收到為準。</p>
        
        <h5 class="mt-4 mb-3">價格與付款</h5>
        <p class="text-muted">所有價格均以新台幣計價。我們保留修改價格的權利。</p>
        
        <h5 class="mt-4 mb-3">智慧財產權</h5>
        <p class="text-muted">本網站所有內容均受智慧財產權保護，未經授權不得使用。</p>
        
        <h5 class="mt-4 mb-3">免責聲明</h5>
        <p class="text-muted">本網站不對任何間接損失負責。使用本網站的風險由用戶自行承擔。</p>
        
        <h5 class="mt-4 mb-3">條款修改</h5>
        <p class="text-muted">我們保留隨時修改本條款的權利，修改後將在網站上公布。</p>
    </div>
</main>
        <?php
        echo $shop->get_footer();
    }
}
