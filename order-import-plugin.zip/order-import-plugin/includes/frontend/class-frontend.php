<?php
/**
 * 前台頁面 - 主控制器
 * 負責路由和登入處理邏輯
 */

if (!defined('ABSPATH')) exit;

class OIP_Frontend {
    
    public function __construct() {
        // 載入頁面類
        require_once __DIR__ . '/class-frontend-auth.php';
        require_once __DIR__ . '/class-frontend-orders.php';
        
        add_action('init', [$this, 'handle_login']);
        add_action('init', [$this, 'handle_logout']);
        add_action('init', [$this, 'handle_password_reset']);
        add_action('template_redirect', [$this, 'override_template']);
    }
    
    public function override_template() {
        if (isset($_GET['oip_page'])) {
            $page = sanitize_text_field($_GET['oip_page']);
            if ($page === 'login') { OIP_Frontend_Auth::render_login($this); exit; }
            if ($page === 'orders') { OIP_Frontend_Orders::render_orders($this); exit; }
            if ($page === 'profile') { OIP_Frontend_Orders::render_profile($this); exit; }
            if ($page === 'reset-password') { OIP_Frontend_Auth::render_reset_password($this); exit; }
        }
    }
    
    public function handle_login() {
        // 處理登入
        if (isset($_POST['oip_login_submit'])) {
            if (!wp_verify_nonce($_POST['oip_login_nonce'], 'oip_login_action')) return;
            $email = sanitize_email($_POST['oip_email']);
            $password = $_POST['oip_password'] ?? '';
            $redirect = isset($_POST['redirect_to']) ? esc_url_raw($_POST['redirect_to']) : home_url('/?oip_page=orders');
            
            if (empty($email) || empty($password)) { 
                wp_redirect(add_query_arg('login_error', 'empty', wp_get_referer())); exit; 
            }
            
            $user = get_user_by('email', $email);
            if (!$user) { 
                wp_redirect(add_query_arg('login_error', 'notfound', wp_get_referer())); exit; 
            }
            
            $is_order_user = get_user_meta($user->ID, '_oip_order_user', true);
            $password_set = get_user_meta($user->ID, '_oip_password_set', true);
            
            if ($is_order_user === '1' && $password_set !== '1') {
                wp_set_password($password, $user->ID);
                update_user_meta($user->ID, '_oip_password_set', '1');
                $user = get_user_by('id', $user->ID);
            } else {
                if (!wp_check_password($password, $user->user_pass, $user->ID)) {
                    wp_redirect(add_query_arg('login_error', 'wrong', wp_get_referer())); exit;
                }
            }
            
            wp_set_auth_cookie($user->ID, true);
            wp_redirect($redirect); exit;
        }
        
        // 處理註冊
        if (isset($_POST['oip_register_submit'])) {
            if (!wp_verify_nonce($_POST['oip_register_nonce'], 'oip_register_action')) return;
            $email = sanitize_email($_POST['reg_email']);
            $password = $_POST['reg_password'] ?? '';
            $password2 = $_POST['reg_password2'] ?? '';
            $redirect = isset($_POST['redirect_to']) ? esc_url_raw($_POST['redirect_to']) : home_url('/?oip_page=orders');
            
            if (empty($email) || empty($password)) {
                wp_redirect(add_query_arg('reg_error', 'empty', wp_get_referer())); exit;
            }
            if (strlen($password) < 6) {
                wp_redirect(add_query_arg('reg_error', 'short', wp_get_referer())); exit;
            }
            if ($password !== $password2) {
                wp_redirect(add_query_arg('reg_error', 'mismatch', wp_get_referer())); exit;
            }
            if (!is_email($email)) {
                wp_redirect(add_query_arg('reg_error', 'invalid_email', wp_get_referer())); exit;
            }
            
            $existing_user = get_user_by('email', $email);
            if ($existing_user) {
                $is_order_user = get_user_meta($existing_user->ID, '_oip_order_user', true);
                $password_set = get_user_meta($existing_user->ID, '_oip_password_set', true);
                
                if ($is_order_user === '1' && $password_set !== '1') {
                    wp_set_password($password, $existing_user->ID);
                    update_user_meta($existing_user->ID, '_oip_password_set', '1');
                    wp_set_auth_cookie($existing_user->ID, true);
                    wp_redirect($redirect); exit;
                } else {
                    wp_redirect(add_query_arg('reg_error', 'exists', wp_get_referer())); exit;
                }
            }
            
            $username = sanitize_user(explode('@', $email)[0] . '_' . rand(100, 999));
            $user_id = wp_create_user($username, $password, $email);
            
            if (is_wp_error($user_id)) {
                wp_redirect(add_query_arg('reg_error', 'failed', wp_get_referer())); exit;
            }
            
            update_user_meta($user_id, '_oip_password_set', '1');
            wp_set_auth_cookie($user_id, true);
            wp_redirect($redirect); exit;
        }
        
        // 處理找回密碼
        if (isset($_POST['oip_forgot_submit'])) {
            if (!wp_verify_nonce($_POST['oip_forgot_nonce'], 'oip_forgot_action')) return;
            $email = sanitize_email($_POST['forgot_email']);
            
            if (empty($email) || !is_email($email)) {
                wp_redirect(add_query_arg('forgot_error', 'invalid', wp_get_referer())); exit;
            }
            
            $last_sent = get_transient('oip_reset_email_' . md5($email));
            if ($last_sent) {
                $wait_time = 60 - (time() - $last_sent);
                wp_redirect(add_query_arg(['forgot_error' => 'too_fast', 'wait' => $wait_time], wp_get_referer())); exit;
            }
            
            $user = get_user_by('email', $email);
            if (!$user) {
                set_transient('oip_reset_email_' . md5($email), time(), 60);
                wp_redirect(add_query_arg('forgot_success', '1', wp_get_referer())); exit;
            }
            
            $reset_key = get_password_reset_key($user);
            if (is_wp_error($reset_key)) {
                wp_redirect(add_query_arg('forgot_error', 'failed', wp_get_referer())); exit;
            }
            
            $reset_url = home_url('/?oip_page=reset-password&key=' . $reset_key . '&login=' . rawurlencode($user->user_login));
            $sent = $this->send_password_reset_email($user, $reset_url);
            
            if ($sent) {
                set_transient('oip_reset_email_' . md5($email), time(), 60);
                wp_redirect(add_query_arg('forgot_success', '1', wp_get_referer())); exit;
            } else {
                wp_redirect(add_query_arg('forgot_error', 'send_failed', wp_get_referer())); exit;
            }
        }
    }
    
    public function handle_password_reset() {
        if (isset($_POST['oip_reset_submit'])) {
            if (!wp_verify_nonce($_POST['oip_reset_nonce'], 'oip_reset_action')) return;
            
            $key = sanitize_text_field($_POST['reset_key']);
            $login = sanitize_text_field($_POST['reset_login']);
            $password = $_POST['new_password'] ?? '';
            $password2 = $_POST['new_password2'] ?? '';
            
            if (empty($password) || strlen($password) < 6) {
                wp_redirect(add_query_arg(['reset_error' => 'short', 'key' => $key, 'login' => $login], home_url('/?oip_page=reset-password'))); exit;
            }
            if ($password !== $password2) {
                wp_redirect(add_query_arg(['reset_error' => 'mismatch', 'key' => $key, 'login' => $login], home_url('/?oip_page=reset-password'))); exit;
            }
            
            $user = check_password_reset_key($key, $login);
            if (is_wp_error($user)) {
                wp_redirect(add_query_arg('reset_error', 'invalid_key', home_url('/?oip_page=login'))); exit;
            }
            
            wp_set_password($password, $user->ID);
            update_user_meta($user->ID, '_oip_password_set', '1');
            wp_redirect(add_query_arg('reset_success', '1', home_url('/?oip_page=login'))); exit;
        }
    }
    
    private function send_password_reset_email($user, $reset_url) {
        $site_name = get_bloginfo('name');
        $to = $user->user_email;
        $subject = '【' . $site_name . '】重置您的密碼';
        
        $message = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f5f5f5;font-family:-apple-system,sans-serif;">
<div style="max-width:600px;margin:0 auto;padding:20px;">
<div style="background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,.1);">
<div style="background:#ee4d2d;padding:25px;text-align:center;"><h1 style="color:#fff;margin:0;font-size:24px;">' . esc_html($site_name) . '</h1></div>
<div style="padding:30px;">
<h2 style="color:#333;margin:0 0 20px;">重置您的密碼</h2>
<p style="color:#666;line-height:1.8;">您好，' . esc_html($user->display_name ?: '會員') . '！<br><br>我們收到了您的密碼重置請求。請點擊下方按鈕設置新密碼：</p>
<div style="text-align:center;margin:30px 0;"><a href="' . esc_url($reset_url) . '" style="display:inline-block;background:#ee4d2d;color:#fff;padding:15px 40px;text-decoration:none;border-radius:4px;font-size:16px;">重置密碼</a></div>
<p style="color:#999;font-size:13px;">此連結將在 24 小時後失效。如果您沒有請求重置密碼，請忽略此郵件。</p>
</div>
<div style="background:#fafafa;padding:20px;text-align:center;border-top:1px solid #eee;"><p style="color:#999;font-size:12px;margin:0;">© ' . date('Y') . ' ' . esc_html($site_name) . '</p></div>
</div></div></body></html>';
        
        return wp_mail($to, $subject, $message, ['Content-Type: text/html; charset=UTF-8']);
    }
    
    public function handle_logout() {
        if (isset($_GET['oip_logout']) && $_GET['oip_logout'] === '1') {
            wp_logout();
            wp_redirect(home_url()); exit;
        }
    }

    // ========== 公共樣式 ==========
    public function get_common_styles() {
        return '<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:"Noto Sans TC",-apple-system,sans-serif;background:#f5f5f5;color:#333;line-height:1.5}
a{text-decoration:none;color:inherit}
.top-bar{background:#ee4d2d;color:#fff;font-size:12px;padding:8px 0}
.top-bar-inner{max-width:1200px;margin:0 auto;padding:0 15px;display:flex;justify-content:space-between}
.top-bar a{color:#fff;margin-left:12px}
.main-header{background:linear-gradient(180deg,#ee4d2d,#f53d2d);padding:15px 0}
.header-inner{max-width:1200px;margin:0 auto;padding:0 15px;display:flex;align-items:flex-start;gap:25px}
.logo{display:flex;align-items:center;gap:10px;color:#fff;font-size:26px;font-weight:700;height:44px}
.logo svg{width:45px;height:45px;fill:#fff}
.search-wrap{flex:1}
.search-box{display:flex;background:#fff;border-radius:4px;overflow:hidden;height:44px}
.search-box input{flex:1;padding:0 15px;border:none;outline:none;font-size:14px}
.search-box button{padding:0 25px;background:#fb6445;color:#fff;border:none;cursor:pointer}
.header-actions{display:flex;gap:15px}
.header-actions a{color:#fff;display:flex;flex-direction:column;align-items:center;gap:4px;font-size:11px}
.header-actions svg{width:24px;height:24px;fill:#fff}
.main-nav{background:#fff;border-bottom:1px solid #e8e8e8;position:sticky;top:0;z-index:100}
.nav-inner{max-width:1200px;margin:0 auto;padding:0 15px;display:flex;justify-content:space-between}
.nav-menu{display:flex}
.nav-menu a{padding:15px 18px;font-size:14px;color:#333;border-bottom:2px solid transparent}
.nav-menu a:hover,.nav-menu a.active{color:#ee4d2d;border-bottom-color:#ee4d2d;background:#fff5f5}
.page-container{max-width:1200px;margin:0 auto;padding:20px 15px;min-height:60vh}
.shop-footer{background:#fff;border-top:4px solid #ee4d2d;margin-top:40px}
.footer-main{max-width:1200px;margin:0 auto;padding:40px 15px;display:grid;grid-template-columns:repeat(4,1fr);gap:30px}
.footer-col h4{font-size:14px;color:#333;margin-bottom:15px}
.footer-col a{display:block;font-size:13px;color:#666;margin-bottom:10px}
.footer-col a:hover{color:#ee4d2d}
.footer-bottom{background:#f5f5f5;padding:20px 0;text-align:center;font-size:12px;color:#999}
@media(max-width:768px){
.top-bar{display:none}
.header-inner{flex-wrap:wrap;gap:10px;padding:10px 15px}
.logo{font-size:18px}.logo svg{width:30px;height:30px}
.search-wrap{order:3;width:100%}
.nav-menu{overflow-x:auto;width:100%}
.nav-menu a{padding:10px 12px;font-size:13px;white-space:nowrap}
.footer-main{grid-template-columns:repeat(2,1fr);padding:25px 15px}
}
</style>';
    }
    
    public function get_header_html($active = '') {
        $site_name = get_bloginfo('name');
        $is_logged_in = is_user_logged_in();
        
        return '<!DOCTYPE html><html lang="zh-TW"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>' . esc_html($site_name) . '</title>
<link href="' . plugins_url('assets/css/noto-sans-tc.css', dirname(dirname(__FILE__))) . '" rel="stylesheet">
' . $this->get_common_styles() . '</head><body>
<div class="top-bar"><div class="top-bar-inner"><div><span>歡迎來到 ' . esc_html($site_name) . '</span></div>
<div><a href="' . home_url('/?oip_shop=faq') . '">幫助中心</a>' . ($is_logged_in ? '<a href="' . home_url('/?oip_page=orders') . '">我的訂單</a><a href="' . home_url('/?oip_logout=1') . '">登出</a>' : '<a href="' . home_url('/?oip_page=login') . '">登入</a>') . '</div></div></div>
<header class="main-header"><div class="header-inner">
<a href="' . home_url() . '" class="logo"><svg viewBox="0 0 24 24"><path d="M18 6h-2c0-2.21-1.79-4-4-4S8 3.79 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6-2c1.1 0 2 .9 2 2h-4c0-1.1.9-2 2-2zm6 16H6V8h2v2c0 .55.45 1 1 1s1-.45 1-1V8h4v2c0 .55.45 1 1 1s1-.45 1-1V8h2v12z"/></svg>' . esc_html($site_name) . '</a>
<div class="search-wrap"><form class="search-box" action="' . home_url() . '" method="get"><input type="hidden" name="oip_shop" value="search"><input type="text" name="q" placeholder="搜尋商品..."><button type="submit">搜尋</button></form></div>
<div class="header-actions"><a href="' . home_url('/?oip_shop=cart') . '"><svg viewBox="0 0 24 24"><path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/></svg><span>購物車</span></a>
<a href="' . home_url('/?oip_page=orders') . '"><svg viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg><span>帳戶</span></a></div></div></header>
<nav class="main-nav"><div class="nav-inner"><div class="nav-menu">
<a href="' . home_url() . '">首頁</a>
<a href="' . home_url('/?oip_shop=flash-sale') . '">限時特賣</a>
<a href="' . home_url('/?oip_shop=new-arrivals') . '">新品上市</a>
<a href="' . home_url('/?oip_page=orders') . '" class="' . ($active === 'orders' ? 'active' : '') . '">我的訂單</a>
</div></div></nav>';
    }
    
    public function get_footer_html() {
        $site_name = get_bloginfo('name');
        return '<footer class="shop-footer"><div class="footer-main">
<div class="footer-col"><h4>客戶服務</h4><a href="' . home_url('/?oip_shop=faq') . '">常見問題</a><a href="' . home_url('/?oip_shop=shipping') . '">配送說明</a><a href="' . home_url('/?oip_shop=returns') . '">退換貨政策</a></div>
<div class="footer-col"><h4>關於我們</h4><a href="' . home_url('/?oip_shop=about') . '">公司介紹</a><a href="' . home_url('/?oip_shop=privacy') . '">隱私政策</a><a href="' . home_url('/?oip_shop=terms') . '">服務條款</a></div>
<div class="footer-col"><h4>付款方式</h4><p style="font-size:13px;color:#666;">貨到付款 / 信用卡 / ATM</p></div>
<div class="footer-col"><h4>物流配送</h4><p style="font-size:13px;color:#666;">宅配到府 / 超商取貨</p></div>
</div><div class="footer-bottom"><p>© ' . date('Y') . ' ' . esc_html($site_name) . ' 版權所有</p></div></footer></body></html>';
    }
}
