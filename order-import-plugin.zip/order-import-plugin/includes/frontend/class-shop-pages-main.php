<?php
/**
 * 商城頁面 - 首頁、分類、搜尋、商品詳情
 */

if (!defined('ABSPATH')) {
    exit;
}

class OIP_Shop_Pages_Main {
    
    // ========== 首頁 ==========
    public static function render_home($shop) {
        $banners = OIP_Product_Manager::get_banners();
        $categories = OIP_Product_Manager::get_categories();
        $all_products = OIP_Product_Manager::get_products(['status' => 'publish']);
        $icons = $shop->get_category_icons();
        
        $hot_products = $all_products;
        usort($hot_products, function($a, $b) { return $b->sales - $a->sales; });
        $hot_products = array_slice($hot_products, 0, 6);
        
        $sale_products = array_filter($all_products, function($p) {
            return $p->original_price && $p->original_price > $p->price;
        });
        usort($sale_products, function($a, $b) {
            $da = ($a->original_price - $a->price) / $a->original_price;
            $db = ($b->original_price - $b->price) / $b->original_price;
            return $db <=> $da;
        });
        $sale_products = array_slice(array_values($sale_products), 0, 6);
        
        echo $shop->get_header();
        ?>
<main class="shop-main">
    <div class="row g-3 mb-4">
        <div class="col-12 col-lg-8">
            <div class="banner-slider">
                <?php if (!empty($banners)): ?>
                <img src="<?php echo esc_url($banners[0]->image); ?>" alt="<?php echo esc_attr($banners[0]->title); ?>" id="main-banner">
                <button class="banner-nav prev" onclick="changeBanner(-1)">‹</button>
                <button class="banner-nav next" onclick="changeBanner(1)">›</button>
                <?php if (count($banners) > 1): ?>
                <div class="banner-dots">
                    <?php foreach ($banners as $i => $b): ?>
                    <span class="<?php echo $i === 0 ? 'active' : ''; ?>" onclick="showBanner(<?php echo $i; ?>)"></span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                <script>
                var banners = <?php echo json_encode(array_map(function($b){ return ['image'=>$b->image,'link'=>$b->link,'title'=>$b->title]; }, $banners)); ?>;
                var currentBanner = 0;
                function showBanner(i) {
                    currentBanner = i;
                    document.getElementById('main-banner').src = banners[i].image;
                    document.querySelectorAll('.banner-dots span').forEach(function(d,idx){ d.className = idx === i ? 'active' : ''; });
                }
                function changeBanner(dir) { showBanner((currentBanner + dir + banners.length) % banners.length); }
                setInterval(function(){ changeBanner(1); }, 5000);
                </script>
                <?php else: ?>
                <div style="width:100%;height:100%;background:linear-gradient(135deg,#ee4d2d 0%,#ff6633 50%,#ff8855 100%);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;text-align:center;padding:40px;">
                    <svg width="80" height="80" fill="#fff" viewBox="0 0 24 24" style="margin-bottom:20px;opacity:.9;"><path d="M18 6h-2c0-2.21-1.79-4-4-4S8 3.79 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6-2c1.1 0 2 .9 2 2h-4c0-1.1.9-2 2-2zm6 16H6V8h2v2c0 .55.45 1 1 1s1-.45 1-1V8h4v2c0 .55.45 1 1 1s1-.45 1-1V8h2v12z"/></svg>
                    <h2 style="font-size:32px;font-weight:700;margin:0 0 10px;text-shadow:0 2px 4px rgba(0,0,0,.2);"><?php echo get_bloginfo('name'); ?></h2>
                    <p style="font-size:16px;opacity:.9;margin:0;">品質保證 · 快速配送 · 安心購物</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-4 d-none d-lg-block">
            <div style="display:flex;flex-direction:column;gap:12px;height:100%;">
                <a href="<?php echo home_url('/?oip_page=login'); ?>" class="side-banner" style="flex:1;background:linear-gradient(135deg,#ff6633,#ee4d2d);border-radius:8px;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;text-align:center;padding:25px;text-decoration:none;transition:transform .2s,box-shadow .2s;">
                    <svg width="45" height="45" fill="#fff" viewBox="0 0 24 24" style="margin-bottom:12px;"><path d="M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-5-2c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm11 15H4v-2h16v2zm0-5H4V8h5.08L7 10.83 8.62 12 11 8.76l1-1.36 1 1.36L15.38 12 17 10.83 14.92 8H20v6z"/></svg>
                    <div style="font-size:18px;font-weight:700;margin-bottom:6px;">立即加入</div>
                    <div style="font-size:13px;opacity:.9;">會員專屬優惠</div>
                </a>
                <a href="<?php echo home_url('/?oip_shop=flash-sale'); ?>" class="side-banner" style="flex:1;background:linear-gradient(135deg,#00bfa5,#00d4aa);border-radius:8px;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;text-align:center;padding:25px;text-decoration:none;transition:transform .2s,box-shadow .2s;">
                    <svg width="45" height="45" fill="#fff" viewBox="0 0 24 24" style="margin-bottom:12px;"><path d="M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4zM6 18.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm13.5-9l1.96 2.5H17V9.5h2.5zm-1.5 9c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>
                    <div style="font-size:18px;font-weight:700;margin-bottom:6px;">免運費</div>
                    <div style="font-size:13px;opacity:.9;">全館免運宅配到府</div>
                </a>
            </div>
        </div>
    </div>
    
    <div class="cat-section">
        <h3>商品分類</h3>
        <div class="cat-grid">
            <?php foreach ($categories as $cat): 
                $icon_path = $icons[$cat->slug] ?? $icons['default'];
            ?>
            <a href="<?php echo home_url('/?oip_shop=category&cat=' . $cat->slug); ?>" class="cat-item">
                <div class="icon"><svg viewBox="0 0 24 24"><?php echo $icon_path; ?></svg></div>
                <span><?php echo esc_html($cat->name); ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    
    <?php if (!empty($sale_products)): ?>
    <div class="flash-section mb-4">
        <div class="flash-header">
            <div class="flash-title">
                <svg viewBox="0 0 24 24"><path d="M7 2v11h3v9l7-12h-4l4-8z"/></svg>
                限時特賣
                <div class="countdown"><span id="hours">08</span>:<span id="mins">45</span>:<span id="secs">30</span></div>
            </div>
            <a href="<?php echo home_url('/?oip_shop=flash-sale'); ?>" class="flash-more">查看更多 ›</a>
        </div>
        <div class="row g-2">
            <?php foreach ($sale_products as $p): echo $shop->render_product_card($p, true, 'col-6 col-md-4 col-lg-2'); endforeach; ?>
        </div>
    </div>
    <script>
    (function(){var h=8,m=45,s=30;setInterval(function(){if(--s<0){s=59;if(--m<0){m=59;if(--h<0)h=23;}}document.getElementById('hours').textContent=h.toString().padStart(2,'0');document.getElementById('mins').textContent=m.toString().padStart(2,'0');document.getElementById('secs').textContent=s.toString().padStart(2,'0');},1000);})();
    </script>
    <?php endif; ?>
    
    <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3">
            <div class="bg-white rounded p-3 h-100 d-flex align-items-center gap-3">
                <svg width="40" height="40" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M18 6h-2c0-2.21-1.79-4-4-4S8 3.79 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6-2c1.1 0 2 .9 2 2h-4c0-1.1.9-2 2-2zm6 16H6V8h2v2c0 .55.45 1 1 1s1-.45 1-1V8h4v2c0 .55.45 1 1 1s1-.45 1-1V8h2v12z"/></svg>
                <div><h6 class="mb-1" style="font-size:14px;">正品保證</h6><small class="text-muted">100%正品</small></div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="bg-white rounded p-3 h-100 d-flex align-items-center gap-3">
                <svg width="40" height="40" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4zM6 18.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm13.5-9l1.96 2.5H17V9.5h2.5zm-1.5 9c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>
                <div><h6 class="mb-1" style="font-size:14px;">快速配送</h6><small class="text-muted">3-5天到貨</small></div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="bg-white rounded p-3 h-100 d-flex align-items-center gap-3">
                <svg width="40" height="40" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>
                <div><h6 class="mb-1" style="font-size:14px;">安全付款</h6><small class="text-muted">多種付款方式</small></div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="bg-white rounded p-3 h-100 d-flex align-items-center gap-3">
                <svg width="40" height="40" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"/></svg>
                <div><h6 class="mb-1" style="font-size:14px;">客服支援</h6><small class="text-muted">專業服務</small></div>
            </div>
        </div>
    </div>
    
    <div class="mb-4">
        <div class="section-header">
            <h2 class="section-title"><svg viewBox="0 0 24 24"><path d="M13.5.67s.74 2.65.74 4.8c0 2.06-1.35 3.73-3.41 3.73-2.07 0-3.63-1.67-3.63-3.73l.03-.36C5.21 7.51 4 10.62 4 14c0 4.42 3.58 8 8 8s8-3.58 8-8C20 8.61 17.41 3.8 13.5.67z"/></svg>熱銷排行</h2>
            <a href="<?php echo home_url('/?oip_shop=best-sellers'); ?>" class="section-more">查看更多 ›</a>
        </div>
        <?php echo $shop->render_product_grid($hot_products, 6); ?>
    </div>
    
    <?php foreach ($categories as $cat): 
        $cat_products = array_filter($all_products, function($p) use ($cat) { return $p->category_id == $cat->id; });
        if (empty($cat_products)) continue;
        $cat_products = array_slice(array_values($cat_products), 0, 5);
    ?>
    <div class="mb-4">
        <div class="section-header">
            <h2 class="section-title"><?php echo esc_html($cat->name); ?></h2>
            <a href="<?php echo home_url('/?oip_shop=category&cat=' . $cat->slug); ?>" class="section-more">查看更多 ›</a>
        </div>
        <?php echo $shop->render_product_grid($cat_products, 5); ?>
    </div>
    <?php endforeach; ?>
    
    <div class="mb-4">
        <div class="section-header">
            <h2 class="section-title"><svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>為您推薦</h2>
        </div>
        <?php shuffle($all_products); echo $shop->render_product_grid(array_slice($all_products, 0, 10), 5); ?>
    </div>
    
    <!-- 品牌故事 -->
    <div class="bg-white rounded p-4 mb-4">
        <div class="row align-items-center">
            <div class="col-12 col-md-6 mb-3 mb-md-0">
                <h3 class="h5 mb-3" style="color:#ee4d2d;">為什麼選擇我們？</h3>
                <p class="text-muted mb-3" style="line-height:1.8;">
                    我們致力於為每位顧客提供最優質的購物體驗。從嚴選商品到快速配送，從專業客服到完善售後，每一個環節都經過精心設計，只為讓您購物無憂。
                </p>
                <div class="row g-3">
                    <div class="col-6">
                        <div class="d-flex align-items-center gap-2">
                            <svg width="24" height="24" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                            <span style="font-size:14px;">100% 正品保證</span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="d-flex align-items-center gap-2">
                            <svg width="24" height="24" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                            <span style="font-size:14px;">7天無理由退換</span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="d-flex align-items-center gap-2">
                            <svg width="24" height="24" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                            <span style="font-size:14px;">全台免運配送</span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="d-flex align-items-center gap-2">
                            <svg width="24" height="24" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                            <span style="font-size:14px;">專業客服支援</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="row g-2 text-center">
                    <div class="col-4">
                        <div class="p-3 rounded" style="background:#fff5f5;">
                            <div style="font-size:28px;font-weight:700;color:#ee4d2d;">10萬+</div>
                            <div style="font-size:12px;color:#666;">滿意顧客</div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="p-3 rounded" style="background:#fff5f5;">
                            <div style="font-size:28px;font-weight:700;color:#ee4d2d;">5000+</div>
                            <div style="font-size:12px;color:#666;">精選商品</div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="p-3 rounded" style="background:#fff5f5;">
                            <div style="font-size:28px;font-weight:700;color:#ee4d2d;">99%</div>
                            <div style="font-size:12px;color:#666;">好評率</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 最新公告 -->
    <div class="bg-white rounded p-3 mb-4">
        <div class="d-flex align-items-center gap-3">
            <span class="badge" style="background:#ee4d2d;padding:6px 12px;">公告</span>
            <div class="flex-grow-1 overflow-hidden">
                <marquee behavior="scroll" direction="left" scrollamount="3" style="font-size:14px;color:#666;">
                    🎉 歡迎光臨！全館商品限時優惠中 | 📦 滿額免運，快速到貨 | 🎁 新會員註冊即享首購優惠 | ☎️ 客服專線：0800-000-000（週一至週五 9:00-18:00）
                </marquee>
            </div>
        </div>
    </div>
    
    <!-- 購物指南 -->
    <div class="row g-3 mb-4">
        <div class="col-12">
            <h5 class="mb-3" style="color:#333;">購物指南</h5>
        </div>
        <div class="col-6 col-md-3">
            <a href="<?php echo home_url('/?oip_shop=faq'); ?>" class="bg-white rounded p-3 d-flex align-items-center gap-3 h-100 text-decoration-none" style="color:#333;">
                <div class="rounded-circle d-flex align-items-center justify-content-center" style="width:50px;height:50px;background:#fff5f5;flex-shrink:0;">
                    <svg width="24" height="24" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"/></svg>
                </div>
                <div>
                    <div style="font-size:14px;font-weight:500;">常見問題</div>
                    <div style="font-size:12px;color:#999;">購物疑問解答</div>
                </div>
            </a>
        </div>
        <div class="col-6 col-md-3">
            <a href="<?php echo home_url('/?oip_shop=shipping'); ?>" class="bg-white rounded p-3 d-flex align-items-center gap-3 h-100 text-decoration-none" style="color:#333;">
                <div class="rounded-circle d-flex align-items-center justify-content-center" style="width:50px;height:50px;background:#fff5f5;flex-shrink:0;">
                    <svg width="24" height="24" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4z"/></svg>
                </div>
                <div>
                    <div style="font-size:14px;font-weight:500;">配送說明</div>
                    <div style="font-size:12px;color:#999;">物流時效查詢</div>
                </div>
            </a>
        </div>
        <div class="col-6 col-md-3">
            <a href="<?php echo home_url('/?oip_shop=returns'); ?>" class="bg-white rounded p-3 d-flex align-items-center gap-3 h-100 text-decoration-none" style="color:#333;">
                <div class="rounded-circle d-flex align-items-center justify-content-center" style="width:50px;height:50px;background:#fff5f5;flex-shrink:0;">
                    <svg width="24" height="24" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M19 8l-4 4h3c0 3.31-2.69 6-6 6-1.01 0-1.97-.25-2.8-.7l-1.46 1.46C8.97 19.54 10.43 20 12 20c4.42 0 8-3.58 8-8h3l-4-4zM6 12c0-3.31 2.69-6 6-6 1.01 0 1.97.25 2.8.7l1.46-1.46C15.03 4.46 13.57 4 12 4c-4.42 0-8 3.58-8 8H1l4 4 4-4H6z"/></svg>
                </div>
                <div>
                    <div style="font-size:14px;font-weight:500;">退換貨政策</div>
                    <div style="font-size:12px;color:#999;">售後服務保障</div>
                </div>
            </a>
        </div>
        <div class="col-6 col-md-3">
            <a href="<?php echo esc_url(oip_get_contact_url()); ?>"<?php echo oip_get_line_id() ? ' target="_blank" rel="noopener"' : ''; ?> class="bg-white rounded p-3 d-flex align-items-center gap-3 h-100 text-decoration-none" style="color:#333;">
                <div class="rounded-circle d-flex align-items-center justify-content-center" style="width:50px;height:50px;background:<?php echo oip_get_line_id() ? '#e8f5e9' : '#fff5f5'; ?>;flex-shrink:0;">
                    <?php if (oip_get_line_id()): ?>
                    <svg width="24" height="24" fill="#00B900" viewBox="0 0 24 24"><path d="M19.365 9.863c.349 0 .63.285.63.631 0 .345-.281.63-.63.63H17.61v1.125h1.755c.349 0 .63.283.63.63 0 .344-.281.629-.63.629h-2.386c-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63h2.386c.346 0 .627.285.627.63 0 .349-.281.63-.63.63H17.61v1.125h1.755zm-3.855 3.016c0 .27-.174.51-.432.596-.064.021-.133.031-.199.031-.211 0-.391-.09-.51-.25l-2.443-3.317v2.94c0 .344-.279.629-.631.629-.346 0-.626-.285-.626-.629V8.108c0-.27.173-.51.43-.595.06-.023.136-.033.194-.033.195 0 .375.104.495.254l2.462 3.33V8.108c0-.345.282-.63.63-.63.345 0 .63.285.63.63v4.771zm-5.741 0c0 .344-.282.629-.631.629-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63.346 0 .628.285.628.63v4.771zm-2.466.629H4.917c-.345 0-.63-.285-.63-.629V8.108c0-.345.285-.63.63-.63.348 0 .63.285.63.63v4.141h1.756c.348 0 .629.283.629.63 0 .344-.282.629-.629.629M24 10.314C24 4.943 18.615.572 12 .572S0 4.943 0 10.314c0 4.811 4.27 8.842 10.035 9.608.391.082.923.258 1.058.59.12.301.079.766.038 1.08l-.164 1.02c-.045.301-.24 1.186 1.049.645 1.291-.539 6.916-4.078 9.436-6.975C23.176 14.393 24 12.458 24 10.314"/></svg>
                    <?php else: ?>
                    <svg width="24" height="24" fill="#ee4d2d" viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/></svg>
                    <?php endif; ?>
                </div>
                <div>
                    <div style="font-size:14px;font-weight:500;"><?php echo oip_get_line_id() ? 'LINE 客服' : '聯繫客服'; ?></div>
                    <div style="font-size:12px;color:#999;">線上即時諮詢</div>
                </div>
            </a>
        </div>
    </div>
</main>
        <?php
        echo $shop->get_footer();
    }


    // ========== 分類頁 ==========
    public static function render_category($shop) {
        $cat_slug = isset($_GET['cat']) ? sanitize_text_field($_GET['cat']) : '';
        global $wpdb;
        $category = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}oip_categories WHERE slug = %s", $cat_slug
        ));
        
        if (!$category) {
            wp_redirect(home_url());
            exit;
        }
        
        $products = OIP_Product_Manager::get_products(['category_id' => $category->id, 'status' => 'publish']);
        $categories = OIP_Product_Manager::get_categories();
        
        $sort = $_GET['sort'] ?? 'default';
        if ($sort === 'price-asc') usort($products, function($a, $b) { return $a->price - $b->price; });
        elseif ($sort === 'price-desc') usort($products, function($a, $b) { return $b->price - $a->price; });
        elseif ($sort === 'sales') usort($products, function($a, $b) { return $b->sales - $a->sales; });
        elseif ($sort === 'newest') usort($products, function($a, $b) { return strtotime($b->created_at) - strtotime($a->created_at); });
        
        echo $shop->get_header($category->name);
        ?>
<main class="shop-main">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb bg-white rounded p-3 mb-0">
            <li class="breadcrumb-item"><a href="<?php echo home_url(); ?>" style="color:#ee4d2d;">首頁</a></li>
            <li class="breadcrumb-item active"><?php echo esc_html($category->name); ?></li>
        </ol>
    </nav>
    
    <div class="row">
        <div class="col-lg-3 d-none d-lg-block">
            <div class="bg-white rounded p-3 mb-3 sticky-top" style="top:70px;">
                <h5 class="border-bottom pb-2 mb-3">所有分類</h5>
                <?php foreach ($categories as $cat): ?>
                <a href="<?php echo home_url('/?oip_shop=category&cat=' . $cat->slug); ?>" 
                   class="d-block py-2 border-bottom <?php echo $cat->id == $category->id ? 'fw-bold' : ''; ?>"
                   style="color:<?php echo $cat->id == $category->id ? '#ee4d2d' : '#333'; ?>;font-size:14px;">
                    <?php echo esc_html($cat->name); ?>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div class="col-12 col-lg-9">
            <div class="d-lg-none mb-3">
                <select class="form-select" onchange="location.href=this.value">
                    <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo home_url('/?oip_shop=category&cat=' . $cat->slug); ?>" <?php selected($cat->id, $category->id); ?>>
                        <?php echo esc_html($cat->name); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="bg-white rounded p-3 mb-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h1 class="h5 mb-0"><?php echo esc_html($category->name); ?> <span class="text-muted fw-normal" style="font-size:14px;">(<?php echo count($products); ?> 件)</span></h1>
                <div class="d-flex gap-2 flex-wrap">
                    <a href="?oip_shop=category&cat=<?php echo $cat_slug; ?>&sort=default" class="btn btn-sm <?php echo $sort === 'default' ? 'btn-danger' : 'btn-outline-secondary'; ?>">綜合</a>
                    <a href="?oip_shop=category&cat=<?php echo $cat_slug; ?>&sort=sales" class="btn btn-sm <?php echo $sort === 'sales' ? 'btn-danger' : 'btn-outline-secondary'; ?>">銷量</a>
                    <a href="?oip_shop=category&cat=<?php echo $cat_slug; ?>&sort=newest" class="btn btn-sm <?php echo $sort === 'newest' ? 'btn-danger' : 'btn-outline-secondary'; ?>">最新</a>
                    <a href="?oip_shop=category&cat=<?php echo $cat_slug; ?>&sort=price-asc" class="btn btn-sm <?php echo $sort === 'price-asc' ? 'btn-danger' : 'btn-outline-secondary'; ?>">價格↑</a>
                    <a href="?oip_shop=category&cat=<?php echo $cat_slug; ?>&sort=price-desc" class="btn btn-sm <?php echo $sort === 'price-desc' ? 'btn-danger' : 'btn-outline-secondary'; ?>">價格↓</a>
                </div>
            </div>
            
            <?php if (empty($products)): ?>
            <div class="bg-white rounded p-5 text-center">
                <p class="text-muted">此分類暫無商品</p>
                <a href="<?php echo home_url(); ?>" class="btn btn-danger mt-2">返回首頁</a>
            </div>
            <?php else: ?>
            <?php echo $shop->render_product_grid($products, 4); ?>
            <?php endif; ?>
        </div>
    </div>
</main>
        <?php
        echo $shop->get_footer();
    }
    
    // ========== 搜尋頁 ==========
    public static function render_search($shop) {
        $keyword = isset($_GET['q']) ? sanitize_text_field($_GET['q']) : '';
        $products = $keyword ? OIP_Product_Manager::get_products(['search' => $keyword, 'status' => 'publish']) : [];
        
        $sort = $_GET['sort'] ?? 'default';
        if ($sort === 'price-asc') usort($products, function($a, $b) { return $a->price - $b->price; });
        elseif ($sort === 'price-desc') usort($products, function($a, $b) { return $b->price - $a->price; });
        elseif ($sort === 'sales') usort($products, function($a, $b) { return $b->sales - $a->sales; });
        
        echo $shop->get_header('搜尋: ' . $keyword);
        ?>
<main class="shop-main">
    <div class="bg-white rounded p-3 p-md-4 mb-3">
        <div class="row align-items-center">
            <div class="col-12 col-md-6 mb-2 mb-md-0">
                <h1 class="h5 mb-1">搜尋「<?php echo esc_html($keyword); ?>」</h1>
                <p class="text-muted mb-0" style="font-size:14px;">找到 <?php echo count($products); ?> 個相關商品</p>
            </div>
            <div class="col-12 col-md-6">
                <div class="d-flex gap-2 flex-wrap justify-content-md-end">
                    <a href="?oip_shop=search&q=<?php echo urlencode($keyword); ?>&sort=default" class="btn btn-sm <?php echo $sort === 'default' ? 'btn-danger' : 'btn-outline-secondary'; ?>">綜合</a>
                    <a href="?oip_shop=search&q=<?php echo urlencode($keyword); ?>&sort=sales" class="btn btn-sm <?php echo $sort === 'sales' ? 'btn-danger' : 'btn-outline-secondary'; ?>">銷量</a>
                    <a href="?oip_shop=search&q=<?php echo urlencode($keyword); ?>&sort=price-asc" class="btn btn-sm <?php echo $sort === 'price-asc' ? 'btn-danger' : 'btn-outline-secondary'; ?>">價格↑</a>
                    <a href="?oip_shop=search&q=<?php echo urlencode($keyword); ?>&sort=price-desc" class="btn btn-sm <?php echo $sort === 'price-desc' ? 'btn-danger' : 'btn-outline-secondary'; ?>">價格↓</a>
                </div>
            </div>
        </div>
    </div>
    
    <?php if (empty($products)): ?>
    <div class="bg-white rounded p-5 text-center">
        <h2 class="h5 mt-3 mb-2">找不到相關商品</h2>
        <p class="text-muted mb-3">請嘗試其他關鍵字</p>
        <a href="<?php echo home_url(); ?>" class="btn btn-danger">返回首頁</a>
    </div>
    <?php else: ?>
    <?php echo $shop->render_product_grid($products, 5); ?>
    <?php endif; ?>
</main>
        <?php
        echo $shop->get_footer();
    }
    
    // ========== 商品詳情頁 ==========
    public static function render_product($shop) {
        $product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        global $wpdb;
        $product = $wpdb->get_row($wpdb->prepare(
            "SELECT p.*, c.name as category_name, c.slug as category_slug 
             FROM {$wpdb->prefix}oip_products p 
             LEFT JOIN {$wpdb->prefix}oip_categories c ON p.category_id = c.id 
             WHERE p.id = %d", $product_id
        ));
        
        if (!$product) {
            wp_redirect(home_url());
            exit;
        }
        
        $related = OIP_Product_Manager::get_products(['category_id' => $product->category_id, 'status' => 'publish', 'limit' => 6]);
        $related = array_filter($related, function($p) use ($product_id) { return $p->id != $product_id; });
        
        $discount = 0;
        if ($product->original_price && $product->original_price > $product->price) {
            $discount = round((1 - $product->price / $product->original_price) * 100);
        }
        
        echo $shop->get_header($product->name);
        ?>
<main class="shop-main">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb bg-white rounded p-3 mb-0">
            <li class="breadcrumb-item"><a href="<?php echo home_url(); ?>" style="color:#ee4d2d;">首頁</a></li>
            <?php if ($product->category_name): ?>
            <li class="breadcrumb-item"><a href="<?php echo home_url('/?oip_shop=category&cat=' . $product->category_slug); ?>" style="color:#ee4d2d;"><?php echo esc_html($product->category_name); ?></a></li>
            <?php endif; ?>
            <li class="breadcrumb-item active"><?php echo esc_html($product->name); ?></li>
        </ol>
    </nav>
    
    <div class="bg-white rounded p-3 p-md-4 mb-4">
        <div class="row">
            <div class="col-12 col-md-5 mb-3 mb-md-0">
                <?php if ($product->image): ?>
                <img src="<?php echo esc_url($product->image); ?>" alt="<?php echo esc_attr($product->name); ?>" class="w-100 rounded" style="aspect-ratio:1;object-fit:cover;">
                <?php else: ?>
                <div class="w-100 rounded d-flex align-items-center justify-content-center" style="aspect-ratio:1;background:#f5f5f5;">
                    <svg width="100" height="100" fill="#ddd" viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-12 col-md-7">
                <h1 class="h4 mb-3"><?php echo esc_html($product->name); ?></h1>
                
                <div class="d-flex align-items-center gap-3 mb-3" style="font-size:14px;">
                    <span style="color:#ffce3d;">★ <?php echo number_format($product->rating, 1); ?></span>
                    <span class="text-muted">|</span>
                    <span class="text-muted">已售 <?php echo number_format($product->sales); ?></span>
                    <span class="text-muted">|</span>
                    <span class="text-muted">庫存 <?php echo $product->stock; ?></span>
                </div>
                
                <div class="p-3 mb-3" style="background:#fff5f5;border-radius:4px;">
                    <div class="d-flex align-items-baseline gap-3">
                        <span style="color:#ee4d2d;font-size:28px;font-weight:700;">$<?php echo number_format($product->price); ?></span>
                        <?php if ($product->original_price && $product->original_price > $product->price): ?>
                        <span class="text-muted text-decoration-line-through">$<?php echo number_format($product->original_price); ?></span>
                        <span class="badge bg-danger"><?php echo $discount; ?>% OFF</span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">數量</label>
                    <div class="d-flex align-items-center gap-2">
                        <button class="btn btn-outline-secondary" onclick="changeQty(-1)">-</button>
                        <input type="number" id="qty" value="1" min="1" max="<?php echo $product->stock; ?>" class="form-control text-center" style="width:80px;">
                        <button class="btn btn-outline-secondary" onclick="changeQty(1)">+</button>
                        <span class="text-muted ms-2">庫存 <?php echo $product->stock; ?> 件</span>
                    </div>
                </div>
                
                <div class="d-flex gap-2 flex-wrap">
                    <button class="btn btn-outline-danger btn-lg" onclick="addToCart(<?php echo $product->id; ?>)">
                        <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24" class="me-1"><path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/></svg>
                        加入購物車
                    </button>
                    <button class="btn btn-danger btn-lg" onclick="buyNow(<?php echo $product->id; ?>)">立即購買</button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="bg-white rounded p-3 p-md-4 mb-4">
        <ul class="nav nav-tabs mb-3" id="productTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="desc-tab" data-bs-toggle="tab" data-bs-target="#desc-pane" type="button" role="tab">商品描述</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="spec-tab" data-bs-toggle="tab" data-bs-target="#spec-pane" type="button" role="tab">規格參數</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="review-tab" data-bs-toggle="tab" data-bs-target="#review-pane" type="button" role="tab">商品評價</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="service-tab" data-bs-toggle="tab" data-bs-target="#service-pane" type="button" role="tab">售後服務</button>
            </li>
        </ul>
        <div class="tab-content" id="productTabsContent">
            <div class="tab-pane fade show active" id="desc-pane" role="tabpanel">
                <div style="white-space:pre-wrap;line-height:1.8;"><?php echo nl2br(esc_html($product->description ?: '暫無商品描述')); ?></div>
                
                <div class="mt-4 p-3 rounded" style="background:#f9f9f9;">
                    <h6 class="mb-3">商品特色</h6>
                    <ul class="mb-0" style="line-height:2;">
                        <li>嚴選優質材料，品質有保障</li>
                        <li>精緻工藝製作，細節處理到位</li>
                        <li>多重品質檢測，確保出貨品質</li>
                        <li>原廠正品保證，假一賠十</li>
                    </ul>
                </div>
            </div>
            <div class="tab-pane fade" id="spec-pane" role="tabpanel">
                <table class="table table-bordered mb-0">
                    <tbody>
                        <tr><th style="width:150px;background:#f9f9f9;">商品編號</th><td>SKU-<?php echo str_pad($product->id, 6, '0', STR_PAD_LEFT); ?></td></tr>
                        <tr><th style="background:#f9f9f9;">商品分類</th><td><?php echo esc_html($product->category_name ?: '未分類'); ?></td></tr>
                        <tr><th style="background:#f9f9f9;">庫存數量</th><td><?php echo $product->stock; ?> 件</td></tr>
                        <tr><th style="background:#f9f9f9;">商品狀態</th><td><span class="badge bg-success">現貨供應</span></td></tr>
                        <tr><th style="background:#f9f9f9;">配送方式</th><td>宅配到府 / 超商取貨</td></tr>
                        <tr><th style="background:#f9f9f9;">付款方式</th><td>貨到付款</td></tr>
                    </tbody>
                </table>
            </div>
            <div class="tab-pane fade" id="review-pane" role="tabpanel">
                <div class="d-flex align-items-center gap-4 mb-4 p-3 rounded" style="background:#fff5f5;">
                    <div class="text-center">
                        <div style="font-size:48px;font-weight:700;color:#ee4d2d;"><?php echo number_format($product->rating, 1); ?></div>
                        <div style="color:#ffce3d;font-size:18px;">★★★★★</div>
                        <div style="font-size:12px;color:#999;">共 <?php echo $product->sales; ?> 則評價</div>
                    </div>
                    <div class="flex-grow-1">
                        <?php for ($i = 5; $i >= 1; $i--): 
                            $pct = $i == 5 ? 75 : ($i == 4 ? 18 : ($i == 3 ? 5 : 2));
                        ?>
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <span style="font-size:12px;width:50px;"><?php echo $i; ?> 星</span>
                            <div class="flex-grow-1" style="height:8px;background:#eee;border-radius:4px;overflow:hidden;">
                                <div style="width:<?php echo $pct; ?>%;height:100%;background:#ffce3d;"></div>
                            </div>
                            <span style="font-size:12px;color:#999;width:40px;"><?php echo $pct; ?>%</span>
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>
                
                <div class="border-bottom pb-3 mb-3">
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center" style="width:36px;height:36px;font-size:14px;">王</div>
                        <div>
                            <div style="font-size:14px;">王**</div>
                            <div style="font-size:12px;color:#999;">2026-01-10</div>
                        </div>
                        <div class="ms-auto" style="color:#ffce3d;">★★★★★</div>
                    </div>
                    <p class="mb-0" style="font-size:14px;color:#666;">商品品質很好，包裝完整，物流速度也很快，非常滿意這次的購物體驗！</p>
                </div>
                <div class="border-bottom pb-3 mb-3">
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <div class="rounded-circle bg-info text-white d-flex align-items-center justify-content-center" style="width:36px;height:36px;font-size:14px;">李</div>
                        <div>
                            <div style="font-size:14px;">李**</div>
                            <div style="font-size:12px;color:#999;">2026-01-08</div>
                        </div>
                        <div class="ms-auto" style="color:#ffce3d;">★★★★☆</div>
                    </div>
                    <p class="mb-0" style="font-size:14px;color:#666;">性價比很高，跟描述的一樣，客服態度也很好，會再回購。</p>
                </div>
                <div class="pb-3">
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <div class="rounded-circle bg-success text-white d-flex align-items-center justify-content-center" style="width:36px;height:36px;font-size:14px;">陳</div>
                        <div>
                            <div style="font-size:14px;">陳**</div>
                            <div style="font-size:12px;color:#999;">2026-01-05</div>
                        </div>
                        <div class="ms-auto" style="color:#ffce3d;">★★★★★</div>
                    </div>
                    <p class="mb-0" style="font-size:14px;color:#666;">已經是第三次購買了，品質一如既往的好，推薦給大家！</p>
                </div>
            </div>
            <div class="tab-pane fade" id="service-pane" role="tabpanel">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="p-3 border rounded h-100">
                            <h6 class="mb-3"><svg width="20" height="20" fill="#ee4d2d" viewBox="0 0 24 24" class="me-2"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg>正品保證</h6>
                            <p class="text-muted mb-0" style="font-size:14px;">本店所有商品均為正品，支持專櫃驗貨，假一賠十。</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="p-3 border rounded h-100">
                            <h6 class="mb-3"><svg width="20" height="20" fill="#ee4d2d" viewBox="0 0 24 24" class="me-2"><path d="M19 8l-4 4h3c0 3.31-2.69 6-6 6-1.01 0-1.97-.25-2.8-.7l-1.46 1.46C8.97 19.54 10.43 20 12 20c4.42 0 8-3.58 8-8h3l-4-4zM6 12c0-3.31 2.69-6 6-6 1.01 0 1.97.25 2.8.7l1.46-1.46C15.03 4.46 13.57 4 12 4c-4.42 0-8 3.58-8 8H1l4 4 4-4H6z"/></svg>7天退換</h6>
                            <p class="text-muted mb-0" style="font-size:14px;">收到商品7天內，如有品質問題可申請退換貨服務。</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="p-3 border rounded h-100">
                            <h6 class="mb-3"><svg width="20" height="20" fill="#ee4d2d" viewBox="0 0 24 24" class="me-2"><path d="M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4z"/></svg>快速配送</h6>
                            <p class="text-muted mb-0" style="font-size:14px;">下單後24小時內出貨，全台宅配3-5天送達。</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="p-3 border rounded h-100">
                            <h6 class="mb-3"><svg width="20" height="20" fill="#ee4d2d" viewBox="0 0 24 24" class="me-2"><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>客服支援</h6>
                            <p class="text-muted mb-0" style="font-size:14px;">專業客服團隊，週一至週五 9:00-18:00 在線服務。</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 購買須知 -->
    <div class="bg-white rounded p-3 p-md-4 mb-4">
        <h5 class="border-bottom pb-2 mb-3">購買須知</h5>
        <div class="row g-3" style="font-size:14px;">
            <div class="col-md-6">
                <div class="d-flex gap-2">
                    <svg width="20" height="20" fill="#ee4d2d" viewBox="0 0 24 24" class="flex-shrink-0"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                    <div>
                        <strong>配送時間：</strong>
                        <span class="text-muted">下單後3-5個工作天送達</span>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="d-flex gap-2">
                    <svg width="20" height="20" fill="#ee4d2d" viewBox="0 0 24 24" class="flex-shrink-0"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                    <div>
                        <strong>付款方式：</strong>
                        <span class="text-muted">貨到付款（現金）</span>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="d-flex gap-2">
                    <svg width="20" height="20" fill="#ee4d2d" viewBox="0 0 24 24" class="flex-shrink-0"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                    <div>
                        <strong>退換貨：</strong>
                        <span class="text-muted">7天內可申請退換</span>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="d-flex gap-2">
                    <svg width="20" height="20" fill="#ee4d2d" viewBox="0 0 24 24" class="flex-shrink-0"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                    <div>
                        <strong>客服時間：</strong>
                        <span class="text-muted">週一至週五 9:00-18:00</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php if (!empty($related)): ?>
    <div class="mb-4">
        <div class="section-header">
            <h2 class="section-title">相關商品</h2>
        </div>
        <?php echo $shop->render_product_grid(array_slice($related, 0, 5), 5); ?>
    </div>
    <?php endif; ?>
</main>

<script>
function changeQty(d) {
    var q = document.getElementById('qty');
    var v = parseInt(q.value) + d;
    if (v >= 1 && v <= <?php echo $product->stock; ?>) q.value = v;
}
function addToCart(id) {
    var qty = parseInt(document.getElementById('qty').value);
    var cart = JSON.parse(localStorage.getItem('oip_cart') || '[]');
    var found = false;
    for (var i = 0; i < cart.length; i++) {
        if (cart[i].id == id) { cart[i].qty += qty; found = true; break; }
    }
    if (!found) cart.push({id: id, qty: qty});
    localStorage.setItem('oip_cart', JSON.stringify(cart));
    document.cookie = 'oip_cart=' + JSON.stringify(cart) + ';path=/';
    
    // 台灣電商風格的成功提示
    showCartToast('success');
    setTimeout(function() { location.reload(); }, 800);
}
function buyNow(id) {
    var qty = parseInt(document.getElementById('qty').value);
    var cart = JSON.parse(localStorage.getItem('oip_cart') || '[]');
    var found = false;
    for (var i = 0; i < cart.length; i++) {
        if (cart[i].id == id) { cart[i].qty += qty; found = true; break; }
    }
    if (!found) cart.push({id: id, qty: qty});
    localStorage.setItem('oip_cart', JSON.stringify(cart));
    document.cookie = 'oip_cart=' + JSON.stringify(cart) + ';path=/';
    
    // 顯示提示後跳轉
    showCartToast('buy');
    setTimeout(function() {
        location.href = '<?php echo home_url('/?oip_shop=cart'); ?>';
    }, 600);
}
function showCartToast(type) {
    var toast = document.createElement('div');
    toast.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;padding:30px 40px;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,.15);z-index:99999;text-align:center;min-width:280px;animation:toastIn .3s ease;';
    
    var icon = type === 'success' ? 
        '<svg width="60" height="60" fill="#00d4aa" viewBox="0 0 24 24" style="margin-bottom:15px;"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>' :
        '<svg width="60" height="60" fill="#ee4d2d" viewBox="0 0 24 24" style="margin-bottom:15px;"><path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/></svg>';
    
    var text = type === 'success' ? 
        '<div style="font-size:18px;font-weight:600;color:#333;margin-bottom:8px;">已加入購物車</div><div style="font-size:14px;color:#666;">商品已成功加入購物車</div>' :
        '<div style="font-size:18px;font-weight:600;color:#333;margin-bottom:8px;">正在前往結帳</div><div style="font-size:14px;color:#666;">請稍候...</div>';
    
    toast.innerHTML = icon + text;
    document.body.appendChild(toast);
    
    var style = document.createElement('style');
    style.textContent = '@keyframes toastIn{from{opacity:0;transform:translate(-50%,-50%) scale(.8)}to{opacity:1;transform:translate(-50%,-50%) scale(1)}}';
    document.head.appendChild(style);
    
    setTimeout(function() {
        toast.style.animation = 'toastOut .2s ease';
        style.textContent += '@keyframes toastOut{to{opacity:0;transform:translate(-50%,-50%) scale(.9)}}';
        setTimeout(function() { toast.remove(); style.remove(); }, 200);
    }, type === 'success' ? 600 : 400);
}
</script>
        <?php
        echo $shop->get_footer();
    }
}
