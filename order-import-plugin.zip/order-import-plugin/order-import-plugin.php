<?php
/**
 * Plugin Name: 網站管理
 * Description: 管理系統 - 完全免费开源
 * Version: 1.2.0
 * Requires at least: 5.0
 * Requires PHP: 7.4
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: order-import-plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

define('OIP_VERSION', '1.2.0');
define('OIP_DB_VERSION', '1.2');
define('OIP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('OIP_PLUGIN_URL', plugin_dir_url(__FILE__));

// Activation hook
register_activation_hook(__FILE__, 'oip_activate_plugin');
register_deactivation_hook(__FILE__, 'oip_deactivate_plugin');

function oip_activate_plugin() {
    // 先加载必要的类文件
    require_once OIP_PLUGIN_DIR . 'includes/core/class-order-manager.php';
    require_once OIP_PLUGIN_DIR . 'includes/core/class-user-manager.php';
    require_once OIP_PLUGIN_DIR . 'includes/core/class-product-manager.php';
    
    // 创建数据表
    oip_create_or_update_table();
    OIP_Product_Manager::create_table();
    
    // 創建前台頁面
    oip_create_frontend_pages();
    
    // 導入預設 banner 圖片
    oip_import_default_banners();
    
    // 設置定時任務
    if (!wp_next_scheduled('oip_process_email_queue')) {
        wp_schedule_event(time(), 'oip_every_minute', 'oip_process_email_queue');
    }
    
    // 刷新重寫規則
    flush_rewrite_rules();
}

/**
 * 創建前台頁面
 */
function oip_create_frontend_pages() {
    // 訂單查詢頁面（不需要登录）- 第一优先级
    $order_search_page = get_page_by_path('order-search');
    if (!$order_search_page) {
        wp_insert_post([
            'post_title' => '訂單查詢',
            'post_name' => 'order-search',
            'post_content' => '[order_search]',
            'post_status' => 'publish',
            'post_type' => 'page',
            'menu_order' => 1
        ]);
    }
    
    // 訂單頁面（需要登录）
    $my_orders_page = get_page_by_path('my-orders');
    if (!$my_orders_page) {
        wp_insert_post([
            'post_title' => '我的訂單',
            'post_name' => 'my-orders',
            'post_content' => '[my_orders]',
            'post_status' => 'publish',
            'post_type' => 'page',
            'menu_order' => 2
        ]);
    }
    
    // 登入頁面
    $login_page = get_page_by_path('customer-login');
    if (!$login_page) {
        wp_insert_post([
            'post_title' => '會員登入',
            'post_name' => 'customer-login',
            'post_content' => '[oip_login]',
            'post_status' => 'publish',
            'post_type' => 'page',
            'menu_order' => 3
        ]);
    }
}

function oip_deactivate_plugin() {
    wp_clear_scheduled_hook('oip_process_email_queue');
    flush_rewrite_rules();
}

// 添加自定義 cron 間隔
add_filter('cron_schedules', 'oip_add_cron_interval');
function oip_add_cron_interval($schedules) {
    $schedules['oip_every_minute'] = [
        'interval' => 60,
        'display' => '每分鐘'
    ];
    return $schedules;
}

/**
 * 獲取 LINE 客服連結
 * 如果後台有配置 LINE ID，返回 LINE 連結；否則返回聯繫頁面連結
 */
function oip_get_contact_url() {
    $settings = OIP_Email_Template::get_settings();
    $line_id = !empty($settings['line_id']) ? $settings['line_id'] : '';
    
    if ($line_id) {
        // 移除 @ 符號後再加上，確保格式正確
        $line_id_clean = ltrim($line_id, '@');
        return 'https://line.me/R/ti/p/@' . urlencode($line_id_clean);
    }
    
    // 沒有配置 LINE，返回聯繫頁面
    return home_url('/?oip_shop=contact');
}

/**
 * 獲取 LINE ID（用於顯示）
 */
function oip_get_line_id() {
    $settings = OIP_Email_Template::get_settings();
    return !empty($settings['line_id']) ? $settings['line_id'] : '';
}

/**
 * 創建或更新數據表（不刪除現有數據）
 */
function oip_create_or_update_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'custom_orders';
    $charset_collate = $wpdb->get_charset_collate();
    
    // 定義所有需要的字段
    $required_columns = [
        'id' => 'bigint(20) NOT NULL AUTO_INCREMENT',
        'order_number' => 'varchar(100) NOT NULL',
        'recipient_name' => 'varchar(200) NOT NULL',
        'recipient_address' => 'text NOT NULL',
        'phone' => 'varchar(50) NOT NULL',
        'email' => 'varchar(200) NOT NULL',
        'product_name' => 'text NOT NULL',
        'amount' => 'decimal(10,2) NOT NULL',
        'shipping_method' => "varchar(100) DEFAULT '免運費'",
        'user_id' => 'bigint(20) DEFAULT 0',
        'source' => "varchar(20) DEFAULT 'imported'",
        'status' => "varchar(50) DEFAULT 'pending'",
        'email_sent' => 'tinyint(1) DEFAULT 0',
        'email_sent_at' => 'datetime DEFAULT NULL',
        'email_error' => 'text DEFAULT NULL',
        'is_viewed' => 'tinyint(1) DEFAULT 0',
        'viewed_at' => 'datetime DEFAULT NULL',
        'created_at' => 'datetime DEFAULT CURRENT_TIMESTAMP'
    ];
    
    // 檢查表是否存在
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'");
    
    if (!$table_exists) {
        // 表不存在，創建新表
        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            order_number varchar(100) NOT NULL,
            recipient_name varchar(200) NOT NULL,
            recipient_address text NOT NULL,
            phone varchar(50) NOT NULL,
            email varchar(200) NOT NULL,
            product_name text NOT NULL,
            amount decimal(10,2) NOT NULL,
            shipping_method varchar(100) DEFAULT '免運費',
            user_id bigint(20) DEFAULT 0,
            status varchar(50) DEFAULT 'pending',
            email_sent tinyint(1) DEFAULT 0,
            email_sent_at datetime DEFAULT NULL,
            email_error text DEFAULT NULL,
            is_viewed tinyint(1) DEFAULT 0,
            viewed_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY order_number (order_number)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    } else {
        // 表存在，檢查並添加缺失的字段
        $existing_columns = $wpdb->get_col("SHOW COLUMNS FROM $table_name", 0);
        
        $prev_column = null;
        foreach ($required_columns as $column => $definition) {
            if (!in_array($column, $existing_columns)) {
                $after = $prev_column ? "AFTER $prev_column" : "FIRST";
                $wpdb->query("ALTER TABLE $table_name ADD COLUMN $column $definition $after");
            }
            $prev_column = $column;
        }
    }
    
    update_option('oip_db_version', OIP_DB_VERSION);
}

// Load plugin files - Core
require_once OIP_PLUGIN_DIR . 'includes/core/class-order-manager.php';
require_once OIP_PLUGIN_DIR . 'includes/core/class-user-manager.php';
require_once OIP_PLUGIN_DIR . 'includes/core/class-email-template.php';
require_once OIP_PLUGIN_DIR . 'includes/core/class-email-sender.php';
require_once OIP_PLUGIN_DIR . 'includes/core/class-product-image.php';
require_once OIP_PLUGIN_DIR . 'includes/core/class-product-manager.php';
require_once OIP_PLUGIN_DIR . 'includes/core/class-sendgrid.php';

// Load plugin files - Admin
require_once OIP_PLUGIN_DIR . 'includes/admin/class-admin-page.php';
require_once OIP_PLUGIN_DIR . 'includes/admin/class-smtp-settings.php';

// Load plugin files - Frontend
require_once OIP_PLUGIN_DIR . 'includes/frontend/class-frontend.php';
require_once OIP_PLUGIN_DIR . 'includes/frontend/class-shop-frontend.php';

// Initialize plugin
add_action('init', 'oip_init_plugin', 1);

function oip_init_plugin() {
    // 註冊 shortcodes
    add_shortcode('my_orders', 'oip_shortcode_my_orders');
    add_shortcode('order_search', 'oip_shortcode_order_search');
    add_shortcode('oip_login', 'oip_shortcode_login');
    add_shortcode('oip_account_icon', 'oip_shortcode_account_icon');
    
    new OIP_Admin_Page();
    new OIP_Frontend();
    new OIP_SMTP_Settings();
    new OIP_Email_Template();
    new OIP_Product_Image();
    new OIP_Product_Manager();
    new OIP_Shop_Frontend();
    
    // 檢查數據庫版本，自動升級
    $current_db_version = get_option('oip_db_version', '1.0');
    if (version_compare($current_db_version, OIP_DB_VERSION, '<')) {
        oip_create_or_update_table();
    }
    
    // 確保定時任務存在
    if (!wp_next_scheduled('oip_process_email_queue')) {
        wp_schedule_event(time(), 'oip_every_minute', 'oip_process_email_queue');
    }
    
    // 確保前台頁面存在
    oip_create_frontend_pages();
}

// Shortcode 回調函數
function oip_shortcode_my_orders() {
    // 我的订单需要登录
    if (!is_user_logged_in()) {
        return '<div style="text-align:center;padding:40px 20px;"><p>請先<a href="' . home_url('/?oip_page=login') . '" style="color:#ee4d2d;">登入</a>查看您的訂單</p></div>';
    }
    
    ob_start();
    OIP_Frontend_Orders::render_orders(new OIP_Frontend());
    return ob_get_clean();
}

function oip_shortcode_order_search() {
    // 确保类已加载
    if (!class_exists('OIP_Shop_Frontend')) {
        require_once OIP_PLUGIN_DIR . 'includes/frontend/class-shop-frontend.php';
    }
    if (!class_exists('OIP_Frontend_Orders')) {
        require_once OIP_PLUGIN_DIR . 'includes/frontend/class-frontend-orders.php';
    }
    
    // 订单查询不需要登录 - 直接渲染并退出
    OIP_Frontend_Orders::render_order_search();
    exit; // 重要：防止主题模板干扰
}

function oip_shortcode_login() {
    $frontend = new OIP_Frontend();
    return $frontend->render_login_form();
}

// 帳戶圖標短代碼 [oip_account_icon]
function oip_shortcode_account_icon($atts) {
    $atts = shortcode_atts([
        'size' => '24',
        'color' => '#333',
        'show' => 'icon', // icon, login, orders, both
    ], $atts);
    
    $size = intval($atts['size']);
    $color = esc_attr($atts['color']);
    $show = $atts['show'];
    
    $login_url = home_url('/?oip_page=login');
    $orders_url = home_url('/?oip_page=orders');
    $logout_url = home_url('/?oip_logout=1');
    $is_logged_in = is_user_logged_in();
    
    // 圖標 SVG
    $icon_user = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="' . $size . '" height="' . $size . '" fill="' . $color . '" style="vertical-align:middle;"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>';
    $icon_orders = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="' . $size . '" height="' . $size . '" fill="' . $color . '" style="vertical-align:middle;"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>';
    
    $style = 'display:inline-flex;align-items:center;gap:5px;text-decoration:none;color:' . $color . ';margin:0 8px;';
    
    $output = '<span class="oip-account-icons" style="display:inline-flex;align-items:center;">';
    
    if ($show === 'icon' || $show === 'both') {
        // 帳戶圖標：未登入→登入頁，已登入→訂單頁
        if ($is_logged_in) {
            $output .= '<a href="' . esc_url($orders_url) . '" title="我的訂單" style="' . $style . '">' . $icon_user . '</a>';
        } else {
            $output .= '<a href="' . esc_url($login_url) . '" title="會員登入" style="' . $style . '">' . $icon_user . '</a>';
        }
    }
    
    if ($show === 'orders' || $show === 'both') {
        // 訂單圖標：直接到訂單頁（未登入會被重定向到登入）
        $output .= '<a href="' . esc_url($orders_url) . '" title="查看訂單" style="' . $style . '">' . $icon_orders . '</a>';
    }
    
    if ($show === 'login') {
        // 只顯示登入/登出
        if ($is_logged_in) {
            $user = wp_get_current_user();
            $output .= '<a href="' . esc_url($orders_url) . '" style="' . $style . '">' . $icon_user . '<span>' . esc_html($user->display_name ?: '我的帳戶') . '</span></a>';
            $output .= '<a href="' . esc_url($logout_url) . '" style="' . $style . 'font-size:12px;">登出</a>';
        } else {
            $output .= '<a href="' . esc_url($login_url) . '" style="' . $style . '">' . $icon_user . '<span>登入</span></a>';
        }
    }
    
    $output .= '</span>';
    
    return $output;
}

// 處理郵件隊列（異步發送）
add_action('oip_process_email_queue', 'oip_send_pending_emails');

function oip_send_pending_emails() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'custom_orders';
    
    // 每次處理最多 20 封郵件，避免超時
    $pending_orders = $wpdb->get_results(
        "SELECT * FROM $table_name WHERE email_sent = 0 AND (email_error IS NULL OR email_error = '') ORDER BY created_at ASC LIMIT 20"
    );
    
    foreach ($pending_orders as $order) {
        $data = [
            'order_number' => $order->order_number,
            'recipient_name' => $order->recipient_name,
            'recipient_address' => $order->recipient_address,
            'phone' => $order->phone,
            'email' => $order->email,
            'product_name' => $order->product_name,
            'amount' => $order->amount,
            'created_at' => $order->created_at
        ];
        
        $result = OIP_Email_Sender::send_order_confirmation($data);
        OIP_Order_Manager::update_email_status($order->id, $result, $result ? '' : '發送失敗');
        
        // 每封郵件間隔 1 秒，避免被當作垃圾郵件
        sleep(1);
    }
}

// 處理導入隊列（異步導入）
add_action('oip_process_import_queue', 'oip_process_import_queue');

function oip_process_import_queue() {
    $queue = get_option('oip_import_queue', []);
    if (empty($queue)) return;
    
    // 取出第一個待處理的文件
    $item = null;
    $item_key = null;
    foreach ($queue as $key => $q) {
        if ($q['status'] === 'pending') {
            $item = $q;
            $item_key = $key;
            break;
        }
    }
    
    if (!$item) return;
    
    // 標記為處理中
    $queue[$item_key]['status'] = 'processing';
    update_option('oip_import_queue', $queue);
    
    // 執行導入
    if (file_exists($item['file'])) {
        $result = OIP_Order_Manager::import_from_excel_async($item['file']);
        
        // 記錄結果
        $queue[$item_key]['status'] = 'completed';
        $queue[$item_key]['result'] = $result;
        update_option('oip_import_queue', $queue);
        
        // 刪除臨時文件
        @unlink($item['file']);
    } else {
        $queue[$item_key]['status'] = 'failed';
        $queue[$item_key]['error'] = '文件不存在';
        update_option('oip_import_queue', $queue);
    }
    
    // 清理 24 小時前的記錄
    $queue = array_filter($queue, function($q) {
        return strtotime($q['time']) > strtotime('-24 hours');
    });
    update_option('oip_import_queue', $queue);
}

// 處理郵件追蹤連結
add_action('init', 'oip_handle_tracking_link');

function oip_handle_tracking_link() {
    if (!isset($_GET['oip_track'])) {
        return;
    }
    
    $order_number = sanitize_text_field($_GET['oip_track']);
    $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'view';
    $redirect = isset($_GET['redirect']) ? esc_url_raw(urldecode($_GET['redirect'])) : home_url('/my-orders/');
    
    // 查找訂單並標記為已查看
    $order = OIP_Order_Manager::get_order_by_number($order_number);
    if ($order) {
        OIP_Order_Manager::mark_as_viewed($order->id);
    }
    
    // 跳轉到目標頁面
    wp_redirect($redirect);
    exit;
}

/**
 * 生成追蹤連結
 */
function oip_get_tracking_url($order_number, $redirect_url, $action = 'view') {
    return add_query_arg([
        'oip_track' => $order_number,
        'action' => $action,
        'redirect' => urlencode($redirect_url)
    ], home_url('/'));
}

// AJAX: 手動觸發郵件發送
add_action('wp_ajax_oip_trigger_email_queue', 'oip_ajax_trigger_email_queue');
function oip_ajax_trigger_email_queue() {
    check_ajax_referer('oip_ajax_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('權限不足');
    }
    
    oip_send_pending_emails();
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'custom_orders';
    $pending = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE email_sent = 0 AND (email_error IS NULL OR email_error = '')");
    
    wp_send_json_success(['pending' => $pending]);
}

// AJAX: 創建訂單（前台購物車結帳）
add_action('wp_ajax_oip_create_order', 'oip_ajax_create_order');
add_action('wp_ajax_nopriv_oip_create_order', 'oip_ajax_create_order');

function oip_ajax_create_order() {
    if (!is_user_logged_in()) {
        wp_send_json_error('請先登入');
    }
    
    $user = wp_get_current_user();
    $cart = json_decode(stripslashes($_POST['cart'] ?? '[]'), true);
    
    if (empty($cart)) {
        wp_send_json_error('購物車是空的');
    }
    
    $name = sanitize_text_field($_POST['name'] ?? '');
    $phone = sanitize_text_field($_POST['phone'] ?? '');
    $address = sanitize_text_field($_POST['address'] ?? '');
    $notes = sanitize_textarea_field($_POST['notes'] ?? '');
    
    if (empty($name) || empty($phone) || empty($address)) {
        wp_send_json_error('請填寫完整的收件資訊');
    }
    
    // 獲取商品信息並計算總金額
    $products = OIP_Product_Manager::get_products(['status' => 'publish']);
    $product_map = [];
    foreach ($products as $p) {
        $product_map[$p->id] = $p;
    }
    
    $total = 0;
    $product_names = [];
    foreach ($cart as $item) {
        if (isset($product_map[$item['id']])) {
            $p = $product_map[$item['id']];
            $total += $p->price * $item['qty'];
            $product_names[] = $p->name . ' x' . $item['qty'];
        }
    }
    
    if ($total <= 0) {
        wp_send_json_error('商品不存在');
    }
    
    // 生成隨機訂單號（8位大寫字母+數字）
    $order_number = oip_generate_order_number();
    
    // 創建訂單
    $data = [
        'order_number' => $order_number,
        'recipient_name' => $name,
        'recipient_address' => $address,
        'phone' => $phone,
        'email' => $user->user_email,
        'product_name' => implode(', ', $product_names),
        'amount' => $total,
        'source' => 'online'
    ];
    
    $result = OIP_Order_Manager::import_order($data, false);
    
    if (is_wp_error($result)) {
        wp_send_json_error($result->get_error_message());
    }
    
    wp_send_json_success(['order_id' => $order_number]);
}

/**
 * 生成隨機訂單號（YP開頭格式）
 * 格式：YP + 年月日時分秒(14位) + 6位隨機數
 * 例如：YP20260107165225011274
 */
function oip_generate_order_number() {
    // YP前綴
    $prefix = 'YP';
    
    // 年月日時分秒（14位）
    $datetime = date('YmdHis');
    
    // 6位隨機數字
    $random = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    
    // 組合：YP + 14位日期時間 + 6位隨機 = YP + 20位數字
    $order_number = $prefix . $datetime . $random;
    
    // 確保唯一性
    global $wpdb;
    $table_name = $wpdb->prefix . 'custom_orders';
    $exists = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $table_name WHERE order_number = %s", $order_number
    ));
    
    if ($exists) {
        // 如果重複，重新生成
        return oip_generate_order_number();
    }
    
    return $order_number;
}

/**
 * 自動導入預設 Banner 圖片
 */
function oip_import_default_banners() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'oip_banners';
    
    // 檢查表是否存在
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'");
    if (!$table_exists) {
        return; // 表不存在，跳過
    }
    
    // 檢查是否已有 banner
    $existing = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    if ($existing > 0) {
        return; // 已有 banner，不重複導入
    }
    
    // 預設 banner 圖片（使用佔位圖服務）
    $banners = [
        [
            'title' => '新品上市',
            'image' => 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=1200&h=480&fit=crop',
            'link' => '',
            'sort_order' => 1,
            'status' => 1
        ],
        [
            'title' => '限時特賣',
            'image' => 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1200&h=480&fit=crop',
            'link' => '',
            'sort_order' => 2,
            'status' => 1
        ],
        [
            'title' => '熱銷商品',
            'image' => 'https://images.unsplash.com/photo-1556740738-b6a63e27c4df?w=1200&h=480&fit=crop',
            'link' => '',
            'sort_order' => 3,
            'status' => 1
        ]
    ];
    
    foreach ($banners as $banner) {
        $wpdb->insert($table_name, $banner);
    }
}
