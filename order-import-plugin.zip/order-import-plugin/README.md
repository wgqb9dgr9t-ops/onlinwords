# 網站管理

WordPress 插件 - 完全免费开源

## 安裝

下載後上傳到 WordPress 啟用

## 功能

商品、訂單、會員

## 需求

- WordPress 5.0+
- PHP 7.4+

## 授權

GPL v2 - 完全免费，可自由使用、修改、分发
