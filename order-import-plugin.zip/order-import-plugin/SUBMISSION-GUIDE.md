# WordPress.org 插件提交指南

## 提交前準備清單

### ✅ 已完成
- [x] readme.txt 文件（符合 WordPress.org 格式）
- [x] LICENSE 文件（GPL v2）
- [x] 插件頭部信息完整
- [x] 代碼符合 WordPress 編碼標準
- [x] 安全性檢查（數據驗證、SQL 注入防護）

### 📝 需要你完成

1. **更新個人信息**
   - 編輯 `order-import-plugin.php` 第 7-9 行
   - 編輯 `readme.txt` 第 2 行
   - 將 "Your Name"、"yourwebsite.com" 等替換為你的真實信息

2. **準備截圖**（重要！）
   在插件根目錄創建 `assets` 文件夾，放入以下截圖：
   - `screenshot-1.png` - 商品管理後台（1200x900px）
   - `screenshot-2.png` - 前台商城首頁（1200x900px）
   - `screenshot-3.png` - 購物車結帳（1200x900px）
   - `screenshot-4.png` - 訂單管理（1200x900px）
   - `screenshot-5.png` - 會員中心（1200x900px）

3. **準備插件圖標**（可選但推薦）
   - `icon-128x128.png` - 小圖標
   - `icon-256x256.png` - 大圖標

4. **準備橫幅圖**（可選）
   - `banner-772x250.png` - 標準橫幅
   - `banner-1544x500.png` - 高解析度橫幅

## 提交步驟

### 第一步：註冊 WordPress.org 帳號
1. 訪問 https://wordpress.org/support/register.php
2. 註冊一個帳號（記住你的用戶名）
3. 驗證郵箱

### 第二步：提交插件審核
1. 訪問 https://wordpress.org/plugins/developers/add/
2. 登入你的帳號
3. 填寫表單：
   - **Plugin Name**: 網站管理 - 訂單與商城系統
   - **Plugin Description**: 簡短描述你的插件
   - **Plugin URL**: 你的 GitHub 或網站連結
4. 上傳插件 ZIP 文件
5. 同意條款並提交

### 第三步：等待審核
- 審核時間：通常 2-14 天
- 你會收到郵件通知
- 審核團隊可能會要求修改代碼

### 第四步：使用 SVN 上傳代碼
審核通過後，你會收到一個 SVN 倉庫地址，例如：
```
https://plugins.svn.wordpress.org/your-plugin-name/
```

**上傳步驟：**

1. 安裝 SVN 客戶端（Windows 推薦 TortoiseSVN）

2. 檢出倉庫：
```bash
svn co https://plugins.svn.wordpress.org/your-plugin-name/
cd your-plugin-name
```

3. 複製文件到 trunk 目錄：
```bash
# 複製所有插件文件到 trunk/
cp -r /path/to/order-import-plugin/* trunk/
```

4. 複製截圖到 assets 目錄：
```bash
# 複製截圖和圖標到 assets/
cp screenshot-*.png assets/
cp icon-*.png assets/
cp banner-*.png assets/
```

5. 添加文件並提交：
```bash
svn add trunk/*
svn add assets/*
svn ci -m "Initial release 1.2.0"
```

6. 創建標籤（版本）：
```bash
svn cp trunk tags/1.2.0
svn ci -m "Tagging version 1.2.0"
```

## 重要注意事項

### ⚠️ 代碼審核要點

WordPress.org 審核團隊會檢查：

1. **安全性**
   - ✅ 已使用 `sanitize_*` 函數清理輸入
   - ✅ 已使用 `esc_*` 函數轉義輸出
   - ✅ 已使用 `$wpdb->prepare()` 防止 SQL 注入
   - ✅ 已使用 `wp_nonce` 驗證表單

2. **WordPress 標準**
   - ✅ 使用 WordPress 函數而非原生 PHP
   - ✅ 正確使用鉤子（hooks）
   - ✅ 遵循命名規範

3. **許可證**
   - ✅ GPL v2 或更高版本
   - ✅ 所有第三方庫也必須兼容 GPL

4. **禁止事項**
   - ❌ 不能包含加密代碼
   - ❌ 不能調用外部服務（除非明確說明）
   - ❌ 不能包含廣告或推廣連結
   - ❌ 不能收集用戶數據

### 📧 可能的審核反饋

常見要求修改的問題：

1. **數據驗證不足**
   - 解決：加強 `sanitize_*` 和 `validate_*` 使用

2. **輸出未轉義**
   - 解決：所有 `echo` 使用 `esc_html()` 或 `esc_attr()`

3. **直接數據庫操作**
   - 解決：使用 `$wpdb->prepare()` 預處理語句

4. **缺少文本域**
   - 解決：所有字符串使用 `__()` 或 `_e()` 包裹

## 發布後維護

### 更新插件

1. 修改代碼
2. 更新版本號（`order-import-plugin.php` 和 `readme.txt`）
3. 更新 `readme.txt` 的 Changelog
4. 提交到 SVN trunk
5. 創建新的標籤：
```bash
svn cp trunk tags/1.2.1
svn ci -m "Version 1.2.1"
```

### 回應用戶

- 定期查看 WordPress.org 上的支援論壇
- 及時回應用戶問題和評價
- 收集反饋改進插件

## 替代方案

如果不想提交到 WordPress.org，你也可以：

1. **GitHub Releases**
   - 在 GitHub 上發布
   - 用戶手動下載安裝

2. **自己的網站**
   - 在你的網站提供下載
   - 可以收費或免費

3. **CodeCanyon**
   - Envato 旗下的付費插件市場
   - 可以銷售插件賺錢

## 需要幫助？

- WordPress.org 插件手冊：https://developer.wordpress.org/plugins/
- 插件審核指南：https://developer.wordpress.org/plugins/wordpress-org/detailed-plugin-guidelines/
- SVN 使用教程：https://developer.wordpress.org/plugins/wordpress-org/how-to-use-subversion/

---

**祝你提交順利！** 🎉
