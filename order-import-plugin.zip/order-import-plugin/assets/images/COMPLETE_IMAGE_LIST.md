# 🖼️ 完整圖片清單 - 所有需要的圖片

## 📊 圖片統計
- **產品圖片**：12 張（400x400px）
- **Banner 輪播圖**：3 張（1200x480px）
- **分類圖標**：6 個（80x80px，SVG 或 PNG）
- **總計**：21 個圖片資源

---

## 🛍️ 產品圖片（12 張）

### 手機配件 (Category 6)
| # | 產品名稱 | 圖片名稱 | 尺寸 | 用途 |
|---|---------|--------|------|------|
| 1 | iPhone 15 Pro Max 透明防摔殼 | `iphone15-case.jpg` | 400x400px | 商品列表、詳情頁、首頁推薦 |
| 2 | iPhone 15 鋼化玻璃保護貼 2片裝 | `iphone15-glass.jpg` | 400x400px | 商品列表、詳情頁、首頁推薦 |

### 音頻設備 (Category 4)
| # | 產品名稱 | 圖片名稱 | 尺寸 | 用途 |
|---|---------|--------|------|------|
| 3 | AirPods Pro 2 藍牙耳機 | `airpods-pro2.jpg` | 400x400px | 商品列表、詳情頁、首頁推薦 |
| 4 | Sony WH-1000XM5 無線降噪耳機 | `sony-xm5.jpg` | 400x400px | 商品列表、詳情頁、首頁推薦 |

### 穿戴設備 (Category 3)
| # | 產品名稱 | 圖片名稱 | 尺寸 | 用途 |
|---|---------|--------|------|------|
| 5 | Apple Watch Series 9 智慧手錶 | `apple-watch-s9.jpg` | 400x400px | 商品列表、詳情頁、首頁推薦 |
| 6 | 小米手環 8 | `mi-band-8.jpg` | 400x400px | 商品列表、詳情頁、首頁推薦 |

### 充電配件 (Category 5)
| # | 產品名稱 | 圖片名稱 | 尺寸 | 用途 |
|---|---------|--------|------|------|
| 7 | 65W GaN 氮化鎵快充充電器 | `gan-charger-65w.jpg` | 400x400px | 商品列表、詳情頁、首頁推薦 |
| 8 | Anker 10000mAh 行動電源 | `anker-powerbank.jpg` | 400x400px | 商品列表、詳情頁、首頁推薦 |

### 電腦周邊 (Category 2)
| # | 產品名稱 | 圖片名稱 | 尺寸 | 用途 |
|---|---------|--------|------|------|
| 9 | Logitech MX Master 3S 無線滑鼠 | `mx-master-3s.jpg` | 400x400px | 商品列表、詳情頁、首頁推薦 |
| 10 | Keychron K3 超薄機械鍵盤 | `keychron-k3.jpg` | 400x400px | 商品列表、詳情頁、首頁推薦 |

### 手機支架 (Category 1)
| # | 產品名稱 | 圖片名稱 | 尺寸 | 用途 |
|---|---------|--------|------|------|
| 11 | 車用磁吸手機支架 | `car-phone-mount.jpg` | 400x400px | 商品列表、詳情頁、首頁推薦 |
| 12 | 手機雲台穩定器 | `phone-gimbal.jpg` | 400x400px | 商品列表、詳情頁、首頁推薦 |

---

## 🎬 Banner 輪播圖（3 張）

| # | Banner 名稱 | 圖片名稱 | 尺寸 | 用途 | 位置 |
|---|-----------|--------|------|------|------|
| 1 | 新品上市 | `banner-new-products.jpg` | 1200x480px | 首頁輪播展示 | 首頁頂部 |
| 2 | 限時特賣 | `banner-flash-sale.jpg` | 1200x480px | 首頁輪播展示 | 首頁頂部 |
| 3 | 熱銷商品 | `banner-hot-products.jpg` | 1200x480px | 首頁輪播展示 | 首頁頂部 |

---

## 🏷️ 分類圖標（6 個）

| # | 分類名稱 | 圖片名稱 | 尺寸 | 用途 | 說明 |
|---|---------|--------|------|------|------|
| 1 | 手機支架 | `category-phone-accessories.png` | 80x80px | 首頁分類區塊 | 手機配件分類 |
| 2 | 電腦周邊 | `category-computer-peripherals.png` | 80x80px | 首頁分類區塊 | 電腦周邊分類 |
| 3 | 智能穿戴 | `category-wearables.png` | 80x80px | 首頁分類區塊 | 穿戴設備分類 |
| 4 | 耳機音響 | `category-audio.png` | 80x80px | 首頁分類區塊 | 音頻設備分類 |
| 5 | 充電設備 | `category-chargers.png` | 80x80px | 首頁分類區塊 | 充電配件分類 |
| 6 | 保護殼膜 | `category-cases.png` | 80x80px | 首頁分類區塊 | 保護殼膜分類 |

---

## 📁 完整目錄結構

```
order-import-plugin/assets/images/
├── products/                          # 產品圖片目錄
│   ├── iphone15-case.jpg             # 1. iPhone 15 Pro Max 透明防摔殼
│   ├── iphone15-glass.jpg            # 2. iPhone 15 鋼化玻璃保護貼
│   ├── airpods-pro2.jpg              # 3. AirPods Pro 2 藍牙耳機
│   ├── sony-xm5.jpg                  # 4. Sony WH-1000XM5 無線降噪耳機
│   ├── apple-watch-s9.jpg            # 5. Apple Watch Series 9 智慧手錶
│   ├── mi-band-8.jpg                 # 6. 小米手環 8
│   ├── gan-charger-65w.jpg           # 7. 65W GaN 氮化鎵快充充電器
│   ├── anker-powerbank.jpg           # 8. Anker 10000mAh 行動電源
│   ├── mx-master-3s.jpg              # 9. Logitech MX Master 3S 無線滑鼠
│   ├── keychron-k3.jpg               # 10. Keychron K3 超薄機械鍵盤
│   ├── car-phone-mount.jpg           # 11. 車用磁吸手機支架
│   └── phone-gimbal.jpg              # 12. 手機雲台穩定器
│
├── banners/                           # Banner 輪播圖目錄
│   ├── banner-new-products.jpg       # 1. 新品上市
│   ├── banner-flash-sale.jpg         # 2. 限時特賣
│   └── banner-hot-products.jpg       # 3. 熱銷商品
│
├── categories/                        # 分類圖標目錄
│   ├── category-phone-accessories.png # 1. 手機支架
│   ├── category-computer-peripherals.png # 2. 電腦周邊
│   ├── category-wearables.png        # 3. 智能穿戴
│   ├── category-audio.png            # 4. 耳機音響
│   ├── category-chargers.png         # 5. 充電設備
│   └── category-cases.png            # 6. 保護殼膜
│
├── README.md                          # 圖片說明文檔
├── PRODUCT_IMAGES.md                  # 產品圖片對應表
└── COMPLETE_IMAGE_LIST.md             # 本文檔
```

---

## 🎨 圖片搜尋建議

### 產品圖片搜尋關鍵詞
- **手機配件**：`phone case`, `screen protector`, `iPhone accessories`
- **音頻設備**：`wireless earbuds`, `headphones`, `noise cancelling`, `AirPods`
- **穿戴設備**：`smartwatch`, `fitness band`, `Apple Watch`, `Mi Band`
- **充電配件**：`charger`, `power bank`, `USB-C`, `fast charging`
- **電腦周邊**：`wireless mouse`, `mechanical keyboard`, `computer accessories`
- **手機支架**：`phone mount`, `car holder`, `gimbal stabilizer`

### Banner 搜尋關鍵詞
- **新品上市**：`new products`, `latest`, `new arrivals`, `electronics`
- **限時特賣**：`sale`, `promotion`, `discount`, `flash sale`
- **熱銷商品**：`best sellers`, `popular`, `trending`, `hot products`

### 分類圖標搜尋關鍵詞
- **手機支架**：`phone icon`, `mobile icon`, `smartphone`
- **電腦周邊**：`computer icon`, `laptop icon`, `peripherals`
- **智能穿戴**：`watch icon`, `wearable icon`, `smartwatch`
- **耳機音響**：`headphone icon`, `audio icon`, `speaker`
- **充電設備**：`charger icon`, `battery icon`, `power`
- **保護殼膜**：`shield icon`, `protection icon`, `case`

---

## 📥 下載和放置步驟

1. **下載所有 21 個圖片**
   - 12 個產品圖片（400x400px）
   - 3 個 Banner 圖片（1200x480px）
   - 6 個分類圖標（80x80px）

2. **按照上面的目錄結構放置**
   - 產品圖片 → `products/` 目錄
   - Banner 圖片 → `banners/` 目錄
   - 分類圖標 → `categories/` 目錄

3. **確保文件名完全匹配**
   - 文件名區分大小寫
   - 不要改變文件名

4. **重新激活插件**
   - 系統會自動掃描並導入所有圖片
   - 圖片會自動關聯到對應的產品和 Banner

---

## ✅ 檢查清單

- [ ] 下載 12 個產品圖片
- [ ] 下載 3 個 Banner 圖片
- [ ] 下載 6 個分類圖標
- [ ] 按照目錄結構放置所有圖片
- [ ] 確認文件名完全匹配
- [ ] 重新激活插件
- [ ] 在後台驗證所有圖片已導入

---

## 🔗 推薦圖片網站

- **Unsplash**：https://unsplash.com（高質量免費圖片）
- **Pexels**：https://www.pexels.com（免費圖片庫）
- **Pixabay**：https://pixabay.com（免費圖片和向量圖）
- **Freepik**：https://www.freepik.com（免費和付費資源）

---

## 💡 圖片優化建議

1. **格式選擇**
   - 產品圖片：JPG（更小的文件大小，適合照片）
   - Banner 圖片：JPG（高質量展示）
   - 分類圖標：PNG（支持透明背景）

2. **文件大小**
   - 產品圖片：50-150KB
   - Banner 圖片：100-300KB
   - 分類圖標：10-50KB

3. **壓縮工具**
   - TinyPNG：https://tinypng.com
   - ImageOptim：https://imageoptim.com
   - Squoosh：https://squoosh.app

4. **尺寸檢查**
   - 使用圖片編輯工具確保尺寸正確
   - 避免拉伸或變形
   - 保持高清質量（至少 72 DPI）
