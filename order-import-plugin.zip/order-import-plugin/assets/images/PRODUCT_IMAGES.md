# 產品圖片命名對應表

## 📱 手機配件 (Category 6)
| 產品名稱 | 推薦圖片名稱 | 尺寸 | 說明 |
|---------|-----------|------|------|
| iPhone 15 Pro Max 透明防摔殼 | `iphone15-case.jpg` | 400x400px | 透明防摔殼 |
| iPhone 15 鋼化玻璃保護貼 2片裝 | `iphone15-glass.jpg` | 400x400px | 玻璃保護貼 |

## 🎧 音頻設備 (Category 4)
| 產品名稱 | 推薦圖片名稱 | 尺寸 | 說明 |
|---------|-----------|------|------|
| AirPods Pro 2 藍牙耳機 | `airpods-pro2.jpg` | 400x400px | 蘋果藍牙耳機 |
| Sony WH-1000XM5 無線降噪耳機 | `sony-xm5.jpg` | 400x400px | 索尼降噪耳機 |

## ⌚ 穿戴設備 (Category 3)
| 產品名稱 | 推薦圖片名稱 | 尺寸 | 說明 |
|---------|-----------|------|------|
| Apple Watch Series 9 智慧手錶 | `apple-watch-s9.jpg` | 400x400px | 蘋果智慧手錶 |
| 小米手環 8 | `mi-band-8.jpg` | 400x400px | 小米手環 |

## 🔌 充電配件 (Category 5)
| 產品名稱 | 推薦圖片名稱 | 尺寸 | 說明 |
|---------|-----------|------|------|
| 65W GaN 氮化鎵快充充電器 | `gan-charger-65w.jpg` | 400x400px | 快充充電器 |
| Anker 10000mAh 行動電源 | `anker-powerbank.jpg` | 400x400px | 行動電源 |

## 🖱️ 電腦周邊 (Category 2)
| 產品名稱 | 推薦圖片名稱 | 尺寸 | 說明 |
|---------|-----------|------|------|
| Logitech MX Master 3S 無線滑鼠 | `mx-master-3s.jpg` | 400x400px | 羅技無線滑鼠 |
| Keychron K3 超薄機械鍵盤 | `keychron-k3.jpg` | 400x400px | 機械鍵盤 |

## 📱 手機支架 (Category 1)
| 產品名稱 | 推薦圖片名稱 | 尺寸 | 說明 |
|---------|-----------|------|------|
| 車用磁吸手機支架 | `car-phone-mount.jpg` | 400x400px | 車用支架 |
| 手機雲台穩定器 | `phone-gimbal.jpg` | 400x400px | 手機穩定器 |

## 🎬 Banner 輪播圖
| Banner 名稱 | 推薦圖片名稱 | 尺寸 | 說明 |
|-----------|-----------|------|------|
| 新品上市 | `banner-new-products.jpg` | 1200x480px | 新品展示 |
| 限時特賣 | `banner-flash-sale.jpg` | 1200x480px | 限時促銷 |
| 熱銷商品 | `banner-hot-products.jpg` | 1200x480px | 熱銷商品 |

## 📥 使用方式

1. **下載圖片**：
   - 從 Unsplash、Pexels 等網站下載符合尺寸的圖片
   - 按照上表的「推薦圖片名稱」命名

2. **放置位置**：
   ```
   order-import-plugin/assets/images/
   ├── products/
   │   ├── iphone15-case.jpg
   │   ├── iphone15-glass.jpg
   │   ├── airpods-pro2.jpg
   │   ├── sony-xm5.jpg
   │   ├── apple-watch-s9.jpg
   │   ├── mi-band-8.jpg
   │   ├── gan-charger-65w.jpg
   │   ├── anker-powerbank.jpg
   │   ├── mx-master-3s.jpg
   │   ├── keychron-k3.jpg
   │   ├── car-phone-mount.jpg
   │   └── phone-gimbal.jpg
   └── banners/
       ├── banner-new-products.jpg
       ├── banner-flash-sale.jpg
       └── banner-hot-products.jpg
   ```

3. **自動導入**：
   - 將圖片放在對應目錄
   - 重新激活插件
   - 系統會自動掃描並導入圖片

## 🎨 圖片搜尋建議

### 手機配件
- 搜尋：`phone case`, `screen protector`, `iPhone accessories`

### 音頻設備
- 搜尋：`wireless earbuds`, `headphones`, `noise cancelling`

### 穿戴設備
- 搜尋：`smartwatch`, `fitness band`, `wearable`

### 充電配件
- 搜尋：`charger`, `power bank`, `USB-C`

### 電腦周邊
- 搜尋：`wireless mouse`, `mechanical keyboard`, `computer accessories`

### 手機支架
- 搜尋：`phone mount`, `car holder`, `gimbal stabilizer`

### Banner
- 搜尋：`shopping`, `ecommerce`, `sale`, `promotion`, `electronics`
