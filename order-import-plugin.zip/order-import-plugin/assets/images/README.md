# 網站圖片規格說明

## 目錄結構

```
assets/images/
├── banners/          # Banner 輪播圖
├── products/         # 商品圖片
└── categories/       # 分類圖標
```

## 圖片規格詳情

### 1. Banner 輪播圖 (`banners/`)
- **尺寸**：1200 x 480px
- **格式**：JPG 或 PNG
- **建議數量**：3-5 張
- **命名規則**：`banner-1.jpg`, `banner-2.jpg`, 等
- **用途**：首頁頂部輪播展示

### 2. 商品圖片 (`products/`)
- **尺寸**：400 x 400px（正方形）
- **格式**：JPG 或 PNG
- **命名規則**：`product-{id}.jpg`
- **用途**：商品列表和詳情頁展示

### 3. 分類圖標 (`categories/`)
- **尺寸**：80 x 80px
- **格式**：PNG（建議透明背景）
- **命名規則**：`category-{name}.png`
- **用途**：首頁分類區塊

## 使用方式

### 方式 1：自動導入（推薦）
1. 將 banner 圖片放在 `banners/` 目錄
2. 重新激活插件，系統會自動導入
3. 在後台「輪播圖」管理頁面查看和編輯

### 方式 2：手動上傳
1. 登入 WordPress 後台
2. 進入「網站管理 > 輪播圖」
3. 點擊「新增輪播圖」手動上傳

## 圖片下載建議

可以從以下免費圖片網站下載：
- **Unsplash**：https://unsplash.com
- **Pexels**：https://www.pexels.com
- **Pixabay**：https://pixabay.com

搜尋關鍵詞：
- Banner：`shopping`, `ecommerce`, `sale`, `promotion`
- 商品：`product`, `electronics`, `fashion`, `lifestyle`
- 分類：`category`, `icon`, `shopping bag`, `delivery`

## 圖片優化建議

1. **壓縮**：使用 TinyPNG 或 ImageOptim 壓縮圖片
2. **格式**：
   - Banner 和商品圖：JPG（更小的文件大小）
   - 圖標：PNG（支持透明背景）
3. **尺寸**：確保圖片尺寸正確，避免拉伸變形
