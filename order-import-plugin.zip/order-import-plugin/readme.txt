=== 網站管理 ===
Contributors: yourwordpressusername
Tags: ecommerce, orders, shop, free, open-source
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.2.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

網站管理系統 - 完全免费开源

== Description ==

WordPress 管理工具

功能包含商品、訂單、會員等模組

完全免费，可自由使用、修改、分发

== Installation ==

上傳後啟用

== Changelog ==

= 1.2.0 =
更新功能

= 1.0.0 =
初始版本
